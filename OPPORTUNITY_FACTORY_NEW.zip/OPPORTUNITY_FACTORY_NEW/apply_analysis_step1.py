with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Narrow P4 pathway terms to require explicit cross-market context
old_p4 = """    (
        "P4",
        "Market \\u2192 Market",
        "cross_market_model",
        (
            "replicate",
            "replicable",
            "adapt",
            "transfer",
            "cross-market",
            "another market",
            "benchmark",
            "proven model",
            "successful model",
        ),
    ),"""

new_p4 = """    (
        "P4",
        "Market \\u2192 Market",
        "cross_market_model",
        (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "successful model in another market",
            "successful model abroad",
            "established service in another market",
            "established service abroad",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "cross-market",
            "another market",
            "benchmark",
        ),
    ),"""

content = content.replace(old_p4, new_p4)
print("Step 1 done: P4 pathway terms narrowed")

# 2. Add British English / Spanish variants to pathway terms
# P1 - add British English terms
old_p1 = """    (
        "P1",
        "Resource \\u2192 Value",
        "resource_signal",
        ("resource", "asset", "capacity", "underused", "unused", "idle", "infrastructure"),
    ),"""

new_p1 = """    (
        "P1",
        "Resource \\u2192 Value",
        "resource_signal",
        ("resource", "asset", "capacity", "underused", "unused", "idle", "infrastructure",
         "underutilised", "underleveraged", "latent capacity", "headroom", "sub-optimal utilisation"),
    ),"""

content = content.replace(old_p1, new_p1)
print("Step 2a done: P1 pathway terms updated with British English")

# P2 - add Spanish and other variants
old_p2 = """    (
        "P2",
        "Problem \\u2192 Business",
        "problem_or_demand",
        ("problem", "unmet", "demand", "shortage", "need", "gap", "constraint"),
    ),"""

new_p2 = """    (
        "P2",
        "Problem \\u2192 Business",
        "problem_or_demand",
        ("problem", "unmet", "demand", "shortage", "need", "gap", "constraint",
         "supply-demand disequilibrium", "demand outpaces supply", "demand outstrips supply",
         "demanda insatisfecha", "necesidad no atendida", "demanda supera la oferta"),
    ),"""

content = content.replace(old_p2, new_p2)
print("Step 2b done: P2 pathway terms updated with Spanish variants")

# P3 - add OEE and Spanish terms
old_p3 = """    (
        "P3",
        "Process \\u2192 Opportunity",
        "process_inefficiency",
        ("process", "inefficient", "waste", "leakage", "bottleneck", "delay", "loss"),
    ),"""

new_p3 = """    (
        "P3",
        "Process \\u2192 Opportunity",
        "process_inefficiency",
        ("process", "inefficient", "waste", "leakage", "bottleneck", "delay", "loss",
         "OEE", "availability losses", "quality losses", "fuga de valor", "pérdidas de rendimiento",
         "مراحل التحويل التصنيعي", "هدر كبير"),
    ),"""

content = content.replace(old_p3, new_p3)
print("Step 2c done: P3 pathway terms updated with OEE and Spanish/Arabic")

# P5 - add JV/strategic alignment terms
old_p5 = """    (
        "P5",
        "Combination \\u2192 Value",
        "combination",
        ("combine", "recombination", "integrate", "complementary", "connect", "synergy"),
    ),"""

new_p5 = """    (
        "P5",
        "Combination \\u2192 Value",
        "combination",
        ("combine", "recombination", "integrate", "complementary", "connect", "synergy",
         "strategic alignment", "JV thesis", "joint venture", "partnership thesis",
         "byproduct to input", "industrial symbiosis", "three actor", "cold chain"),
    ),"""

content = content.replace(old_p5, new_p5)
print("Step 2d done: P5 pathway terms updated with JV and compositional terms")

# P6 - add brownfield/adaptive reuse terms
old_p6 = """    (
        "P6",
        "Asset \\u2192 Opportunity",
        "asset_operation",
        (
            "factory",
            "company",
            "turnaround",
            "distressed",
            "reconfigure",
            "alternative use",
            "asset-to-value",
        ),
    ),"""

new_p6 = """    (
        "P6",
        "Asset \\u2192 Opportunity",
        "asset_operation",
        (
            "factory",
            "company",
            "turnaround",
            "distressed",
            "reconfigure",
            "alternative use",
            "asset-to-value",
            "brownfield", "adaptive reuse", "last-mile logistics", "repurpose",
        ),
    ),"""

content = content.replace(old_p6, new_p6)
print("Step 2e done: P6 pathway terms updated with brownfield/adaptive reuse")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)

print("All pathway patches applied successfully!")
