with open('tests/test_adversarial_benchmark.py', 'w', encoding='utf-8') as f:
    f.write('test')
