import base64
chunks = []
for i in range(1, 10):
    try:
        with open("semantic_b64_part" + str(i) + ".txt", "r") as f:
            chunks.append(f.read())
    except:
        break
encoded = "".join(chunks)
content = base64.b64decode(encoded).decode("utf-8")
with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)
print("semantic.py written")