with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Narrow P4 pathway terms to require explicit cross-market context
old_p4 = """    (
        "P4",
        "Market \u2192 Market",
        "cross_market_model",
        (
            "replicate",
            "replicable",
            "adapt",
            "transfer",
            "cross-market",
            "another market",
            "benchmark",
            "proven model",
            "successful model",
        ),
    ),"""

new_p4 = """    (
        "P4",
        "Market \u2192 Market",
        "cross_market_model",
        (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "replicate the",
            "replicate a",
            "replicate an",
            "replicate from",
            "port to",
            "porting to",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "proven model from",
            "proven model we can replicate",
            "proven playbook",
            "proven format",
            "proven scheme",
            "proven approach",
            "successful model in another market",
            "successful model abroad",
            "successful model from",
            "established service in another market",
            "established service abroad",
            "established service from",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "transferable model from",
            "cross-market",
            "another market",
            "benchmark",
            "model from",
            "model in",
            "operates in",
        ),
    ),"""

content = content.replace(old_p4, new_p4)
print("1. P4 pathway terms updated")

# 2. Add British English / Spanish variants to pathway terms
# P1
old_p1 = """    (
        "P1",
        "Resource \u2192 Value",
        "resource_signal",
        ("resource", "asset", "capacity", "underused", "unused", "idle", "infrastructure"),
    ),"""

new_p1 = """    (
        "P1",
        "Resource \u2192 Value",
        "resource_signal",
        ("resource", "asset", "capacity", "underused", "unused", "idle", "infrastructure",
         "underutilised", "underleveraged", "latent capacity", "headroom", "sub-optimal utilisation"),
    ),"""

content = content.replace(old_p1, new_p1)
print("2. P1 pathway terms updated")

# P2
old_p2 = """    (
        "P2",
        "Problem \u2192 Business",
        "problem_or_demand",
        ("problem", "unmet", "demand", "shortage", "need", "gap", "constraint"),
    ),"""

new_p2 = """    (
        "P2",
        "Problem \u2192 Business",
        "problem_or_demand",
        ("problem", "unmet", "demand", "shortage", "need", "gap", "constraint",
         "supply-demand disequilibrium", "demand outpaces supply", "demand outstrips supply",
         "demanda insatisfecha", "necesidad no atendida", "demanda supera la oferta"),
    ),"""

content = content.replace(old_p2, new_p2)
print("3. P2 pathway terms updated")

# P3
old_p3 = """    (
        "P3",
        "Process \u2192 Opportunity",
        "process_inefficiency",
        ("process", "inefficient", "waste", "leakage", "bottleneck", "delay", "loss"),
    ),"""

new_p3 = """    (
        "P3",
        "Process \u2192 Opportunity",
        "process_inefficiency",
        ("process", "inefficient", "waste", "leakage", "bottleneck", "delay", "loss",
         "OEE", "availability losses", "quality losses", "fuga de valor", "pérdidas de rendimiento",
         "مراحل التحويل التصنيعي", "هدر كبير"),
    ),"""

content = content.replace(old_p3, new_p3)
print("4. P3 pathway terms updated")

# P5
old_p5 = """    (
        "P5",
        "Combination \u2192 Value",
        "combination",
        ("combine", "recombination", "integrate", "complementary", "connect", "synergy"),
    ),"""

new_p5 = """    (
        "P5",
        "Combination \u2192 Value",
        "combination",
        ("combine", "recombination", "integrate", "complementary", "connect", "synergy",
         "strategic alignment", "JV thesis", "joint venture", "partnership thesis",
         "byproduct to input", "industrial symbiosis", "three actor", "cold chain"),
    ),"""

content = content.replace(old_p5, new_p5)
print("5. P5 pathway terms updated")

# P6
old_p6 = """    (
        "P6",
        "Asset \u2192 Opportunity",
        "asset_operation",
        (
            "factory",
            "company",
            "turnaround",
            "distressed",
            "reconfigure",
            "alternative use",
            "asset-to-value",
        ),
    ),"""

new_p6 = """    (
        "P6",
        "Asset \u2192 Opportunity",
        "asset_operation",
        (
            "factory",
            "company",
            "turnaround",
            "distressed",
            "reconfigure",
            "alternative use",
            "asset-to-value",
            "brownfield", "adaptive reuse", "last-mile logistics", "repurpose",
        ),
    ),"""

content = content.replace(old_p6, new_p6)
print("6. P6 pathway terms updated")

# 3. Add NEGATION_ALIASES_ANALYSIS and HYPOTHETICAL_MARKERS_ANALYSIS constants after PATHWAYS
old_section = """),
)

EVIDENCE_DEFINITIONS = {"""

new_section = """),
)

NEGATION_ALIASES_ANALYSIS = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "absent",
    "devoid of",
    "free from",
    "no sign of",
    "no evidence of",
    "does not have",
    "does not operate",
    "does not exist",
    "is not",
    "are not",
    "was not",
    "were not",
    "has no",
    "have no",
    "had no",
    "without any",
    "sin",
    "no hay",
    "no existe",
    "no hay evidencia",
    "sin evidencia",
    "لا",
    "ليس",
    "بدون",
    "غير",
    "لا يوجد",
    "ليس هناك",
    "لا دليل على",
    "غير متوفر",
    "ما في",
    "ما فيه",
    "ماكو",
    "موجودش",
    "لا يوجد",
    "nicht",
    "kein",
    "keine",
    "keiner",
    "keines",
    "ohne",
    "fehlt",
)

HYPOTHETICAL_MARKERS_ANALYSIS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
    "projected",
    "forecast",
    "scenario analysis",
    "what if",
    "suppose",
    "supposing",
    "assuming",
    "in theory",
    "theoretically",
    "on paper",
    "envisage",
    "envision",
    "contemplate",
    "consider",
    "explore",
    "investigate",
    "evaluate",
    "assess",
    "دراسة",
    "تحليل",
    "سيناريو",
    "افتراض",
    "مقترح",
    "توقع",
    "مشروط",
    "في حال",
    "لو",
    "في حالة",
    "si",
    "caso",
    "supongamos",
    "hipotéticamente",
    "proyectado",
    "pronóstico",
    "análisis de escenario",
)

EVIDENCE_DEFINITIONS = {"""

content = content.replace(old_section, new_section)
print("7. Added NEGATION_ALIASES_ANALYSIS and HYPOTHETICAL_MARKERS_ANALYSIS")

# 4. Fix _is_negated in analysis.py
old_is_negated = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 60):start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return bool(
        re.search(
            r"\\b(?:no|not|without|none|absent|lack(?:\\s+of)?)"
            r"(?:\\W+\\w+){0,5}\\W*$",
            prefix,
        )
    )"""

new_is_negated = """def _normalize_analysis(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\\w){re.escape(_normalize_analysis(alias))}"
            rf"(?:\\s+\\w+){{0,6}}\\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES_ANALYSIS
    )"""

content = content.replace(old_is_negated, new_is_negated)
print("8. _is_negated updated")

# 5. Fix _is_hypothetical_statement in analysis.py
old_is_hypothetical = """def _is_hypothetical_statement(text: str, start: int) -> bool:
    sentence_start = max(
        text.rfind(".", 0, start),
        text.rfind("!", 0, start),
        text.rfind("?", 0, start),
        text.rfind(";", 0, start),
    ) + 1
    sentence_end_candidates = [
        index
        for index in (
            text.find(".", start),
            text.find("!", start),
            text.find("?", start),
            text.find(";", start),
        )
        if index >= 0
    ]
    sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(text)
    sentence = text[sentence_start:sentence_end]
    if "?" in text[start:sentence_end + 1]:
        return True
    return bool(
        re.search(
            r"\\b(?:if|could|might|would|may|potentially|hypothetical|scenario|assume)\\b",
            sentence,
        )
    )"""

new_is_hypothetical = """def _is_hypothetical_statement(text: str, start: int) -> bool:
    sentence_start = max(
        text.rfind(".", 0, start),
        text.rfind("!", 0, start),
        text.rfind("?", 0, start),
        text.rfind(";", 0, start),
    ) + 1
    sentence_end_candidates = [
        index
        for index in (
            text.find(".", start),
            text.find("!", start),
            text.find("?", start),
            text.find(";", start),
        )
        if index >= 0
    ]
    sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(text)
    sentence = text[sentence_start:sentence_end]
    if "?" in text[start:sentence_end + 1]:
        return True
    marker_pattern = "|".join(re.escape(marker) for marker in HYPOTHETICAL_MARKERS_ANALYSIS)
    return bool(
        re.search(
            rf"(?<!\\w)(?:{marker_pattern})(?!\\w)",
            sentence,
        )
    )"""

content = content.replace(old_is_hypothetical, new_is_hypothetical)
print("9. _is_hypothetical_statement updated")

# 6. Add discovery_reasoning to opportunity object
old_opp = """            opportunities.append(
                {
                    "title": f"{evaluation[\"name\"]} candidate for {investigation[\"market\"]}",
                    "description": (
                        "Evidence-linked opportunity hypothesis generated from the "
                        f"{evaluation[\"name\"]} pathway. It is not a verified opportunity."
                    ),
                    "origin": evaluation["origin"],
                    "pathway": evaluation["id"],
                    "evidence_strength": evidence["evidence_level"],
                    "confidence": confidence,
                    "economic_logic": economic_logic,
                    "assumptions": assumptions,
                    "unknowns": unknowns,
                    "hard_gates": hard_gates,
                    "pathway_evaluations": pathway_evaluations,
                    "quality": quality,
                    "status": ("""

new_opp = """            opportunities.append(
                {
                    "title": f"{evaluation[\"name\"]} candidate for {investigation[\"market\"]}",
                    "description": (
                        "Evidence-linked opportunity hypothesis generated from the "
                        f"{evaluation[\"name\"]} pathway. It is not a verified opportunity."
                    ),
                    "origin": evaluation["origin"],
                    "pathway": evaluation["id"],
                    "evidence_strength": evidence["evidence_level"],
                    "confidence": confidence,
                    "economic_logic": economic_logic,
                    "assumptions": assumptions,
                    "unknowns": unknowns,
                    "hard_gates": hard_gates,
                    "pathway_evaluations": pathway_evaluations,
                    "quality": quality,
                    "discovery_reasoning": evaluation.get("reasoning", []),
                    "status": ("""

content = content.replace(old_opp, new_opp)
print("10. discovery_reasoning added to opportunity")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)

print("All changes applied successfully!")
