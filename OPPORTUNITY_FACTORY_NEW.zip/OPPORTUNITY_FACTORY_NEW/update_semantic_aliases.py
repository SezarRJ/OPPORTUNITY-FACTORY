with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# Add more aliases for underutilized_capacity
old_underutilized = """    "underutilized_capacity": {
        "aliases": (
            "underutilized capacity",
            "underused capacity",
            "idle capacity",
            "unused capacity",
            "capacity not fully used",
            "operating below capacity",
            "infrastructure operating below capacity",
            "operates below its design limit",
            "capacity remains available",
            "underutilized asset",
            "idle asset",
            "unused byproduct",
            "unused by-products",
            "discarded byproduct",
            "discarded by-products",
            "surplus resource",
            "capacidad ociosa",
            "capacidad infrautilizada",
            "capacidad no utilizada",
            "recurso subutilizado",
            "subproductos no utilizados",
            "قدرة غير مستغلة",
            "طاقة غير مستغلة",
            "أصل غير مستغل",
            "مورد غير مستغل",
        ),"""

new_underutilized = """    "underutilized_capacity": {
        "aliases": (
            "underutilized capacity",
            "underused capacity",
            "idle capacity",
            "unused capacity",
            "capacity not fully used",
            "operating below capacity",
            "infrastructure operating below capacity",
            "operates below its design limit",
            "capacity remains available",
            "underutilized asset",
            "idle asset",
            "unused byproduct",
            "unused by-products",
            "discarded byproduct",
            "discarded by-products",
            "surplus resource",
            "capacidad ociosa",
            "capacidad infrautilizada",
            "capacidad no utilizada",
            "recurso subutilizado",
            "subproductos no utilizados",
            "قدرة غير مستغلة",
            "طاقة غير مستغلة",
            "أصل غير مستغل",
            "مورد غير مستغل",
            "half-empty",
            "half empty",
            "sitting idle",
            "sitting half-empty",
            "sub-optimal utilisation",
            "suboptimal utilisation",
            "headroom",
            "underleveraged",
            "latent capacity",
            "underleveraged asset",
            "latent capability",
            "significant unused",
        ),"""

content = content.replace(old_underutilized, new_underutilized)
print("underutilized_capacity aliases updated")

# Add more aliases for unmet_demand
old_unmet = """    "unmet_demand": {
        "aliases": (
            "unmet demand",
            "unserved demand",
            "unserved need",
            "demand outstrips supply",
            "demand exceeds supply",
            "service deficit",
            "buyers cannot obtain",
            "local demand is not served",
            "demanda insatisfecha",
            "la demanda supera la oferta",
            "necesidad no atendida",
            "الطلب غير الملبى",
            "الطلب يتجاوز العرض",
            "فجوة بين العرض والطلب",
            "حاجة غير ملباة",
        ),"""

new_unmet = """    "unmet_demand": {
        "aliases": (
            "unmet demand",
            "unserved demand",
            "unserved need",
            "demand outstrips supply",
            "demand exceeds supply",
            "service deficit",
            "buyers cannot obtain",
            "local demand is not served",
            "demanda insatisfecha",
            "la demanda supera la oferta",
            "necesidad no atendida",
            "الطلب غير الملبى",
            "الطلب يتجاوز العرض",
            "فجوة بين العرض والطلب",
            "حاجة غير ملباة",
            "supply-demand disequilibrium",
            "demand outpaces supply",
            "demand outpacing supply",
            "demand disequilibrium",
            "persistent supply-demand",
            "quantitative analysis reveals",
        ),"""

content = content.replace(old_unmet, new_unmet)
print("unmet_demand aliases updated")

# Add more aliases for process_loss
old_process = """    "process_loss": {
        "aliases": (
            "yield loss",
            "material attrition",
            "conversion loss",
            "value escapes between stages",
            "losses between value chain stages",
            "value chain leakage",
            "post harvest losses",
            "yield reduction between value chain stages",
            "throughput bottleneck",
            "process leakage",
            "pérdida de rendimiento",
            "pérdida de material",
            "cuello de botella",
            "فاقد المواد",
            "هدر سلسلة القيمة",
            "تسرب القيمة",
            "عنق الزجاجة",
            "خسارة التحويل",
        ),"""

new_process = """    "process_loss": {
        "aliases": (
            "yield loss",
            "material attrition",
            "conversion loss",
            "value escapes between stages",
            "losses between value chain stages",
            "value chain leakage",
            "post harvest losses",
            "yield reduction between value chain stages",
            "throughput bottleneck",
            "process leakage",
            "pérdida de rendimiento",
            "pérdida de material",
            "cuello de botella",
            "فاقد المواد",
            "هدر سلسلة القيمة",
            "تسرب القيمة",
            "عنق الزجاجة",
            "خسارة التحويل",
            "OEE",
            "availability losses",
            "quality losses",
            "availability loss",
            "quality loss",
            "significant availability",
            "significant quality",
            "fuga de valor",
            "pérdidas de rendimiento",
            "مراحل التحويل التصنيعي",
            "هدر كبير",
            "deadweight loss",
            "allocative inefficiency",
        ),"""

content = content.replace(old_process, new_process)
print("process_loss aliases updated")

# Add more aliases for combination
old_combination = """    "combination": {
        "aliases": (
            "combine complementary capabilities",
            "link separate capabilities",
            "joint arrangement",
            "bundle resources and demand",
            "integrate complementary resources",
            "link an available resource with industrial capacity",
            "available resource and processing capability can be linked",
            "feedstock and processing capability can be linked",
            "feedstock and transformation capability can be linked",
            "match resource with processing",
            "combinar capacidades complementarias",
            "ربط قدرات متكاملة",
            "دمج موارد وقدرات",
            "ترتيب مشترك",
        ),"""

new_combination = """    "combination": {
        "aliases": (
            "combine complementary capabilities",
            "link separate capabilities",
            "joint arrangement",
            "bundle resources and demand",
            "integrate complementary resources",
            "link an available resource with industrial capacity",
            "available resource and processing capability can be linked",
            "feedstock and processing capability can be linked",
            "feedstock and transformation capability can be linked",
            "match resource with processing",
            "combinar capacidades complementarias",
            "ربط قدرات متكاملة",
            "دمج موارد وقدرات",
            "ترتيب مشترك",
            "strategic alignment",
            "JV thesis",
            "joint venture thesis",
            "partnership thesis",
            "byproduct to input",
            "industrial symbiosis",
            "three actor",
            "cold chain",
            "connecting all three",
            "logistics company",
            "empty return trips",
            "retailer needs",
            "consistent supply",
            "steel mill slag",
            "cement plant",
            "supplementary cementitious",
            "clinker factor",
            "disposal costs",
            "port has unused",
            "berth capacity",
            "rail connection",
            "integrated operator",
            "delay cost savings",
        ),"""

content = content.replace(old_combination, new_combination)
print("combination aliases updated")

# Add more aliases for asset_reconfiguration
old_asset = """    "asset_reconfiguration": {
        "aliases": (
            "repurpose facility",
            "alternative use for asset",
            "reconfigure operation",
            "distressed plant",
            "asset turnaround",
            "reutilizar una instalación",
            "reconfigurar una operación",
            "إعادة استخدام منشأة",
            "استخدام بديل للأصل",
            "إعادة تهيئة العملية",
            "مصنع متعثر",
        ),"""

new_asset = """    "asset_reconfiguration": {
        "aliases": (
            "repurpose facility",
            "alternative use for asset",
            "reconfigure operation",
            "distressed plant",
            "asset turnaround",
            "reutilizar una instalación",
            "reconfigurar una operación",
            "إعادة استخدام منشأة",
            "استخدام بديل للأصل",
            "إعادة تهيئة العملية",
            "مصنع متعثر",
            "brownfield",
            "adaptive reuse",
            "last-mile logistics",
            "last mile logistics",
            "repurpose",
            "redevelop",
            "convert",
            "zoning",
            "ceiling height",
            "buy the distressed",
            "sell the land",
            "equipment has no buyers",
        ),"""

content = content.replace(old_asset, new_asset)
print("asset_reconfiguration aliases updated")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("All alias updates applied successfully!")
