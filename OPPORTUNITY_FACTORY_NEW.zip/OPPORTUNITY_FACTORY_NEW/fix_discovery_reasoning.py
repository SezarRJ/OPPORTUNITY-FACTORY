with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# Add discovery_reasoning to opportunity object at top level
old_opp = """            opportunities.append(
                {
                    "title": f"{evaluation[\"name\"]} candidate for {investigation[\"market\"]}",
                    "description": (
                        "Evidence-linked opportunity hypothesis generated from the "
                        f"{evaluation[\"name\"]} pathway. It is not a verified opportunity."
                    ),
                    "origin": evaluation["origin"],
                    "pathway": evaluation["id"],
                    "evidence_strength": evidence["evidence_level"],
                    "confidence": confidence,
                    "economic_logic": economic_logic,
                    "assumptions": assumptions,
                    "unknowns": unknowns,
                    "hard_gates": hard_gates,
                    "pathway_evaluations": pathway_evaluations,
                    "quality": quality,
                    "status": ("""

new_opp = """            opportunities.append(
                {
                    "title": f"{evaluation[\"name\"]} candidate for {investigation[\"market\"]}",
                    "description": (
                        "Evidence-linked opportunity hypothesis generated from the "
                        f"{evaluation[\"name\"]} pathway. It is not a verified opportunity."
                    ),
                    "origin": evaluation["origin"],
                    "pathway": evaluation["id"],
                    "evidence_strength": evidence["evidence_level"],
                    "confidence": confidence,
                    "economic_logic": economic_logic,
                    "assumptions": assumptions,
                    "unknowns": unknowns,
                    "hard_gates": hard_gates,
                    "pathway_evaluations": pathway_evaluations,
                    "quality": quality,
                    "discovery_reasoning": evaluation.get("reasoning", []),
                    "status": ("""

content = content.replace(old_opp, new_opp)
print("discovery_reasoning added to opportunity top level")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)
