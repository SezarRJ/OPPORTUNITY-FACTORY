import os  
os.chdir(r'D:\مصنع الفرص\OPPORTUNITY_FACTORY_NEW')  
with open('app/services/semantic.py', 'r', encoding='utf-8') as f:  
    content = f.read()  
start = content.find('GENERALIZED_REGEX_RULES =')  
end = content.find('GENERALIZED_GROUP_RULES =')  
  
new_rules_text = ''' 
