with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# Add _normalize function before _is_negated
old_is_negated_def = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]"""

new_is_negated_def = """def _normalize_analysis(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]"""

content = content.replace(old_is_negated_def, new_is_negated_def)
print("_normalize_analysis function added")

# Update the _is_negated function to use _normalize_analysis
old_normalize_call = """rf"(?<!\\\\w){re.escape(_normalize(alias))}\""""

new_normalize_call = """rf"(?<!\\\\w){re.escape(_normalize_analysis(alias))}\""""

content = content.replace(old_normalize_call, new_normalize_call)
print("_normalize calls updated to _normalize_analysis")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Fix applied successfully!")
