import base64

def build_content():
    parts = []
    parts.append("from __future__ import annotations")
    parts.append("")
    parts.append("import re")
    parts.append("import unicodedata")
    parts.append("from typing import Any")
    parts.append("")
    parts.append("")
    parts.append("SEMANTIC_RULE_VERSION = ""OF-SEMANTIC-RULES-0.3""")
    parts.append("")
    parts.append("SEMANTIC_CONCEPTS = {")
    # ... (rest of content)
    return "
".join(parts)

content = build_content()
encoded = base64.b64encode(content.encode("utf-8")).decode()
chunk_size = 10000
for i in range(0, len(encoded), chunk_size):
    chunk = encoded[i:i+chunk_size]
    part_num = i // chunk_size + 1
    with open("semantic_b64_part" + str(part_num) + ".txt", "w") as f:
        f.write(chunk)
    print("Wrote part" + str(part_num))
print("Done")