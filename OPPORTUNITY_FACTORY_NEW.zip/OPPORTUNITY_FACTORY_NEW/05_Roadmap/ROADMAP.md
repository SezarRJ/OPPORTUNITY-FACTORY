# STAGED DESIGN AND IMPLEMENTATION ROADMAP
**Version:** 1.0  
**Status:** DRAFT — For Review  
**Date:** 2026-11-08  
**Project:** OPPORTUNITY FACTORY  
**Document ID:** OF-RM-001

---

## PURPOSE

This roadmap defines the staged approach for designing and implementing OPPORTUNITY FACTORY. Each stage has explicit entry/exit criteria and approval gates.

---

## ROADMAP OVERVIEW

`
STAGE 0: FOUNDATION (Current)          STAGE 1: ARCHITECTURE & DESIGN
+-- Master Strategic Reference         +-- Technology Stack Decision (PD-01..07)
+-- Decision Register                  +-- Database Technology Decision (PD-02)
+-- Requirements Traceability          +-- AI/ML Framework Decision (PD-03)
+-- Specifications To Design           +-- Frontend Framework Decision (PD-04)
+-- Roadmap (this doc)                 +-- Deployment Target Decision (PD-05)
+-- Approval Process                   +-- Core Data Specs (SD-001..008)
                                       +-- Engine Specs (SD-010..014)
                                       +-- Module Specs (SD-020..028)
                                       +-- Cross-Cutting Specs (SD-030..042)
                                       +-- UI/UX Specs (SD-050..056)
                                            |
                                            v
STAGE 2: CORE FOUNDATION (Phase 1)     STAGE 3: OPPORTUNITY DISCOVERY (Phase 2)
+-- User Auth & Permissions            +-- Guided Search & Market Analysis
+-- Dashboard (SD-050)                 +-- Gap Detection (SD-022)
+-- Canonical Data Model (SD-001)      +-- Relationship Discovery
+-- Entity/Market/Asset CRUD (SD-020)  +-- Initial Opportunity Creation (SD-023)
+-- Source/Evidence Management (SD-024)+-- Opportunity Management
+-- Task Management                    +-- Acceptance Tests A, B
+-- Background Jobs (SD-033)           |
+-- Audit Logging (SD-032)             v
+-- Acceptance Tests: Infrastructure   STAGE 4: CREATION & VALIDATION (Phase 3)
+-- STAGE 1 APPROVAL GATE              +-- Economic Model Builder (SD-025)
                                       +-- Claim Verification (SD-024)
                                       +-- Assumption Management
                                       +-- Cost/Revenue Analysis
                                       +-- Risk Assessment (SD-026)
                                       +-- Opportunity Comparison
                                       +-- Acceptance Tests C, E, F, G
                                            |
                                            v
STAGE 5: ASSET-TO-VALUE (Phase 4)      STAGE 6: LEARNING & EXPANSION (Phase 5)
+-- Asset Data Ingestion               +-- Outcome Tracking (SD-028)
+-- Process Analysis                   +-- Prediction vs Actual
+-- Unused Capacity Detection          +-- Discovery Rule Improvement
+-- Waste Identification               +-- Model Recalibration
+-- Activity Reconfiguration           +-- Data Source Expansion
+-- Improvement Opportunities          +-- Market/Language Expansion
+-- Acceptance Test D                  +-- Automation Assessment
                                        +-- Acceptance Test H
                                            |
                                            v
                              STAGE 7: PRODUCTION HARDENING
                              +-- Performance Optimization
                              +-- Security Hardening
                              +-- Observability Complete
                              +-- Backup/DR Tested
                              +-- Documentation Complete
                              +-- FINAL APPROVAL GATE
`

---

## STAGE 0: FOUNDATION (Weeks 1-2) — CURRENT

### Objective
Establish project foundation, strategic alignment, and decision register.

### Deliverables
| ID | Deliverable | Status |
|----|-------------|--------|
| D0-01 | Project Structure Created | **DONE** |
| D0-02 | Master Strategic Reference (OF-SR-001) | **DRAFT** |
| D0-03 | Decision Register (OF-DR-001) | **DRAFT** |
| D0-04 | Requirements Traceability Framework (OF-RTF-001) | **DRAFT** |
| D0-05 | Specifications To Design (OF-STD-001) | **DRAFT** |
| D0-06 | Roadmap (OF-RM-001) | **DRAFT** |
| D0-07 | Approval Process (OF-AP-001) | **DRAFT** |

### Exit Criteria
- [ ] All 6 primary foundation documents reviewed and 11 ADR statuses recorded
- [ ] Strategic conflicts (C1-C8) acknowledged
- [ ] Pending decisions (PD-01..26) assigned owners
- [ ] Product Owner final Gate 0 closure decision recorded
- [ ] Stage 1 authorization recorded separately

### Approval Required
**Product Owner final authority, informed by Codex AI-assisted architectural assessment and AI-assisted Domain & Economic Methodology Assessment**

---

## STAGE 1: ARCHITECTURE & DESIGN (Weeks 3-8)

### Objective
Resolve all PENDING technology decisions; produce all design specifications (SDD-XXX).

### Phase 1A: Technology Decisions (Weeks 3-4)

| Decision | Owner | Target | Dependencies |
|----------|-------|--------|--------------|
| PD-01: Technology Stack | Lead Architect | Week 3 | Architecture justification |
| PD-02: Database Technology | Data Architect | Week 3 | Canonical model analysis |
| PD-03: AI/ML Framework | AI Systems Engineer | Week 3 | Engine requirements |
| PD-04: Frontend Framework | Frontend Lead | Week 3 | UI complexity |
| PD-05: Deployment Target | DevOps / Owner | Week 3 | Data sovereignty, cost |
| PD-06: Containerization | DevOps | Week 4 | PD-05 |
| PD-07: CI/CD Pipeline | DevOps | Week 4 | Repo strategy |

**Gate**: All PD-01..07 **RESOLVED** with documented ADRs.

### Phase 1B: Core Data Design (Weeks 4-5)

| Spec | Title | Owner | Target |
|------|-------|-------|--------|
| SD-001 | Canonical Data Model — Physical Schema | Data Architect | Week 4 |
| SD-002 | Entity Resolution Specification | Data Architect | Week 4 |
| SD-003 | Economic Ontology & Relationship Schema | Domain Expert | Week 4 |
| SD-004 | Evidence Ledger Schema | Data Architect | Week 5 |
| SD-005 | Claim Registry Schema | Data Architect | Week 5 |
| SD-006 | Source Registry Schema | Data Architect | Week 5 |
| SD-007 | Opportunity State Machine Schema | Domain Expert | Week 5 |
| SD-008 | Temporal Data Model | Data Architect | Week 5 |

**Gate**: All SD-001..008 **DESIGN REVIEWED & APPROVED**.

### Phase 1C: Engine Design (Weeks 5-6)

| Spec | Title | Owner | Target |
|------|-------|-------|--------|
| SD-010 | E1: Economic World Scanner | Economic Intelligence Lead | Week 5 |
| SD-011 | E2: System Failure & Gap Detector | Economic Intelligence Lead | Week 5 |
| SD-012 | E3: Opportunity Creation Engine | Opportunity Engineering Lead | Week 6 |
| SD-013 | E4: Economic Model & Validation Engine | Domain Expert / Quant | Week 6 |
| SD-014 | E5: Opportunity Deployment Engine | Deployment Lead | Week 6 |

**Gate**: All SD-010..014 **DESIGN REVIEWED & APPROVED**.

### Phase 1D: Module & Cross-Cutting Design (Weeks 6-7)

| Spec | Title | Owner | Target |
|------|-------|-------|--------|
| SD-020..028 | M1-M9 Module Specs | Backend Lead | Week 6 |
| SD-030..042 | Cross-Cutting Specs | Backend Lead / DevOps / AI / QA | Week 7 |

**Gate**: All SD-020..042 **DESIGN REVIEWED & APPROVED**.

### Phase 1E: UI/UX Design (Weeks 7-8)

| Spec | Title | Owner | Target |
|------|-------|-------|--------|
| SD-050..055 | Screen Specs (6 screens) | Frontend Lead | Week 7 |
| SD-056 | Design System & Component Library | Frontend Lead | Week 8 |

**Gate**: All SD-050..056 **DESIGN REVIEWED & APPROVED**.

### Stage 1 Exit Criteria
- [ ] All 10 technology decisions (PD-01..10) resolved with ADRs
- [ ] All 40+ specifications (SD-001..056) have approved design documents (SDD-XXX)
- [ ] Architecture Decision Records (ADR-0001+) documented
- [ ] Implementation task breakdown created with estimates
- [ ] Risk register updated

### Approval Required
**Lead Architect + Domain Expert + QA Lead + Product Owner**

---

## STAGE 2: CORE FOUNDATION — Phase 1 Implementation (Weeks 9-16)

### Objective
Build the foundational platform: auth, dashboard, canonical model, entity management, evidence management, task management.

### Implementation Sequence

| Sprint | Focus | Key Deliverables | Acceptance Tests |
|--------|-------|------------------|------------------|
| 1-2 | **Auth & Permissions** | OIDC/SAML, RBAC, session mgmt, audit log | Infra |
| 3-4 | **Dashboard (SD-050)** | Investigation list, opportunity status, evidence gaps, approvals | Infra |
| 5-6 | **Canonical Data Model (SD-001)** | 12 entities, relationships, indexes, migrations | Infra |
| 7-8 | **Entity/Market/Asset CRUD (SD-020)** | Full CRUD, search, import/export, entity resolution | Infra |
| 9-10 | **Source/Evidence Management (SD-024)** | Source registry, evidence ledger, claim registry, grading | Infra, AT-E partial |
| 11-12 | **Task Management** | Task CRUD, assignment, status, notifications | Infra |
| 13-14 | **Background Jobs (SD-033)** | Queue, workers, retry, scheduling, monitoring | Infra |
| 15-16 | **Integration & Hardening** | E2E tests, performance, security, docs | Infra |

### Stage 2 Exit Criteria
- [ ] All Phase 1 functional requirements (FR-M1 core, FR-M5 core) implemented
- [ ] Infrastructure acceptance tests pass
- [ ] Performance baselines established (NFR-PERF-001)
- [ ] Security review passed (NFR-SEC-001..004)
- [ ] Documentation complete for deployed features

### Approval Required
**Lead Architect + QA Lead + Product Owner**

---

## STAGE 3: OPPORTUNITY DISCOVERY — Phase 2 Implementation (Weeks 17-28)

### Objective
Implement guided search, market analysis, gap detection, relationship discovery, initial opportunity creation.

### Implementation Sequence

| Sprint | Focus | Key Deliverables | Acceptance Tests |
|--------|-------|------------------|------------------|
| 1-2 | **E1: Economic World Scanner (SD-010)** | Source connectors, ingestion, entity extraction, model build | AT-A partial |
| 3-4 | **M1: Market Investigation UI (SD-051)** | Market definition, scope, participants, resources, needs | AT-A |
| 5-6 | **E2: Gap Detector (SD-011)** | Value leakage, bottlenecks, unmet demand, capacity analysis | AT-A, AT-B |
| 7-8 | **M3: Gap Detection UI (SD-022)** | Gap registry, quantification, severity, evidence links | AT-A, AT-B |
| 9-10 | **Relationship Discovery** | Graph visualization, strength, evidence, missing links | AT-A |
| 11-12 | **E3: Opportunity Creation (SD-012)** | 6 pathways, pattern library, hypothesis builder | AT-B, AT-C partial |
| 13-14 | **M4: Opportunity Factory UI (SD-052)** | Opportunities, gaps, creation wizard, comparison | AT-B, AT-C |
| 15-16 | **Integration & Acceptance Tests A, B** | End-to-end discovery flow | AT-A, AT-B |

### Stage 3 Exit Criteria
- [ ] Acceptance Tests A & B **PASS**
- [ ] E1 scans pilot market in <30min (NFR-PERF-002)
- [ ] E2 detects gaps in <15min (NFR-PERF-003)
- [ ] E3 creates hypotheses in <10min (NFR-PERF-004)
- [ ] Evidence grades visible throughout (NFR-UX-002)
- [ ] Sector independence verified (NFR-UX-005)

### Approval Required
**Economic Intelligence Lead + Opportunity Engineering Lead + QA Lead + Product Owner**

---

## STAGE 4: CREATION & VALIDATION — Phase 3 Implementation (Weeks 29-44)

### Objective
Implement economic modeling, claim verification, assumption management, cost/revenue analysis, risk assessment, opportunity comparison, scoring.

### Implementation Sequence

| Sprint | Focus | Key Deliverables | Acceptance Tests |
|--------|-------|------------------|------------------|
| 1-3 | **E4: Economic Model Engine (SD-013)** | Financial equations, assumption framework, scenario engine | AT-C, AT-F |
| 4-5 | **M6: Modeling UI (SD-025)** | Model builder, assumption register, scenarios, sensitivity | AT-C, AT-F |
| 6-7 | **Claim Verification (SD-024)** | Evidence-to-claim, contradiction tracking, review workflow | AT-E |
| 8-9 | **Validation Workspace UI (SD-054)** | Claims, evidence, assumptions, contradictions, model, risk | AT-E, AT-F |
| 10-11 | **E4: Risk Assessment** | Tech, ops, market, legal, financial risk modules | AT-F |
| 12-13 | **E3/E4: Opportunity Comparison** | Side-by-side, dimension scoring, trade-offs | AT-C, AT-F |
| 14-15 | **E4/E5: Scoring Engine (SD-014, SD-026)** | 5-dimension scoring, critical failures, recommendations | AT-F, AT-G |
| 16 | **Integration & Acceptance Tests C, E, F, G** | End-to-end validation flow | AT-C, AT-E, AT-F, AT-G |

### Stage 4 Exit Criteria
- [ ] Acceptance Tests C, E, F, G **PASS**
- [ ] Financial models reproducible (NFR-DATA-001, FR-M6-016)
- [ ] Critical failure vetoes enforced (SR-SCORING-002)
- [ ] Decision audit trail complete (NFR-SEC-004, FR-M7-009)
- [ ] Human approval gates functional (SR-CONST-008)

### Approval Required
**Domain Expert/Quant + Validation Lead + QA Lead + Product Owner**

---

## STAGE 5: ASSET-TO-VALUE — Phase 4 Implementation (Weeks 45-56)

### Objective
Implement asset data ingestion, process analysis, unused capacity detection, waste identification, activity reconfiguration.

### Implementation Sequence

| Sprint | Focus | Key Deliverables | Acceptance Tests |
|--------|-------|------------------|------------------|
| 1-2 | **Asset Data Ingestion (SD-020, SD-053)** | Asset profiles, utilization, costs/outputs, evidence | AT-D |
| 3-4 | **Process Analysis** | Activity mapping, flow analysis, bottleneck detection | AT-D |
| 5-6 | **Unused Capacity Detection** | Capacity vs utilization, gap quantification | AT-D |
| 7-8 | **Waste Identification** | Waste streams, quantities, costs, recovery potential | AT-D |
| 9-10 | **Activity Reconfiguration** | Alternative flows, cost/benefit, implementation path | AT-D |
| 11-12 | **Improvement Opportunities** | Hypotheses tied to specific assets, quantified | AT-D |
| 13-14 | **Asset-to-Value UI (SD-053)** | Full workflow, evidence, comparison, export | AT-D |
| 15-16 | **Integration & Acceptance Test D** | End-to-end asset analysis flow | AT-D |

### Stage 5 Exit Criteria
- [ ] Acceptance Test D **PASS**
- [ ] Asset analysis produces quantified opportunities (AT-D criteria)
- [ ] Evidence traceability from asset to opportunity (NFR-UX-002)
- [ ] Integration with validation workspace (FR-M8)

### Approval Required
**Asset-to-Value Lead + QA Lead + Product Owner**

---

## STAGE 6: LEARNING & EXPANSION — Phase 5 Implementation (Weeks 57-68)

### Objective
Implement outcome tracking, prediction comparison, rule improvement, model recalibration, data source expansion.

### Implementation Sequence

| Sprint | Focus | Key Deliverables | Acceptance Tests |
|--------|-------|------------------|------------------|
| 1-2 | **Outcome Tracking (SD-028)** | Predicted vs actual for all parameters, automated comparison | AT-H partial |
| 3-4 | **Prediction vs Actual Engine** | Flagging, analysis, root cause, reporting | AT-H |
| 5-6 | **Discovery Rule Improvement** | Pattern success/failure, heuristic updates, versioning | AT-H |
| 7-8 | **Model Recalibration** | Financial params, evidence weights, automated retraining | AT-H |
| 9-10 | **Knowledge Updates** | Entity corrections, relationship updates, source re-rating | AT-H |
| 11-12 | **Data Source Expansion** | New source onboarding, quality assessment, integration | AT-H |
| 13-14 | **Market/Language Expansion** | i18n, new market onboarding templates | AT-H |
| 15-16 | **Automation Assessment** | Proven automation identification, human-in-the-loop boundaries | AT-H |
| 17-18 | **Integration & Acceptance Test H** | End-to-end learning flow | AT-H |

### Stage 6 Exit Criteria
- [ ] Acceptance Test H **PASS**
- [ ] Learning loop operational (predictions -> outcomes -> improvements)
- [ ] Sector independence verified (new sector onboarded without code changes)
- [ ] Automation boundaries documented and enforced

### Approval Required
**Learning Engine Lead + QA Lead + Product Owner**

---

## STAGE 7: PRODUCTION HARDENING (Weeks 69-76)

### Objective
Production readiness: performance, security, observability, backup/DR, documentation.

### Focus Areas

| Area | Target |
|------|--------|
| Performance | All NFR-PERF targets met under load |
| Security | Penetration test passed; audit logs tamper-proof |
| Observability | Dashboards, alerts, SLOs defined and monitored |
| Backup/DR | RPO <1hr, RTO <4hr tested and documented |
| Documentation | Architecture, API, user guide, runbooks complete |
| Cost Management | LLM budgets, API quotas monitored and alerting |

### Final Exit Criteria
- [ ] All 8 Acceptance Tests (A-H) **PASS** in production-like environment
- [ ] All NFR targets met
- [ ] Security audit passed
- [ ] DR test successful
- [ ] Documentation complete
- [ ] Cost monitoring operational

### Approval Required
**Lead Architect + DevOps + Security + QA Lead + Product Owner**

---

## MILESTONE SUMMARY

| Milestone | Target Week | Approval Gate |
|-----------|-------------|---------------|
| M0: Foundation Complete | 2 | Product Owner + Lead Architect + Domain Expert |
| M1: Architecture & Design Complete | 8 | Lead Architect + Domain Expert + QA Lead + Product Owner |
| M2: Core Foundation (Phase 1) | 16 | Lead Architect + QA Lead + Product Owner |
| M3: Opportunity Discovery (Phase 2) | 28 | EI Lead + OE Lead + QA Lead + Product Owner |
| M4: Creation & Validation (Phase 3) | 44 | Domain Expert + Validation Lead + QA Lead + Product Owner |
| M5: Asset-to-Value (Phase 4) | 56 | Asset Lead + QA Lead + Product Owner |
| M6: Learning & Expansion (Phase 5) | 68 | Learning Lead + QA Lead + Product Owner |
| M7: Production Ready | 76 | Lead Architect + DevOps + Security + QA Lead + Product Owner |

---

## RESOURCE ESTIMATES (Indicative)

| Role | Stage 1 | Stage 2 | Stage 3 | Stage 4 | Stage 5 | Stage 6 | Stage 7 |
|------|---------|---------|---------|---------|---------|---------|---------|
| Lead Architect | 1.0 | 0.5 | 0.3 | 0.3 | 0.2 | 0.2 | 0.5 |
| Data Architect | 1.0 | 0.5 | 0.2 | 0.2 | 0.1 | 0.1 | 0.2 |
| Backend Lead | 0.5 | 1.0 | 1.0 | 1.0 | 1.0 | 0.5 | 0.5 |
| Frontend Lead | 0.5 | 1.0 | 1.0 | 1.0 | 1.0 | 0.5 | 0.3 |
| Economic Intelligence Lead | 0.5 | 0.2 | 1.0 | 0.5 | 0.3 | 0.2 | 0.1 |
| Opportunity Engineering Lead | 0.5 | 0.2 | 1.0 | 1.0 | 0.5 | 0.2 | 0.1 |
| Domain Expert / Quant | 0.3 | 0.2 | 0.3 | 1.0 | 0.3 | 0.3 | 0.2 |
| AI Systems Engineer | 0.5 | 0.3 | 0.5 | 0.5 | 0.3 | 0.5 | 0.3 |
| DevOps | 0.3 | 0.5 | 0.3 | 0.3 | 0.2 | 0.2 | 1.0 |
| QA Lead | 0.3 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 |
| Product Owner | 0.5 | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 |
| **Total FTE** | **6.2** | **6.2** | **6.7** | **6.9** | **5.9** | **4.5** | **4.9** |

---

## RISK REGISTER (Top Risks)

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| PD-01..07 decisions delayed | High | High | Time-boxed decision process; fallback options documented |
| Entity resolution accuracy <95% | Medium | High | Invest in PD-08 early; human review workflow |
| Financial model reproducibility fails | Low | Critical | Deterministic engine (SD-013); extensive test suite |
| AI cost overruns | Medium | High | Token budgets (NFR-AI-002); caching; model selection |
| Sector independence not achieved | Medium | High | C4, C7 addressed in design; pattern library extensibility |
| Team capacity insufficient | Medium | High | Phased hiring; contractor options; scope flexibility |

---

## DOCUMENT CONTROL

| Field | Value |
|-------|-------|
| **Document ID** | OF-RM-001 |
| **Version** | 1.0 (Draft) |
| **Status** | Under Review |
| **Owner** | Lead Architect |
| **Reviewers** | Product Owner, Technical Lead, Domain Expert, QA Lead |
| **Approval Required** | **Yes — Before Stage 1 Begins** |

---

**END OF ROADMAP**

*This roadmap is a living document. Dates are estimates; approval gates are mandatory. Scope changes require formal change request with impact analysis.*
