with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# Fix the _is_negated function to use _normalize_analysis
old_code = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\\w){re.escape(_normalize(alias))}"
            rf"(?:\\s+\\w+){{0,6}}\\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES_ANALYSIS
    )"""

new_code = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\\w){re.escape(_normalize_analysis(alias))}"
            rf"(?:\\s+\\w+){{0,6}}\\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES_ANALYSIS
    )"""

content = content.replace(old_code, new_code)
print("Fix applied!")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)
