with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Update SEMANTIC_RULE_VERSION
content = content.replace(
    "SEMANTIC_RULE_VERSION = \"OF-SEMANTIC-RULES-0.2\"",
    "SEMANTIC_RULE_VERSION = \"OF-SEMANTIC-RULES-0.3\""
)

# 2. Update NEGATION_ALIASES
old_negation = """NEGATION_ALIASES = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "sin",
    "no existe",
    "لا",
    "ليس",
    "بدون",
    "غير",
)"""

new_negation = """NEGATION_ALIASES = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "absent",
    "devoid of",
    "free from",
    "no sign of",
    "no evidence of",
    "does not have",
    "does not operate",
    "does not exist",
    "is not",
    "are not",
    "was not",
    "were not",
    "has no",
    "have no",
    "had no",
    "without any",
    "sin",
    "no hay",
    "no existe",
    "no hay evidencia",
    "sin evidencia",
    "لا",
    "ليس",
    "بدون",
    "غير",
    "لا يوجد",
    "ليس هناك",
    "لا دليل على",
    "غير متوفر",
    "ما في",
    "ما فيه",
    "ماكو",
    "موجودش",
    "لا يوجد",
    "nicht",
    "kein",
    "keine",
    "keiner",
    "keines",
    "ohne",
    "fehlt",
)"""

content = content.replace(old_negation, new_negation)

# 3. Update HYPOTHETICAL_MARKERS
old_hypothetical = """HYPOTHETICAL_MARKERS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
)"""

new_hypothetical = """HYPOTHETICAL_MARKERS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
    "projected",
    "forecast",
    "scenario analysis",
    "what if",
    "suppose",
    "supposing",
    "assuming",
    "in theory",
    "theoretically",
    "on paper",
    "envisage",
    "envision",
    "contemplate",
    "consider",
    "explore",
    "investigate",
    "evaluate",
    "assess",
    "دراسة",
    "تحليل",
    "سيناريو",
    "افتراض",
    "مقترح",
    "توقع",
    "مشروط",
    "في حال",
    "لو",
    "في حالة",
    "si",
    "caso",
    "supongamos",
    "hipotéticamente",
    "proyectado",
    "pronóstico",
    "análisis de escenario",
)"""

content = content.replace(old_hypothetical, new_hypothetical)

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("All initial patches applied successfully!")
