# ADR-002: 12 Canonical Entities

**Status**: ACCEPTED
**Date**: 2026-11-08
**Deciders**: Data Architect, Domain Expert, Lead Architect

## Context
The system needs a unified data model that can represent any economic activity globally without sector-specific schemas. The model must support both Market-to-Opportunity and Asset-to-Value directions.

## Decision
Define 12 canonical entities as the single source of truth:
1. Market
2. Sector
3. Entity (economic participant)
4. Asset
5. Activity
6. Product & Service
7. Need & Demand
8. Problem & Gap
9. Relationship
10. Source & Evidence
11. Claim
12. Opportunity (central output)

All entities have UUIDs, temporal validity, source traceability, multi-lingual support, soft deletes, and JSONB extensibility.

## Options Considered
| Option | Pros | Cons |
|--------|------|------|
| 12 Canonical Entities | Unified, extensible, supports both directions, global scope | Requires careful design to avoid over-generalization |
| Sector-specific schemas | Tailored to each domain | Not global, maintenance nightmare, violates sector independence |
| EAV (Entity-Attribute-Value) | Maximum flexibility | Query complexity, performance, loss of schema enforcement |

## Consequences
- **Positive**: Single model for all economic analysis; pathway logic works on same entities; sector independence achievable
- **Negative**: Some entities may have sparse attributes for certain sectors; JSONB fields need governance
- **Follow-up**: Define physical schema (SD-001); entity resolution rules (SD-002); ontology (SD-003)

## Affected Specifications
- SD-001..008 (core data specs)
- SD-020..028 (all modules)
- All engine specs (SD-010..014)

## Related Conflicts
- C4: Model Extensibility vs. Stability (JSONB + fixed core)
- C7: Sector Independence vs. Domain Knowledge (core + extensions)

---
*Approved at Gate 0 by Data Architect, Domain Expert, Lead Architect*
