with open("LEAD_ARCHITECT_GATE0_ASSESSMENT.md", "r", encoding="utf-8") as f:
    content = f.read()

# Fix 1: Change "7 Medium" to "6 Medium" in the finding count table
old1 = """| Finding Category | Count |
|------------------|-------|
| **Critical** (Gate 0 Blockers) | 0 |
| **High** (Must Resolve Before Stage 1 Implementation) | 3 |
| **Medium** (Should Resolve During Stage 1 Design) | 7 |
| **Low** (Documentation/Process Improvements) | 5 |"""

new1 = """| Finding Category | Count |
|------------------|-------|
| **Critical** (Gate 0 Blockers) | 0 |
| **High** (Must Resolve Before Stage 1 Implementation) | 3 |
| **Medium** (Should Resolve During Stage 1 Design) | 6 |
| **Low** (Documentation/Process Improvements) | 5 |"""

# Fix 2: Change "four HIGH-severity conditions (LA-01, LA-02, LA-03, plus LA-10/11/12 documentation corrections)" to "three HIGH-severity conditions (LA-01, LA-02, LA-03)"
old2 = "the four HIGH-severity conditions (LA-01, LA-02, LA-03, plus LA-10/11/12 documentation corrections)"
new2 = "the three HIGH-severity conditions (LA-01, LA-02, LA-03)"

# Fix 3: Also update the reference to "four HIGH-severity conditions" in the Stage 1 Authorization section
old3 = "Conditions LA-01, LA-02, LA-03 are acknowledged as mandatory Stage 1 design requirements"
new3 = "Conditions LA-01, LA-02, LA-03 are acknowledged as mandatory Stage 1 design requirements"

content = content.replace(old1, new1)
content = content.replace(old2, new2)

with open("LEAD_ARCHITECT_GATE0_ASSESSMENT.md", "w", encoding="utf-8") as f:
    f.write(content)

print("Done")
