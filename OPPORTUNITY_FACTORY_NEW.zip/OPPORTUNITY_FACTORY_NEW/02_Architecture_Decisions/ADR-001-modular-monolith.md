# ADR-001: Modular Monolith Architecture

**Status**: ACCEPTED
**Date**: 2026-11-08
**Deciders**: Lead Architect, Data Architect, Domain Expert

## Context
OPPORTUNITY FACTORY v1 needs an architecture that balances simplicity, maintainability, and future extensibility. The system must support 5 disciplines, 9 modules, 5 engines, and 12 entities without premature distributed system complexity.

## Decision
Adopt a **Modular Monolith** architecture: a single deployable unit organized into clear internal modules with well-defined boundaries. Modules communicate via internal interfaces, not network calls. Extraction to microservices is deferred until scale demands it.

## Options Considered
| Option | Pros | Cons |
|--------|------|------|
| Modular Monolith | Simple dev/ops, easy debugging, low cost, testable, extractable later | Single point of failure, scaling limits |
| Microservices | Independent scaling, team autonomy, tech diversity | High complexity, distributed debugging, operational overhead, premature for v1 |
| Serverless Functions | Auto-scaling, pay-per-use | Cold starts, vendor lock-in, debugging difficulty, not suited for long-running AI/analysis jobs |

## Consequences
- **Positive**: Faster initial development, simpler testing, lower infrastructure cost, clear module boundaries for future extraction
- **Negative**: All modules share process; memory/CPU issues affect all; deployment is all-or-nothing
- **Follow-up**: Define module interfaces as if they were service contracts; use dependency injection; document extraction criteria

## Affected Specifications
- All SD-030..042 (cross-cutting)
- All SD-020..028 (modules)
- SD-050..056 (UI specs)

## Related Conflicts
- C4: Model Extensibility vs. Stability (module boundaries support this)
- C8: Single-User MVP vs. Multi-User Architecture (monolith simplifies v1 auth)

---
*Approved at Gate 0 by Lead Architect, Data Architect, Domain Expert*
