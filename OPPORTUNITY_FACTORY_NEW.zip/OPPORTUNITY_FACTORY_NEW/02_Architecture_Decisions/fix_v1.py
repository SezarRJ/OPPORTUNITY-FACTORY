with open("LEAD_ARCHITECT_GATE0_ASSESSMENT.md", "r", encoding="utf-8") as f:
    content = f.read()

# Find the V1 Source Documents section and enhance it
old = """### 2.4 V1 Source Documents (Noted -- Not Directly Inspected)

The 15 V1 DOCX files at D:\\\\مصنع الفرص\\\\*.docx were **not directly inspected** as they are binary documents. This assessment references them only as reported in the foundation documents. Where V2 claims V1 preservation, I note "V1 source not independently verified.""""

new = """### 2.4 V1 Source Documents (Noted -- Not Directly Inspected)

**Exact Inventory (15 files verified at D:\\\\مصنع الفرص\\\\*.docx on 2026-11-08):**

| # | Filename | Size (bytes) | Last Modified |
|---|----------|--------------|---------------|
| 1 | CANONICAL DATA MODEL.docx | 28,821 | 2026-11-08 10:42:38 |
| 2 | DATA & INTELLIGENCE SPECIFICATION.docx | 66,212 | 2026-11-08 10:35:44 |
| 3 | ECONOMIC ONTOLOGY & RELATIONSHIP SCHEMA.docx | 28,614 | 2026-11-08 10:46:56 |
| 4 | EVIDENCE, CLAIM & VALIDATION SCHEMA.docx | 31,029 | 2026-11-08 10:48:31 |
| 5 | GLOBAL ECONOMIC SIGNALS & CHANGE DETECTION ENGINE.docx | 28,751 | 2026-11-08 11:35:34 |
| 6 | GLOBAL MARKET & COUNTRY INTELLIGENCE ENGINE.docx | 39,305 | 2026-11-08 11:31:05 |
| 7 | Global Opportunity Factory Concept -- Final Master Concept.docx | 53,528 | 2026-11-08 10:27:47 |
| 8 | LEARNING, CALIBRATION & CONTINUOUS EVOLUTION ENGINE.docx | 34,279 | 2026-11-08 11:34:24 |
| 9 | MASTER DEVELOPMENT PROMPT.docx | 44,840 | 2026-11-08 11:51:53 |
| 10 | MVP SCOPE & ACCEPTANCE TEST PLAN.docx | 44,310 | 2026-11-08 11:03:59 |
| 11 | OPPORTUNITY DISCOVERY METHODOLOGY.docx | 47,363 | 2026-11-08 11:19:37 |
| 12 | OPPORTUNITY SCORING & DECISION ENGINE.docx | 37,272 | 2026-11-08 11:26:13 |
| 13 | SYSTEM ARCHITECTURE & TECHNICAL IMPLEMENTATION PLAN.docx | 37,361 | 2026-11-08 10:57:59 |
| 14 | System Architecture, Business & Operational Specifications.docx | 46,554 | 2026-11-08 10:28:23 |
| 15 | Version 1.0 -- Core Application Functions & User Workflows.docx | 40,845 | 2026-11-08 10:51:04 |

**Total: 15 files, ~642 KB**

**Limitation Statement:**
These 15 V1 DOCX files were **not directly inspected** (binary format). This assessment references them only as reported in the foundation documents. Where V2 claims V1 preservation, I note "V1 source not independently verified."

**Do Not Claim:**
- All V1 requirements have been verified.
- V1-to-V2 preservation has been confirmed.
- The seven Economic Hard Gates have been fully specified and verified against V1 source.
- All scoring, methodology-versioning, and learning requirements have been validated against V1.

These matters require the Domain Expert assessment and examination of the original V1 source documents."""

content = content.replace(old, new)

with open("LEAD_ARCHITECT_GATE0_ASSESSMENT.md", "w", encoding="utf-8") as f:
    f.write(content)

print("Done")
