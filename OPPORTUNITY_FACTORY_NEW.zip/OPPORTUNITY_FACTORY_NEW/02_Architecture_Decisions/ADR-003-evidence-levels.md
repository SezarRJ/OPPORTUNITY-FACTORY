# ADR-003: Evidence Levels E0-E4

**Status**: ACCEPTED
**Date**: 2026-11-08
**Deciders**: Domain Expert, Lead Architect, Economic Intelligence Lead

## Context
The system must distinguish between verified facts, corroborated information, assumptions, and AI-generated hypotheses. Users must see what is known vs. inferred vs. assumed.

## Decision
Adopt five evidence levels:

| Level | Label | Definition | Use in Decision |
|-------|-------|------------|-----------------|
| E0 | Signal / Hypothesis | Unverified lead, AI pattern, user intuition | Starting point only |
| E1 | Single Source | One document, database, interview | Exploration only |
| E2 | Corroborated | Multiple independent sources agreeing | Assumption registration |
| E3 | Independently Verified | Field check, primary data, audited records | Required for critical claims |
| E4 | Field-Tested / Outcome-Verified | Actual pilot/deployment results | Highest confidence |

Core components: Source Registry, Evidence Ledger (immutable), Claim Registry, Contradiction Tracking, Missing Evidence Registry.

Validation Rules:
1. Material claims >= E2 or explicit assumption
2. Critical claims (revenue, regulatory, technical) >= E3
3. Contradictions displayed, not hidden
4. Assumptions registered with owner, rationale, test plan
5. Financial models show sensitivity to each assumption
6. No advancement past Validated state without passing gates

## Options Considered
| Option | Pros | Cons |
|--------|------|------|
| 5-level E0-E4 | Granular, honest, actionable | More complex than binary verified/unverified |
| Binary (verified/unverified) | Simple | Loses nuance, hides assumption risk |
| Confidence scores (0-100) | Quantitative | False precision, not actionable for gates |

## Consequences
- **Positive**: Evidence honesty; users see gaps; gates enforce rigor; AI constrained
- **Negative**: Slower discovery; more data entry; E3/E4 require field work
- **Follow-up**: Define evidence ledger schema (SD-004); claim registry (SD-005); source registry (SD-006); thresholds per claim type (SD7)

## Affected Specifications
- SD-004..006 (evidence/claim/source schemas)
- SD-024 (M5 Evidence & Claim Management)
- SD-025 (M6 Economic Modeling)
- SD-026 (M7 Scoring & Decision)
- All engine specs (evidence requirements)

## Related Conflicts
- C3: Evidence Rigor vs. Discovery Speed (thresholds per claim type)

---
*Approved at Gate 0 by Domain Expert, Lead Architect, Economic Intelligence Lead*
