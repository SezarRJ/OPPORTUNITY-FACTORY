import base64

with open("semantic_full_b64.txt", "r") as f:
    encoded = f.read()
content = base64.b64decode(encoded).decode("utf-8")
with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)
print("semantic.py written")