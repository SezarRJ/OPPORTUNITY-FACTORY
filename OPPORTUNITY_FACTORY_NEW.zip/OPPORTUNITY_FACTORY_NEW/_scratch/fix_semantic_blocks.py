"""Rebuild NEGATION_ALIASES and HYPOTHETICAL_MARKERS in app/services/semantic.py.

The recovered entries were decoded from the mangled block and cross-checked
against the clean copies in app/services/analysis.py
(NEGATION_ALIASES_ANALYSIS / HYPOTHETICAL_MARKERS_ANALYSIS).
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

SEMANTIC = Path("app/services/semantic.py")
ANALYSIS = Path("app/services/analysis.py")

NEGATION_ALIASES = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "absent",
    "devoid of",
    "free from",
    "no sign of",
    "no evidence of",
    "does not have",
    "does not operate",
    "does not exist",
    "is not",
    "are not",
    "was not",
    "were not",
    "has no",
    "have no",
    "had no",
    "without any",
    "sin",
    "no hay",
    "no existe",
    "no hay evidencia",
    "sin evidencia",
    "لا",
    "ليس",
    "بدون",
    "غير",
    "لا يوجد",
    "ليس هناك",
    "لا دليل على",
    "غير متوفر",
    "ما في",
    "ما فيه",
    "ماكو",
    "موجودش",
    "لا يوجد",
    "nicht",
    "kein",
    "keine",
    "keiner",
    "keines",
    "ohne",
    "fehlt",
    "not true that",
    "it is not true that",
    "it is not the case that",
    "it is false that",
    "contrary to",
    "despite",
    "although",
    "even though",
    "however",
    "but",
    "except",
    "except for",
    "other than",
    "rather than",
    "instead of",
    "لا يوجد",
    "لا صحة",
    "غير صحيح",
    "ليس صحيح",
    "خطأ",
    "كذب",
    "عكس",
    "على عكس",
    "رغم",
    "على الرغم",
    "ولكن",
    "سوى",
    "ما عدا",
    "بدل",
    "instead of",
    "no es cierto",
    "es falso",
    "contrario",
    "a pesar de",
    "aunque",
    "sin embargo",
    "pero",
    "excepto",
    "salvo",
    "en lugar de",
    "nicht wahr",
    "falsch",
    "entgegen",
    "trotz",
    "obwohl",
    "jedoch",
    "aber",
    "außer",
    "statt",
)

HYPOTHETICAL_MARKERS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
    "projected",
    "forecast",
    "scenario analysis",
    "what if",
    "suppose",
    "supposing",
    "assuming",
    "in theory",
    "theoretically",
    "on paper",
    "envisage",
    "envision",
    "contemplate",
    "consider",
    "explore",
    "investigate",
    "evaluate",
    "assess",
    "دراسة",
    "تحليل",
    "سيناريو",
    "افتراض",
    "مقترح",
    "توقع",
    "مشروط",
    "في حال",
    "لو",
    "في حالة",
    "si",
    "caso",
    "supongamos",
    "hipotéticamente",
    "proyectado",
    "pronóstico",
    "análisis de escenario",
    "maybe",
    "perhaps",
    "possibly",
    "likely",
    "probable",
    "conceivable",
    "imaginable",
    "think",
    "believe",
    "suggest",
    "propose",
    "recommend",
    "might be",
    "could be",
    "would be",
    "should",
    "ought to",
    "ربّما",
    "ربما",
    "محتمل",
    "متوقع",
    "يمكن",
    "قد",
    "ظن",
    "أعتقد",
    "أظن",
    "أتصور",
    "tal vez",
    "quizás",
    "posiblemente",
    "probablemente",
    "concebible",
    "imaginable",
    "creo",
    "pienso",
    "sugiero",
    "propongo",
    "recomiendo",
    "podría ser",
    "debería",
    "vielleicht",
    "möglicherweise",
    "wahrscheinlich",
    "denkbar",
    "vorstellbar",
    "glaube",
    "denke",
    "schlage vor",
    "empfehle",
    "könnte sein",
    "sollte",
)


def build_tuple_block(name: str, entries: tuple[str, ...]) -> str:
    lines = [f"{name} = ("]
    lines.extend(f'    "{entry}",' for entry in entries)
    lines.append(")")
    return "\r\n".join(lines)


def analysis_constants() -> dict[str, tuple[str, ...]]:
    tree = ast.parse(ANALYSIS.read_text(encoding="utf-8"))
    found: dict[str, tuple[str, ...]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id in (
                "NEGATION_ALIASES_ANALYSIS",
                "HYPOTHETICAL_MARKERS_ANALYSIS",
            ):
                found[target.id] = ast.literal_eval(node.value)
    return found


def main() -> int:
    reference = analysis_constants()
    if len(reference) != 2:
        print(f"FAILED: could not read analysis.py reference constants: {sorted(reference)}")
        return 1

    # Every entry of the clean analysis.py lists must appear in the rebuilt
    # semantic.py lists in the same relative order. Extra duplicate occurrences
    # (the original file repeats a few aliases) are allowed after the prefix.
    for ref_name, rebuilt in (
        ("NEGATION_ALIASES_ANALYSIS", NEGATION_ALIASES),
        ("HYPOTHETICAL_MARKERS_ANALYSIS", HYPOTHETICAL_MARKERS),
    ):
        ref_entries = reference[ref_name]
        rebuilt_filtered = [entry for entry in rebuilt if entry in set(ref_entries)]
        if rebuilt_filtered[: len(ref_entries)] != list(ref_entries):
            print(f"FAILED: {ref_name} prefix mismatch.")
            for index, expected in enumerate(ref_entries):
                actual = (
                    rebuilt_filtered[index]
                    if index < len(rebuilt_filtered)
                    else None
                )
                if expected != actual:
                    print(f"  position {index}: expected {expected!r} got {actual!r}")
                    break
            return 1
        extras = rebuilt_filtered[len(ref_entries):]
        print(
            f"prefix check ok: {ref_name} ({len(ref_entries)} shared entries, "
            f"{len(extras)} duplicate occurrence(s) allowed)"
        )

    source = SEMANTIC.read_text(encoding="utf-8", newline="")
    start = source.index("NEGATION_ALIASES = (")
    end = source.index("GENERALIZED_REGEX_RULES = (")
    corrupted_region = source[start:end]
    control_chars = {
        char
        for char in corrupted_region
        if ord(char) < 32 and char not in ("\r", "\n", "\t")
    }
    print(f"corrupted region: {len(corrupted_region)} chars, "
          f"control chars present: {sorted(map(hex, map(ord, control_chars)))}")

    replacement = (
        build_tuple_block("NEGATION_ALIASES", NEGATION_ALIASES)
        + "\r\n\r\n"
        + build_tuple_block("HYPOTHETICAL_MARKERS", HYPOTHETICAL_MARKERS)
        + "\r\n\r\n"
    )
    fixed = source[:start] + replacement + source[end:]

    compile(fixed, str(SEMANTIC), "exec")  # raises on any syntax error
    SEMANTIC.write_text(fixed, encoding="utf-8", newline="")
    print(f"semantic.py rewritten: {len(source)} -> {len(fixed)} chars")

    check = SEMANTIC.read_text(encoding="utf-8")
    remaining = [
        (number, repr(line))
        for number, line in enumerate(check.splitlines(), start=1)
        if any(ord(char) < 32 and char not in ("\t",) for char in line)
    ]
    if remaining:
        print(f"FAILED: {len(remaining)} lines still contain control characters:")
        for number, line in remaining[:5]:
            print(f"  {number}: {line[:90]}")
        return 1
    print("no control characters remain")
    return 0


if __name__ == "__main__":
    sys.exit(main())
