"""Print shared-entry sequences with indices to locate the order mismatch."""

from __future__ import annotations

import ast
import sys
from pathlib import Path

sys.path.insert(0, "_scratch")
from fix_semantic_blocks import NEGATION_ALIASES, HYPOTHETICAL_MARKERS  # noqa: E402

ANALYSIS = Path("app/services/analysis.py")


def constants() -> dict[str, tuple[str, ...]]:
    tree = ast.parse(ANALYSIS.read_text(encoding="utf-8"))
    found: dict[str, tuple[str, ...]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if (
                isinstance(target, ast.Name)
                and target.id
                in ("NEGATION_ALIASES_ANALYSIS", "HYPOTHETICAL_MARKERS_ANALYSIS")
                and isinstance(node.value, ast.Tuple)
            ):
                found[target.id] = ast.literal_eval(node.value)
    return found


for name, rebuilt in (
    ("NEGATION", NEGATION_ALIASES),
    ("HYPOTHETICAL", HYPOTHETICAL_MARKERS),
):
    ref_name = f"{name}_ALIASES_ANALYSIS" if name == "NEGATION" else f"{name}_MARKERS_ANALYSIS"
    ref = constants()[ref_name]
    ref_set = set(ref)
    rebuilt_set = set(rebuilt)
    shared_ref = [entry for entry in ref if entry in rebuilt_set]
    shared_rebuilt = [entry for entry in rebuilt if entry in ref_set]
    print(f"=== {name}: shared_ref={len(shared_ref)} shared_rebuilt={len(shared_rebuilt)}")
    for index, entry in enumerate(shared_rebuilt):
        marker = ""
        if index < len(shared_ref) and shared_ref[index] != entry:
            marker = f"   <-- ref[{index}]={shared_ref[index]!r}"
        if marker or entry not in shared_ref[: len(shared_ref)]:
            pass
        print(f"  rebuilt_shared[{index}] = {entry!r}{marker}")
