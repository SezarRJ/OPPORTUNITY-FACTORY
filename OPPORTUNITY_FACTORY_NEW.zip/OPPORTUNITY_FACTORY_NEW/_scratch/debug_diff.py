"""Debug: compare analysis.py reference constants with the rebuilt lists."""

from __future__ import annotations

import ast
import sys
from pathlib import Path

sys.path.insert(0, "_scratch")
from fix_semantic_blocks import NEGATION_ALIASES, HYPOTHETICAL_MARKERS  # noqa: E402

ANALYSIS = Path("app/services/analysis.py")


def constants() -> dict[str, tuple[str, ...]]:
    tree = ast.parse(ANALYSIS.read_text(encoding="utf-8"))
    found: dict[str, tuple[str, ...]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if (
                isinstance(target, ast.Name)
                and target.id
                in ("NEGATION_ALIASES_ANALYSIS", "HYPOTHETICAL_MARKERS_ANALYSIS")
                and isinstance(node.value, ast.Tuple)
            ):
                found[target.id] = ast.literal_eval(node.value)
    return found


def diff(name: str, rebuilt: tuple[str, ...], ref: tuple[str, ...]) -> None:
    print(f"--- {name}: ref={len(ref)} rebuilt={len(rebuilt)}")
    rebuilt_set = set(rebuilt)
    ref_set = set(ref)
    missing = [entry for entry in ref if entry not in rebuilt_set]
    extra = [entry for entry in rebuilt if entry not in ref_set]
    if missing:
        print("  missing from rebuilt:")
        for entry in missing:
            print(f"    {entry!r}")
    if extra:
        print("  not in reference (expected for semantic.py extras):")
        for entry in extra:
            print(f"    {entry!r}")
    # order check on shared entries
    shared_ref = [entry for entry in ref if entry in rebuilt_set]
    shared_rebuilt = [entry for entry in rebuilt if entry in ref_set]
    if shared_ref != shared_rebuilt:
        print("  ORDER MISMATCH")
        for expected, actual in zip(shared_ref, shared_rebuilt):
            if expected != actual:
                print(f"    expected {expected!r} got {actual!r}")


refs = constants()
diff("NEGATION", NEGATION_ALIASES, refs.get("NEGATION_ALIASES_ANALYSIS", ()))
diff("HYPOTHETICAL", HYPOTHETICAL_MARKERS, refs.get("HYPOTHETICAL_MARKERS_ANALYSIS", ()))
