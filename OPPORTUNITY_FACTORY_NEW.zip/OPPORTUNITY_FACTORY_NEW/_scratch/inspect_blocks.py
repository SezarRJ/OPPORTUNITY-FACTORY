"""Recover the two corrupted tuples in app/services/semantic.py.

Corruption model observed in the file:
  '"'  -> '\\'                    (a quote became a lone backslash)
  ' '  -> newline                 (spaces inside an entry became line breaks)
  then one Python unescape pass ran, so '\\a' '\\b' '\\f' '\\v' '\\n'
  turned into control characters BEL, BS, FF, VT, LF, eating the letter.
"""

from __future__ import annotations

import sys
from pathlib import Path

SEMANTIC = Path("app/services/semantic.py")

CTRL_MAP = {
    "\x07": '"a',
    "\x08": '"b',
    "\x0b": '"v',
    "\x0c": '"f',
    "\x09": '"t',
}


def decode_entry(raw: str) -> str:
    text = raw
    for control, replacement in CTRL_MAP.items():
        text = text.replace(control, replacement)
    text = text.replace("\\,", "\x00SEP\x00")
    text = text.replace("\\", '"')
    text = text.replace("\r", "")
    text = text.replace("\n", " ")
    text = text.replace("\x00SEP\x00", "\\,")
    return " ".join(text.split())


def extract_block(source: str, header: str) -> tuple[int, int, list[str]]:
    start = source.index(header)
    tail = source[start:]
    end = tail.index("\n)") + 3
    body = tail[len(header):end]
    entries: list[str] = []
    for raw in body.split("\\,"):
        candidate = raw.strip()
        if not candidate or candidate == ")":
            continue
        entries.append(decode_entry(candidate))
    return start, start + end, entries


def main() -> int:
    source = SEMANTIC.read_text(encoding="utf-8")
    for header in ("NEGATION_ALIASES = (", "HYPOTHETICAL_MARKERS = ("):
        start, end, entries = extract_block(source, header)
        print(f"=== {header} lines {source[:start].count(chr(10)) + 1}"
              f"-{source[:end].count(chr(10)) + 1} ({len(entries)} entries) ===")
        for entry in entries:
            print(repr(entry))
        print()

    controls = [
        (number, repr(line))
        for number, line in enumerate(source.splitlines(), start=1)
        if any(ord(char) < 32 and char != "\t" for char in line)
    ]
    print(f"lines with control characters: {len(controls)}")
    for number, line in controls[:10]:
        print(f"  {number}: {line[:90]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
