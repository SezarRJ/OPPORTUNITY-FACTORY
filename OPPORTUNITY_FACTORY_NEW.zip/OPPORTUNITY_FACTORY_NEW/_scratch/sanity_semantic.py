"""Sanity check the repaired semantic module and run the interpret path."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.services import semantic  # noqa: E402


def main() -> int:
    print("version:", semantic.SEMANTIC_RULE_VERSION)
    print("negation aliases:", len(semantic.NEGATION_ALIASES))
    print("hypothetical markers:", len(semantic.HYPOTHETICAL_MARKERS))
    print("negation sample:", semantic.NEGATION_ALIASES[:3], "...", semantic.NEGATION_ALIASES[-3:])
    print("hypothetical sample:", semantic.HYPOTHETICAL_MARKERS[:3], "...", semantic.HYPOTHETICAL_MARKERS[-3:])

    result = semantic.interpret_economic_context(
        investigation={
            "title": "Idle capacity at the mill",
            "activity": "grain milling",
            "sources": [],
            "claims": [
                {"id": "C1", "text": "If the plant were operating below capacity, we could add products."}
            ],
        },
        metrics=[],
        entities=[],
        relationships=[],
        economic_model={},
    )
    print("concepts:", sorted(result["concepts"]))
    print("suppressed:", len(result["suppressed_candidates"]))
    negated = semantic.interpret_economic_context(
        investigation={
            "title": "No idle capacity case",
            "sources": [],
            "claims": [
                {"id": "C1", "text": "The facility has NO idle capacity; all lines run at maximum."},
                {"id": "C2", "text": "It is not true that there is no unmet demand; customers seek alternatives."},
            ],
        },
        metrics=[],
        entities=[],
        relationships=[],
        economic_model={},
    )
    print("negated case concepts:", sorted(negated["concepts"]))
    print("negated case suppressed:", len(negated["suppressed_candidates"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
