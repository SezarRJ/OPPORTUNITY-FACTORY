from __future__ import annotations

import re
from math import isfinite
from datetime import date
from typing import Any

from .semantic import interpret_economic_context


METHODOLOGY_VERSION = "OF-V2-MVP-0.1"
RULESET_VERSION = "OF-RULES-0.1"
ENGINE_VERSION = "E1-E5-MVP-0.1"

EVIDENCE_LEVELS = ("E0", "E1", "E2", "E3", "E4")
EVIDENCE_SCORES = {level: index for index, level in enumerate(EVIDENCE_LEVELS)}

HARD_GATES = (
    (
        "HG-1",
        "Legal Permission",
        ("licensed", "lawfully permitted", "legal approval"),
        ("illegal", "not permitted", "no legal", "prohibited"),
    ),
    (
        "HG-2",
        "Economic Mechanism",
        ("viable mechanism", "value creation mechanism", "economic mechanism exists"),
        ("no mechanism", "not viable", "no value"),
    ),
    (
        "HG-3",
        "Identifiable Payer",
        ("identified payer", "buyer identified", "paying customer"),
        ("no payer", "no customer", "no buyer"),
    ),
    (
        "HG-4",
        "Critical Resource Access",
        ("resource access", "critical resource available", "access confirmed"),
        ("no access", "unavailable resource", "cannot access"),
    ),
    (
        "HG-5",
        "Critical Evidence",
        ("verified evidence", "supported evidence", "critical evidence confirmed"),
        ("no evidence", "unsubstantiated", "unsupported"),
    ),
    (
        "HG-6",
        "Capital Exposure",
        ("capital available", "funded", "financing confirmed"),
        ("no capital", "unfunded", "capital unavailable"),
    ),
    (
        "HG-7",
        "Safety & Compliance",
        ("safe", "compliant", "compliance confirmed"),
        ("unsafe", "noncompliant", "not compliant", "dangerous"),
    ),
)

PATHWAYS = (
    (
        "P1",
        "Resource → Value",
        "resource_signal",
        ("resource", "asset", "capacity", "underused", "unused", "idle", "infrastructure",
         "underutilised", "underleveraged", "latent capacity", "headroom", "sub-optimal utilisation"),
    ),
    (
        "P2",
        "Problem → Business",
        "problem_or_demand",
        ("problem", "unmet", "demand", "shortage", "need", "gap", "constraint",
         "supply-demand disequilibrium", "demand outpaces supply", "demand outstrips supply",
         "demanda insatisfecha", "necesidad no atendida", "demanda supera la oferta"),
    ),
    (
        "P3",
        "Process → Opportunity",
        "process_inefficiency",
        ("process", "inefficient", "waste", "leakage", "bottleneck", "delay", "loss",
         "OEE", "availability losses", "quality losses", "fuga de valor", "pérdidas de rendimiento",
         "مراحل التحويل التصنيعي", "هدر كبير"),
    ),
    (
        "P4",
        "Market → Market",
        "cross_market_model",
        (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "replicate the",
            "replicate a",
            "replicate an",
            "replicate from",
            "port to",
            "porting to",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "proven model from",
            "proven model we can replicate",
            "proven playbook",
            "proven format",
            "proven scheme",
            "proven approach",
            "successful model in another market",
            "successful model abroad",
            "successful model from",
            "established service in another market",
            "established service abroad",
            "established service from",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "transferable model from",
            "cross-market",
            "another market",
            "benchmark",
            "model from",
            "model in",
            "operates in",
        ),
    ),
    (
        "P5",
        "Combination → Value",
        "combination",
        ("combine", "recombination", "integrate", "complementary", "connect", "synergy",
         "strategic alignment", "JV thesis", "joint venture", "partnership thesis",
         "byproduct to input", "industrial symbiosis", "three actor", "cold chain"),
    ),
    (
        "P6",
        "Asset → Opportunity",
        "asset_operation",
        (
            "factory",
            "company",
            "turnaround",
            "distressed",
            "reconfigure",
            "alternative use",
            "asset-to-value",
            "brownfield", "adaptive reuse", "last-mile logistics", "repurpose",
        ),
    ),
)

NEGATION_ALIASES_ANALYSIS = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "absent",
    "devoid of",
    "free from",
    "no sign of",
    "no evidence of",
    "does not have",
    "does not operate",
    "does not exist",
    "is not",
    "are not",
    "was not",
    "were not",
    "has no",
    "have no",
    "had no",
    "without any",
    "sin",
    "no hay",
    "no existe",
    "no hay evidencia",
    "sin evidencia",
    "لا",
    "ليس",
    "بدون",
    "غير",
    "لا يوجد",
    "ليس هناك",
    "لا دليل على",
    "غير متوفر",
    "ما في",
    "ما فيه",
    "ماكو",
    "موجودش",
    "لا يوجد",
    "nicht",
    "kein",
    "keine",
    "keiner",
    "keines",
    "ohne",
    "fehlt",
)

HYPOTHETICAL_MARKERS_ANALYSIS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
    "projected",
    "forecast",
    "scenario analysis",
    "what if",
    "suppose",
    "supposing",
    "assuming",
    "in theory",
    "theoretically",
    "on paper",
    "envisage",
    "envision",
    "contemplate",
    "consider",
    "explore",
    "investigate",
    "evaluate",
    "assess",
    "دراسة",
    "تحليل",
    "سيناريو",
    "افتراض",
    "مقترح",
    "توقع",
    "مشروط",
    "في حال",
    "لو",
    "في حالة",
    "si",
    "caso",
    "supongamos",
    "hipotéticamente",
    "proyectado",
    "pronóstico",
    "análisis de escenario",
)

EVIDENCE_DEFINITIONS = {
    "E0": "Unsubstantiated hypothesis or no evidence registered.",
    "E1": "Single-source or preliminary observation.",
    "E2": "Corroborated observation or measured gap with material limitations.",
    "E3": "Strongly supported claim with documented validation conditions.",
    "E4": "Verified outcome under documented conditions; not a guarantee of transferability.",
}

OPPORTUNITY_STATE_DEFINITIONS = {
    "economic_signal": (
        "A registered economic observation, gap, resource, change, or condition "
        "that warrants investigation but is not yet an opportunity hypothesis."
    ),
    "opportunity_hypothesis": (
        "A deterministic pathway-linked hypothesis connecting an economic signal "
        "to a possible value-creating action."
    ),
    "opportunity_under_investigation": (
        "A hypothesis with an active validation work item and unresolved evidence, "
        "mechanism, resource, payer, or hard-gate questions."
    ),
    "validated_opportunity": (
        "An opportunity whose mechanism and required validation evidence have been "
        "verified under documented conditions."
    ),
    "commercial_feasibility_established": (
        "A validated opportunity with sufficient evidence for payer, costs, "
        "revenues, constraints, and commercial feasibility under stated conditions."
    ),
}

CALCULATION_STATUS_CALCULATED = "calculated"
CALCULATION_STATUS_NOT_CALCULABLE = "not_calculable"
VALUE_STATUS_KNOWN = "known"
VALUE_STATUS_ESTIMATED = "estimated"

METRIC_ALIASES = (
    (
        "utilized_capacity",
        ("utilized capacity", "used capacity", "capacity used", "actual capacity"),
    ),
    (
        "resource_used",
        ("resource used", "used resource", "resource utilization used"),
    ),
    (
        "resource_available",
        ("resource available", "available resource", "resource capacity"),
    ),
    (
        "recoverable_quantity",
        ("recoverable quantity", "recovery quantity", "quantity recoverable"),
    ),
    (
        "recovery_value_per_unit",
        ("recovery value per unit", "unit recovery value", "recovery unit value"),
    ),
    (
        "input_quantity",
        ("input quantity", "material input", "input volume", "feedstock input"),
    ),
    (
        "output_quantity",
        ("output quantity", "production output", "product output", "output volume"),
    ),
    (
        "operating_cost",
        ("operating cost", "operating costs", "total operating cost"),
    ),
    (
        "variable_cost",
        ("variable cost", "variable costs", "cost of goods sold", "direct cost"),
    ),
    (
        "unit_value",
        ("unit value", "value per unit", "price per unit", "unit price"),
    ),
    ("production_capacity", ("production capacity", "available capacity")),
    ("capacity", ("capacity",)),
    ("supply", ("supply", "available supply", "quantity supplied")),
    ("demand", ("demand", "required quantity", "quantity demanded")),
    ("revenue", ("revenue", "sales revenue", "sales")),
)


def analyze_investigation(investigation: dict[str, Any]) -> dict[str, Any]:
    mode = investigation.get("mode", "M2O")
    sources = investigation.get("sources", [])
    claims = investigation.get("claims", [])
    entities = investigation.get("entities", [])
    relationships = investigation.get("relationships", [])
    metrics = investigation.get("metrics", [])
    source_by_id = {source["id"]: source for source in sources}
    claim_source_ids = {
        claim["source_id"]
        for claim in claims
        if claim.get("source_id") is not None
    }
    text = _combined_text(investigation)
    analysis_date = investigation.get("analysis_date") or date.today().isoformat()
    evidence = _summarize_evidence(
        sources,
        claims,
        source_by_id,
        claim_source_ids,
        analysis_date,
    )
    economic_model = _calculate_economic_model(metrics, relationships)
    semantic_interpretation = interpret_economic_context(
        investigation,
        metrics,
        entities,
        relationships,
        economic_model,
    )
    gaps = _detect_gaps(
        investigation,
        sources,
        claims,
        entities,
        relationships,
        text,
        mode,
        semantic_interpretation,
    )
    pathway_evaluations = _evaluate_pathways(
        investigation,
        entities,
        text,
        evidence,
        mode,
        semantic_interpretation,
    )
    hard_gates = _evaluate_hard_gates(text, evidence)
    hard_gate_decision = _hard_gate_decision(hard_gates)
    sufficient = _is_sufficient_for_hypothesis(evidence, claims)
    triggered = [
        evaluation for evaluation in pathway_evaluations if evaluation["indicated"]
    ]
    if not sufficient:
        status = "insufficient-evidence"
    elif not triggered:
        status = "no-supported-pathway"
    elif hard_gate_decision["status"] == "blocked":
        status = "blocked-by-hard-gate"
    elif hard_gate_decision["status"] == "awaiting":
        status = "awaiting-hard-gates"
    else:
        status = "candidate-hypotheses"

    confidence = _confidence_score(
        evidence,
        len(entities),
        len(relationships),
        len(gaps),
    )
    unknowns = _build_unknowns(
        investigation,
        evidence,
        gaps,
        entities,
        relationships,
        hard_gates,
    )
    assumptions = _build_assumptions(investigation, evidence)
    economic_logic = _economic_logic(
        investigation,
        claims,
        entities,
        relationships,
        economic_model,
    )
    opportunities = []
    if sufficient and triggered:
        for evaluation in triggered:
            quality = _build_opportunity_quality(
                evaluation,
                evidence,
                unknowns,
                hard_gates,
                hard_gate_decision,
                economic_model,
            )
            opportunities.append(
                {
                    "title": f"{evaluation['name']} candidate for {investigation['market']}",
                    "description": (
                        "Evidence-linked opportunity hypothesis generated from the "
                        f"{evaluation['name']} pathway. It is not a verified opportunity."
                    ),
                    "origin": evaluation["origin"],
                    "pathway": evaluation["id"],
                    "evidence_strength": evidence["evidence_level"],
                    "confidence": confidence,
                    "economic_logic": economic_logic,
                    "assumptions": assumptions,
                    "unknowns": unknowns,
                    "hard_gates": hard_gates,
                    "pathway_evaluations": pathway_evaluations,
                    "quality": quality,
                    "status": (
                        "blocked"
                        if hard_gate_decision["status"] != "passed"
                        else "hypothesis"
                    ),
                }
            )

    return {
        "status": status,
        "mode": mode,
        "methodology_version": METHODOLOGY_VERSION,
        "ruleset_version": RULESET_VERSION,
        "engine_version": ENGINE_VERSION,
        "analysis_date": analysis_date,
        "evidence": evidence,
        "evidence_definitions": EVIDENCE_DEFINITIONS,
        "semantic_interpretation": semantic_interpretation,
        "gaps": gaps,
        "pathway_evaluations": pathway_evaluations,
        "hard_gates": hard_gates,
        "hard_gate_decision": hard_gate_decision,
        "confidence": confidence,
        "commercial_attractiveness": "not_assessed",
        "assumptions": assumptions,
        "unknowns": unknowns,
        "economic_logic": economic_logic,
        "economic_model": economic_model,
        "opportunity_state_summary": _build_opportunity_state_summary(
            pathway_evaluations,
            opportunities,
        ),
        "opportunities": opportunities,
        "controls": {
            "ai_override_of_hard_gates": False,
            "evidence_link_required_for_material_claims": True,
            "historical_reproducibility": True,
            "pathways_authoritative": ["P1", "P2", "P3", "P4", "P5", "P6"],
            "a2v_requires_asset_context": True,
        },
    }


def _combined_text(investigation: dict[str, Any]) -> str:
    values = [
        investigation.get("title", ""),
        investigation.get("country", ""),
        investigation.get("geography", ""),
        investigation.get("market", ""),
        investigation.get("activity", ""),
        investigation.get("objective", ""),
        investigation.get("asset_context", ""),
    ]
    for source in investigation.get("sources", []):
        values.extend(
            [
                source.get("title", ""),
                source.get("data_domain", ""),
                source.get("content", ""),
            ]
        )
    values.extend(claim.get("text", "") for claim in investigation.get("claims", []))
    values.extend(entity.get("name", "") for entity in investigation.get("entities", []))
    for metric in investigation.get("metrics", []):
        values.extend(
            [
                metric.get("metric_type", ""),
                metric.get("name", ""),
                metric.get("economic_activity", ""),
                metric.get("notes", ""),
            ]
        )
    return " ".join(values).lower()


def _summarize_evidence(
    sources: list[dict[str, Any]],
    claims: list[dict[str, Any]],
    source_by_id: dict[int, dict[str, Any]],
    claim_source_ids: set[int],
    analysis_date: str,
) -> dict[str, Any]:
    levels = [
        source.get("evidence_level", "E0") for source in sources
    ] + [
        claim.get("evidence_level", "E0") for claim in claims
    ]
    highest = max(levels, key=lambda level: EVIDENCE_SCORES.get(level, 0), default="E0")
    independent_groups = {
        _source_independence_key(source)
        for source in sources
        if float(source.get("independence_score", 0.0)) >= 0.6
    }
    linked_claims = [claim for claim in claims if claim.get("source_id") in source_by_id]
    source_groups: dict[str, list[int]] = {}
    for source in sources:
        source_groups.setdefault(_source_independence_key(source), []).append(source["id"])
    return {
        "evidence_level": highest,
        "source_count": len(sources),
        "claim_count": len(claims),
        "linked_claim_count": len(linked_claims),
        "independent_source_count": len(independent_groups),
        "independence_groups": source_groups,
        "source_ids": [source["id"] for source in sources],
        "claim_ids": [claim["id"] for claim in claims],
        "analysis_date": analysis_date,
        "source_independence_rule": (
            "Derivative or duplicated publications do not count as independent "
            "corroboration; sources in the same source_family or canonical URI "
            "group count as one independent source."
        ),
        "quality_observations": [
            {
                "source_id": source["id"],
                "reliability": source.get("reliability", 0.0),
                "independence_score": source.get("independence_score", 0.0),
                "source_family": source.get("source_family", ""),
                "last_updated": source.get("last_updated", ""),
                "freshness": _freshness_status(source.get("last_updated", ""), analysis_date),
                "access_limitations": source.get("access_limitations", ""),
            }
            for source in sources
        ],
    }


def _source_independence_key(source: dict[str, Any]) -> str:
    source_family = str(source.get("source_family", "")).strip().lower()
    if source_family:
        return f"family:{source_family}"
    uri = str(source.get("uri", "")).strip().lower().rstrip("/")
    if uri:
        return f"uri:{uri}"
    return f"source:{source.get('id')}"


def _freshness_status(last_updated: str, analysis_date: str) -> dict[str, Any]:
    if not last_updated:
        return {"status": "unknown", "age_days": None}
    try:
        updated = date.fromisoformat(last_updated[:10])
        observed = date.fromisoformat(analysis_date[:10])
    except ValueError:
        return {"status": "unknown", "age_days": None}
    age_days = (observed - updated).days
    if age_days < 0:
        return {"status": "future-dated", "age_days": age_days}
    return {
        "status": "fresh" if age_days <= 365 else "stale",
        "age_days": age_days,
    }


def _detect_gaps(
    investigation: dict[str, Any],
    sources: list[dict[str, Any]],
    claims: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
    text: str,
    mode: str,
    semantic_interpretation: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    gaps: list[dict[str, Any]] = []
    if not sources:
        gaps.append(
            {
                "id": "GAP-EVIDENCE-001",
                "title": "No registered evidence sources",
                "severity": "high",
                "status": "open",
                "evidence_ids": [],
            }
        )
    if claims and not any(claim.get("source_id") is not None for claim in claims):
        gaps.append(
            {
                "id": "GAP-TRACEABILITY-001",
                "title": "Claims are not linked to sources",
                "severity": "high",
                "status": "open",
                "evidence_ids": [claim["id"] for claim in claims],
            }
        )
    if not entities:
        gaps.append(
            {
                "id": "GAP-CONTEXT-001",
                "title": "Economic participants or assets are not mapped",
                "severity": "medium",
                "status": "open",
                "evidence_ids": [],
            }
        )
    if not relationships:
        gaps.append(
            {
                "id": "GAP-FLOW-001",
                "title": "Economic relationships or flows are not mapped",
                "severity": "medium",
                "status": "open",
                "evidence_ids": [],
            }
        )
    if mode == "A2V" and not investigation.get("asset_context", "").strip():
        gaps.append(
            {
                "id": "GAP-A2V-ASSET-001",
                "title": "A2V asset or operation context is missing",
                "severity": "high",
                "status": "open",
                "evidence_ids": [],
            }
        )
    signal_terms = _matching_terms(
        text,
        (
            "gap",
            "inefficien",
            "waste",
            "leakage",
            "bottleneck",
            "unmet",
            "shortage",
            "underused",
            "demand",
            "problem",
        ),
    )
    if not signal_terms:
        semantic_signal_exists = bool(
            (semantic_interpretation or {}).get("concepts")
        )
        if semantic_signal_exists:
            return gaps
        gaps.append(
            {
                "id": "GAP-SIGNAL-001",
                "title": "No explicit economic gap or signal identified",
                "severity": "medium",
                "status": "unknown",
                "evidence_ids": [],
            }
        )
    return gaps


def _evaluate_pathways(
    investigation: dict[str, Any],
    entities: list[dict[str, Any]],
    text: str,
    evidence: dict[str, Any],
    mode: str,
    semantic_interpretation: dict[str, Any],
) -> list[dict[str, Any]]:
    evaluations = []
    for pathway_id, name, origin, terms in PATHWAYS:
        lexical_matches = _matching_terms(text, terms)
        if pathway_id == "P6" and mode == "A2V" and investigation.get("asset_context"):
            lexical_matches.append("A2V asset context")
        semantic_matches = semantic_interpretation.get(
            "pathway_signals",
            {},
        ).get(pathway_id, [])
        semantic_labels = [
            f"semantic:{match['concept']}" for match in semantic_matches
        ]
        matches = lexical_matches + semantic_labels
        indicated = bool(matches)
        semantic_conflict = any(
            match.get("conflicting_evidence_refs")
            for match in semantic_matches
        )
        if lexical_matches and semantic_matches:
            selection_basis = "lexical_and_semantic"
        elif semantic_matches:
            selection_basis = "semantic"
        elif lexical_matches:
            selection_basis = "lexical"
        else:
            selection_basis = "none"
        reasoning = [
            match["reason"] for match in semantic_matches
        ]
        if lexical_matches:
            reasoning.insert(
                0,
                "The registered text also matched the pathway's explicit screening terms.",
            )
        if semantic_conflict:
            reasoning.append(
                "Conflicting registered observations affect this signal; the conflict "
                "must be resolved before it can support a hypothesis."
            )
        evaluations.append(
            {
                "id": pathway_id,
                "name": name,
                "origin": origin,
                "indicated": indicated,
                "discovery_state": "economic_signal" if indicated else "not_indicated",
                "ready_for_hypothesis": indicated
                and evidence["linked_claim_count"] > 0
                and evidence["evidence_level"] != "E0"
                and not semantic_conflict,
                "selection_basis": selection_basis,
                "semantic_conflict": semantic_conflict,
                "matched_signals": sorted(set(matches)),
                "lexical_matches": sorted(set(lexical_matches)),
                "semantic_matches": semantic_matches,
                "reasoning": reasoning,
                "non_selection_reason": (
                    ""
                    if indicated
                    else (
                        "No asserted lexical signal or normalized semantic concept "
                        "supports this pathway in the registered context."
                    )
                ),
                "evidence_level": evidence["evidence_level"],
                "note": (
                    "Indication is a deterministic screening result; it does not "
                    "establish an opportunity or an authoritative opportunity type."
                ),
            }
        )
    return evaluations


def _evaluate_hard_gates(text: str, evidence: dict[str, Any]) -> list[dict[str, Any]]:
    results = []
    for gate_id, name, pass_terms, fail_terms in HARD_GATES:
        pass_matches = _matching_terms(text, pass_terms, respect_negation=True)
        fail_matches = _matching_terms(text, fail_terms, respect_negation=False)
        if pass_matches and fail_matches:
            status = "conflicting"
        elif fail_matches:
            status = "fail"
        elif pass_matches:
            status = "pass"
        else:
            status = "unknown"
        results.append(
            {
                "id": gate_id,
                "name": name,
                "status": status,
                "matched_pass_signals": pass_matches,
                "matched_fail_signals": fail_matches,
                "overridable": False,
                "evidence_level": evidence["evidence_level"],
                "note": (
                    "Only explicit evidence can produce pass. Unknown, conflicting, "
                    "or failed states block validation and cannot be overridden by "
                    "a score, AI recommendation, or interface action."
                ),
            }
        )
    return results


def _hard_gate_decision(hard_gates: list[dict[str, Any]]) -> dict[str, Any]:
    blocking = [
        gate["id"]
        for gate in hard_gates
        if gate["status"] in {"fail", "unknown", "conflicting"}
    ]
    failed = [
        gate["id"]
        for gate in hard_gates
        if gate["status"] in {"fail", "conflicting"}
    ]
    if failed:
        status = "blocked"
        reason = "At least one Economic Hard Gate failed or has conflicting evidence."
    elif blocking:
        status = "awaiting"
        reason = "One or more Economic Hard Gates remain unknown."
    else:
        status = "passed"
        reason = "All seven Economic Hard Gates have explicit pass evidence."
    return {
        "status": status,
        "blocking_gate_ids": blocking,
        "reason": reason,
        "non_overridable": True,
    }


def _is_sufficient_for_hypothesis(
    evidence: dict[str, Any],
    claims: list[dict[str, Any]],
) -> bool:
    return (
        evidence["source_count"] > 0
        and evidence["linked_claim_count"] > 0
        and evidence["evidence_level"] != "E0"
        and bool(claims)
    )


def _confidence_score(
    evidence: dict[str, Any],
    entity_count: int,
    relationship_count: int,
    gap_count: int,
) -> float:
    evidence_component = EVIDENCE_SCORES[evidence["evidence_level"]] / 4 * 0.45
    linkage_component = (
        min(evidence["linked_claim_count"], 5) / 5 * 0.2
    )
    independence_component = (
        min(evidence["independent_source_count"], 3) / 3 * 0.15
    )
    context_component = min(entity_count, 3) / 3 * 0.1
    relationship_component = min(relationship_count, 3) / 3 * 0.05
    gap_penalty = min(gap_count, 5) / 5 * 0.15
    score = (
        0.05
        + evidence_component
        + linkage_component
        + independence_component
        + context_component
        + relationship_component
        - gap_penalty
    )
    return round(max(0.0, min(score, 1.0)), 3)


def _build_unknowns(
    investigation: dict[str, Any],
    evidence: dict[str, Any],
    gaps: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
    hard_gates: list[dict[str, Any]],
) -> list[str]:
    unknowns = [
        f"Whether the evidence is transferable beyond {investigation.get('country', 'the stated geography')}.",
        "Whether the proposed mechanism has a paying customer under actual conditions.",
    ]
    if not entities:
        unknowns.append("Which economic participants, assets, or activities are in scope.")
    if not relationships:
        unknowns.append("How ownership, control, use, supply, purchase, and flows operate over time.")
    if investigation.get("mode") == "A2V":
        unknowns.append("Whether the asset or operation can be reconfigured under its physical, legal, and capital constraints.")
    if evidence["independent_source_count"] < 2:
        unknowns.append("Whether independent corroboration exists beyond the registered sources.")
    unknowns.extend(
        f"{gate['id']} {gate['name']} remains {gate['status']}."
        for gate in hard_gates
        if gate["status"] != "pass"
    )
    unknowns.extend(gap["title"] for gap in gaps if gap["status"] in {"open", "unknown"})
    return list(dict.fromkeys(unknowns))


def _build_assumptions(
    investigation: dict[str, Any],
    evidence: dict[str, Any],
) -> list[str]:
    assumptions = [
        "The investigation scope supplied by the owner is the intended analytical boundary.",
        "Registered source content is an accurate representation of the cited material.",
        "The current deterministic ruleset is the approved executable screening basis for this run.",
    ]
    if evidence["evidence_level"] in {"E0", "E1"}:
        assumptions.append(
            "The opportunity hypothesis remains exploratory because evidence is limited."
        )
    if investigation.get("asset_context"):
        assumptions.append("The stated asset context is relevant to the investigation objective.")
    return assumptions


def _calculate_economic_model(
    metrics: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
) -> dict[str, Any]:
    calculations: list[dict[str, Any]] = []

    production_capacity = _aggregate_metric(metrics, "production_capacity")
    if not production_capacity["candidates"]:
        production_capacity = _aggregate_metric(metrics, "capacity")
    utilized_capacity = _aggregate_metric(metrics, "utilized_capacity")
    calculations.append(
        _ratio_calculation(
            "EC-001",
            "Capacity utilization",
            utilized_capacity,
            production_capacity,
            "utilized_capacity / production_capacity",
            "Capacity utilization is calculated only when both quantities use the same unit.",
        )
    )

    demand = _aggregate_metric(metrics, "demand")
    supply = _aggregate_metric(metrics, "supply")
    calculations.append(
        _difference_calculation(
            "EC-002",
            "Supply-demand gap",
            demand,
            supply,
            "demand - supply",
            "A positive result indicates demand exceeds registered supply.",
        )
    )

    input_quantity = _aggregate_metric(metrics, "input_quantity")
    output_quantity = _aggregate_metric(metrics, "output_quantity")
    calculations.append(
        _value_calculation(
            "EC-003",
            "Input quantity",
            input_quantity,
            "input quantity",
            "Registered input quantities are summed only when their units agree.",
        )
    )
    calculations.append(
        _value_calculation(
            "EC-004",
            "Output quantity",
            output_quantity,
            "output quantity",
            "Registered output quantities are summed only when their units agree.",
        )
    )
    material_loss = _difference_calculation(
        "EC-005",
        "Material loss",
        input_quantity,
        output_quantity,
        "input_quantity - output_quantity",
        "A negative result indicates that the declared system boundary needs review.",
    )
    calculations.append(material_loss)
    calculations.append(
        _ratio_calculation(
            "EC-006",
            "Material loss rate",
            _calculation_as_aggregate(material_loss),
            input_quantity,
            "material_loss / input_quantity",
            "Material loss rate uses the calculated loss quantity and the registered input quantity.",
            numerator_unit=material_loss.get("unit", ""),
        )
    )

    unit_value = _aggregate_metric(metrics, "unit_value", require_currency=True)
    calculations.append(
        _value_leakage_calculation(
            "EC-007",
            _calculation_as_aggregate(material_loss),
            unit_value,
        )
    )

    revenue = _aggregate_metric(metrics, "revenue", require_currency=True)
    operating_cost = _aggregate_metric(metrics, "operating_cost", require_currency=True)
    calculations.append(
        _value_calculation(
            "EC-008",
            "Revenue",
            revenue,
            "currency",
            "Registered revenue values are summed only when their currency agrees.",
        )
    )
    calculations.append(
        _value_calculation(
            "EC-009",
            "Operating cost",
            operating_cost,
            "currency",
            "Registered operating costs are summed only when their currency agrees.",
        )
    )
    gross_margin = _difference_calculation(
        "EC-010",
        "Gross margin",
        revenue,
        operating_cost,
        "revenue - operating_cost",
        "Gross margin is not a profitability guarantee and excludes unregistered costs.",
        require_currency=True,
    )
    calculations.append(gross_margin)
    calculations.append(
        _ratio_calculation(
            "EC-011",
            "Gross margin rate",
            _calculation_as_aggregate(gross_margin),
            revenue,
            "gross_margin / revenue",
            "Gross margin rate is not calculated when revenue is zero or currency is missing.",
            numerator_unit=gross_margin.get("currency", ""),
            require_same_unit=False,
        )
    )
    variable_cost = _aggregate_metric(
        metrics,
        "variable_cost",
        require_currency=True,
    )
    contribution_margin = _difference_calculation(
        "EC-014",
        "Contribution margin",
        revenue,
        variable_cost,
        "revenue - variable_cost",
        "Contribution margin requires an explicitly registered variable-cost definition.",
        require_currency=True,
    )
    calculations.append(contribution_margin)
    calculations.append(
        _ratio_calculation(
            "EC-015",
            "Contribution margin rate",
            _calculation_as_aggregate(contribution_margin),
            revenue,
            "contribution_margin / revenue",
            "Contribution margin rate is not calculated when revenue is zero or currency is missing.",
            numerator_unit=contribution_margin.get("currency", ""),
            require_same_unit=False,
        )
    )

    resource_available = _aggregate_metric(metrics, "resource_available")
    resource_used = _aggregate_metric(metrics, "resource_used")
    calculations.append(
        _ratio_calculation(
            "EC-012",
            "Resource utilization",
            resource_used,
            resource_available,
            "resource_used / resource_available",
            "Resource utilization requires comparable available and used quantities.",
        )
    )

    recoverable_quantity = _aggregate_metric(metrics, "recoverable_quantity")
    recovery_value = _aggregate_metric(
        metrics,
        "recovery_value_per_unit",
        require_currency=True,
    )
    calculations.append(
        _recovery_calculation(
            "EC-013",
            recoverable_quantity,
            recovery_value,
        )
    )

    return {
        "version": "OF-ECONOMIC-MODEL-0.1",
        "methodology_version": METHODOLOGY_VERSION,
        "ruleset_version": RULESET_VERSION,
        "calculations": calculations,
        "flow_validation": _validate_relationships(relationships),
        "summary": {
            "calculation_count": len(calculations),
            "calculated_count": sum(
                calculation["status"] == CALCULATION_STATUS_CALCULATED
                for calculation in calculations
            ),
            "not_calculable_count": sum(
                calculation["status"] == CALCULATION_STATUS_NOT_CALCULABLE
                for calculation in calculations
            ),
            "known_or_estimated_inputs_only": True,
            "no_missing_values_invented": True,
        },
    }


def _aggregate_metric(
    metrics: list[dict[str, Any]],
    semantic_type: str,
    *,
    require_unit: bool = True,
    require_currency: bool = False,
) -> dict[str, Any]:
    candidates = [
        metric
        for metric in metrics
        if _metric_semantic_type(metric) == semantic_type
    ]
    input_records = [_metric_input_record(metric) for metric in candidates]
    missing_inputs: list[str] = []
    usable_values: list[float] = []
    input_statuses: list[str] = []
    usable_observations: dict[tuple[Any, ...], list[tuple[float, str]]] = {}
    units = {str(metric.get("unit", "")).strip() for metric in candidates}
    currencies = {str(metric.get("currency", "")).strip() for metric in candidates}
    periods = {
        (
            str(metric.get("period_start", "")).strip(),
            str(metric.get("period_end", "")).strip(),
        )
        for metric in candidates
    }

    if not candidates:
        missing_inputs.append(semantic_type)
    for metric in candidates:
        status = metric.get("status", "unknown")
        input_statuses.append(status)
        value = metric.get("value")
        if status not in {"known", "estimated"}:
            missing_inputs.append(f"{semantic_type} value ({status})")
            continue
        if value is None:
            missing_inputs.append(f"{semantic_type} value")
            continue
        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            missing_inputs.append(f"{semantic_type} numeric value")
            continue
        if not isfinite(numeric_value):
            missing_inputs.append(f"{semantic_type} finite numeric value")
            continue
        identity = _metric_identity(metric)
        usable_observations.setdefault(identity, []).append((numeric_value, status))

    if require_unit and any(not unit for unit in units):
        missing_inputs.append(f"{semantic_type} unit")
    if len({unit for unit in units if unit}) > 1:
        missing_inputs.append(f"{semantic_type} compatible unit")
    if require_currency and any(not currency for currency in currencies):
        missing_inputs.append(f"{semantic_type} currency")
    if len({currency for currency in currencies if currency}) > 1:
        missing_inputs.append(f"{semantic_type} compatible currency")
    if len(periods) > 1:
        missing_inputs.append(f"{semantic_type} compatible period")
    if any(bool(start) != bool(end) for start, end in periods):
        missing_inputs.append(f"{semantic_type} complete period")

    duplicate_observation_count = 0
    conflicting_observation_count = 0
    for observations in usable_observations.values():
        distinct_values = {value for value, _ in observations}
        if len(distinct_values) > 1:
            conflicting_observation_count += 1
            missing_inputs.append(f"{semantic_type} conflicting observations")
        else:
            usable_values.append(next(iter(distinct_values)))
            duplicate_observation_count += max(0, len(observations) - 1)

    input_status = (
        VALUE_STATUS_ESTIMATED
        if any(status == VALUE_STATUS_ESTIMATED for status in input_statuses)
        else VALUE_STATUS_KNOWN
        if input_statuses and not missing_inputs
        else "unknown"
    )
    unit = next((unit for unit in units if unit), "")
    currency = next((currency for currency in currencies if currency), "")
    return {
        "semantic_type": semantic_type,
        "candidates": input_records,
        "inputs": input_records,
        "ok": bool(candidates) and not missing_inputs and bool(usable_values),
        "value": round(sum(usable_values), 6) if usable_values else None,
        "unit": unit,
        "currency": currency,
        "input_status": input_status,
        "missing_inputs": list(dict.fromkeys(missing_inputs)),
        "duplicate_observation_count": duplicate_observation_count,
        "conflicting_observation_count": conflicting_observation_count,
    }


def _metric_semantic_type(metric: dict[str, Any]) -> str | None:
    metric_text = _normalize_metric_text(
        f"{metric.get('metric_type', '')} {metric.get('name', '')}"
    )
    for semantic_type, aliases in METRIC_ALIASES:
        if any(_contains_phrase(metric_text, alias) for alias in aliases):
            return semantic_type
    return None


def _normalize_metric_text(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()


def _contains_phrase(text: str, phrase: str) -> bool:
    normalized_phrase = _normalize_metric_text(phrase)
    return bool(
        re.search(
            rf"(?<!\w){re.escape(normalized_phrase)}(?!\w)",
            text,
        )
    )


def _metric_input_record(metric: dict[str, Any]) -> dict[str, Any]:
    return {
        "metric_id": metric.get("id"),
        "metric_type": metric.get("metric_type", ""),
        "name": metric.get("name", ""),
        "value": metric.get("value"),
        "unit": metric.get("unit", ""),
        "currency": metric.get("currency", ""),
        "status": metric.get("status", "unknown"),
        "verification_status": metric.get("verification_status", "potential"),
        "period_start": metric.get("period_start", ""),
        "period_end": metric.get("period_end", ""),
        "economic_activity": metric.get("economic_activity", ""),
        "source_id": metric.get("source_id"),
    }


def _metric_identity(metric: dict[str, Any]) -> tuple[Any, ...]:
    return (
        _normalize_metric_text(metric.get("metric_type", "")),
        _normalize_metric_text(metric.get("name", "")),
        metric.get("entity_id"),
        str(metric.get("period_start", "")).strip(),
        str(metric.get("period_end", "")).strip(),
        str(metric.get("unit", "")).strip(),
        str(metric.get("currency", "")).strip(),
    )


def _calculation_record(
    calculation_id: str,
    name: str,
    formula: str,
    inputs: list[dict[str, Any]],
    *,
    result: float | None,
    unit: str,
    currency: str,
    input_status: str,
    assumptions: list[str],
    limitations: list[str],
    missing_inputs: list[str],
    observation_metadata: dict[str, int] | None = None,
) -> dict[str, Any]:
    calculated = not missing_inputs and result is not None
    value_status = (
        VALUE_STATUS_ESTIMATED
        if input_status == VALUE_STATUS_ESTIMATED
        else VALUE_STATUS_KNOWN
        if calculated
        else "unknown"
    )
    return {
        "id": calculation_id,
        "name": name,
        "status": (
            CALCULATION_STATUS_CALCULATED
            if calculated
            else CALCULATION_STATUS_NOT_CALCULABLE
        ),
        "value_status": value_status,
        "input_status": input_status,
        "result": round(result, 6) if result is not None else None,
        "unit": unit,
        "currency": currency,
        "formula": formula,
        "inputs": inputs,
        "methodology_version": METHODOLOGY_VERSION,
        "ruleset_version": RULESET_VERSION,
        "assumptions": assumptions,
        "limitations": limitations,
        "missing_inputs": list(dict.fromkeys(missing_inputs)),
        "observation_metadata": observation_metadata
        or {
            "duplicate_observation_count": 0,
            "conflicting_observation_count": 0,
        },
    }


def _value_calculation(
    calculation_id: str,
    name: str,
    aggregate: dict[str, Any],
    formula: str,
    limitation: str,
) -> dict[str, Any]:
    return _calculation_record(
        calculation_id,
        name,
        formula,
        aggregate["inputs"],
        result=aggregate["value"] if aggregate["ok"] else None,
        unit=aggregate["unit"],
        currency=aggregate["currency"],
        input_status=aggregate["input_status"],
        assumptions=["All registered values are within the declared investigation boundary."],
        limitations=[limitation],
        missing_inputs=aggregate["missing_inputs"],
        observation_metadata=_observation_metadata(aggregate),
    )


def _calculation_as_aggregate(calculation: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": calculation["status"] == CALCULATION_STATUS_CALCULATED,
        "value": calculation["result"],
        "unit": calculation["unit"],
        "currency": calculation["currency"],
        "inputs": calculation["inputs"],
        "input_status": calculation["input_status"],
        "missing_inputs": calculation["missing_inputs"],
        "duplicate_observation_count": calculation["observation_metadata"][
            "duplicate_observation_count"
        ],
        "conflicting_observation_count": calculation["observation_metadata"][
            "conflicting_observation_count"
        ],
    }


def _difference_calculation(
    calculation_id: str,
    name: str,
    minuend: dict[str, Any],
    subtrahend: dict[str, Any],
    formula: str,
    limitation: str,
    *,
    require_currency: bool = False,
) -> dict[str, Any]:
    inputs = minuend["inputs"] + subtrahend["inputs"]
    missing_inputs = minuend["missing_inputs"] + subtrahend["missing_inputs"]
    if minuend["ok"] and subtrahend["ok"]:
        if minuend["unit"] != subtrahend["unit"]:
            missing_inputs.append("compatible units")
        if require_currency and minuend["currency"] != subtrahend["currency"]:
            missing_inputs.append("compatible currencies")
    result = (
        minuend["value"] - subtrahend["value"]
        if minuend["ok"]
        and subtrahend["ok"]
        and minuend["unit"] == subtrahend["unit"]
        and (not require_currency or minuend["currency"] == subtrahend["currency"])
        else None
    )
    input_status = _combined_input_status(minuend, subtrahend)
    return _calculation_record(
        calculation_id,
        name,
        formula,
        inputs,
        result=result,
        unit=minuend["unit"] or subtrahend["unit"],
        currency=minuend["currency"] or subtrahend["currency"],
        input_status=input_status,
        assumptions=["The compared values describe the same economic boundary and period."],
        limitations=[limitation],
        missing_inputs=missing_inputs,
        observation_metadata=_observation_metadata(minuend, subtrahend),
    )


def _ratio_calculation(
    calculation_id: str,
    name: str,
    numerator: dict[str, Any],
    denominator: dict[str, Any],
    formula: str,
    limitation: str,
    *,
    numerator_unit: str = "",
    require_same_unit: bool = True,
) -> dict[str, Any]:
    inputs = numerator["inputs"] + denominator["inputs"]
    missing_inputs = numerator["missing_inputs"] + denominator["missing_inputs"]
    compatible = (
        numerator["ok"]
        and denominator["ok"]
        and (not require_same_unit or numerator["unit"] == denominator["unit"])
        and denominator["value"] != 0
    )
    if numerator["ok"] and denominator["ok"]:
        if require_same_unit and numerator["unit"] != denominator["unit"]:
            missing_inputs.append("compatible units")
        if denominator["value"] == 0:
            missing_inputs.append("non-zero denominator")
    result = (
        numerator["value"] / denominator["value"]
        if compatible
        else None
    )
    return _calculation_record(
        calculation_id,
        name,
        formula,
        inputs,
        result=result,
        unit="ratio" if not numerator_unit else "ratio",
        currency="",
        input_status=_combined_input_status(numerator, denominator),
        assumptions=["The numerator and denominator refer to the same period or comparable basis."],
        limitations=[limitation],
        missing_inputs=missing_inputs,
        observation_metadata=_observation_metadata(numerator, denominator),
    )


def _value_leakage_calculation(
    calculation_id: str,
    material_loss: dict[str, Any],
    unit_value: dict[str, Any],
) -> dict[str, Any]:
    inputs = material_loss["inputs"] + unit_value["inputs"]
    missing_inputs = material_loss["missing_inputs"] + unit_value["missing_inputs"]
    result = None
    compatible_units = _per_unit_value_matches_quantity(
        material_loss["unit"],
        unit_value["unit"],
    )
    if material_loss["ok"] and unit_value["ok"] and not compatible_units:
        missing_inputs.append("compatible quantity and value-per-unit units")
    if material_loss["ok"] and unit_value["ok"] and compatible_units:
        result = material_loss["value"] * unit_value["value"]
    return _calculation_record(
        calculation_id,
        "Potential value leakage",
        "material_loss_quantity * value_per_unit",
        inputs,
        result=result,
        unit="currency",
        currency=unit_value["currency"],
        input_status=_combined_input_status(material_loss, unit_value),
        assumptions=["The registered unit value is applicable to the calculated loss quantity."],
        limitations=[
            "This is a potential gross value estimate, not a realized recovery or profit."
        ],
        missing_inputs=missing_inputs,
        observation_metadata=_observation_metadata(material_loss, unit_value),
    )


def _recovery_calculation(
    calculation_id: str,
    recoverable_quantity: dict[str, Any],
    recovery_value: dict[str, Any],
) -> dict[str, Any]:
    inputs = recoverable_quantity["inputs"] + recovery_value["inputs"]
    missing_inputs = recoverable_quantity["missing_inputs"] + recovery_value["missing_inputs"]
    result = None
    compatible_units = _per_unit_value_matches_quantity(
        recoverable_quantity["unit"],
        recovery_value["unit"],
    )
    if recoverable_quantity["ok"] and recovery_value["ok"] and not compatible_units:
        missing_inputs.append("compatible quantity and value-per-unit units")
    if recoverable_quantity["ok"] and recovery_value["ok"] and compatible_units:
        result = recoverable_quantity["value"] * recovery_value["value"]
    return _calculation_record(
        calculation_id,
        "Potential value recovery",
        "recoverable_quantity * recovery_value_per_unit",
        inputs,
        result=result,
        unit="currency",
        currency=recovery_value["currency"],
        input_status=_combined_input_status(recoverable_quantity, recovery_value),
        assumptions=["The recovery quantity is physically and legally recoverable under the stated conditions."],
        limitations=[
            "This is a potential gross value estimate; recovery cost, access, and demand remain to be validated."
        ],
        missing_inputs=missing_inputs,
        observation_metadata=_observation_metadata(
            recoverable_quantity,
            recovery_value,
        ),
    )


def _observation_metadata(*aggregates: dict[str, Any]) -> dict[str, int]:
    return {
        "duplicate_observation_count": sum(
            aggregate.get("duplicate_observation_count", 0)
            for aggregate in aggregates
        ),
        "conflicting_observation_count": sum(
            aggregate.get("conflicting_observation_count", 0)
            for aggregate in aggregates
        ),
    }


def _per_unit_value_matches_quantity(
    quantity_unit: str,
    value_unit: str,
) -> bool:
    normalized_quantity = _normalize_unit(quantity_unit)
    normalized_value = _normalize_unit(value_unit)
    if not normalized_quantity or not normalized_value:
        return False
    denominator = ""
    if "/" in normalized_value:
        _, denominator = normalized_value.split("/", 1)
    else:
        match = re.search(r"\bper\s+(.+)$", normalized_value)
        if match:
            denominator = match.group(1).strip()
    return bool(denominator) and denominator == normalized_quantity


def _normalize_unit(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value).lower().strip())


def _combined_input_status(
    first: dict[str, Any],
    second: dict[str, Any],
) -> str:
    if VALUE_STATUS_ESTIMATED in {
        first.get("input_status"),
        second.get("input_status"),
    }:
        return VALUE_STATUS_ESTIMATED
    if first.get("input_status") == VALUE_STATUS_KNOWN and second.get("input_status") == VALUE_STATUS_KNOWN:
        return VALUE_STATUS_KNOWN
    return "unknown"


def _validate_relationships(
    relationships: list[dict[str, Any]],
) -> dict[str, Any]:
    relationship_records = []
    missing_field_counts: dict[str, int] = {}
    structured_flow_count = 0
    verified_count = 0
    potential_count = 0
    provenance_complete_count = 0
    for relationship in relationships:
        structured_fields = (
            relationship.get("economic_activity"),
            relationship.get("quantity"),
            relationship.get("quantity_unit"),
            relationship.get("value_amount"),
            relationship.get("currency"),
            relationship.get("time_period"),
            relationship.get("ownership_control"),
            relationship.get("valid_from"),
            relationship.get("valid_to"),
        )
        if any(value not in (None, "") for value in structured_fields):
            structured_flow_count += 1
        if relationship.get("verification_status") == "verified":
            verified_count += 1
        elif relationship.get("verification_status") == "potential":
            potential_count += 1
        if relationship.get("source_id") is not None:
            provenance_complete_count += 1
        for field_name in (
            "direction",
            "economic_activity",
            "quantity",
            "quantity_unit",
            "quantity_status",
            "value_amount",
            "currency",
            "value_status",
            "time_period",
            "ownership_control",
            "valid_from",
            "valid_to",
            "source_id",
        ):
            if relationship.get(field_name) in (None, ""):
                missing_field_counts[field_name] = missing_field_counts.get(field_name, 0) + 1
        relationship_records.append(
            {
                "relationship_id": relationship.get("id"),
                "subject_entity_id": relationship.get("subject_entity_id"),
                "object_entity_id": relationship.get("object_entity_id"),
                "relationship_type": relationship.get("relationship_type", ""),
                "direction": relationship.get("direction", ""),
                "flow_type": relationship.get("flow_type", ""),
                "economic_activity": relationship.get("economic_activity", ""),
                "quantity": relationship.get("quantity"),
                "quantity_unit": relationship.get("quantity_unit", ""),
                "quantity_status": relationship.get("quantity_status", "unknown"),
                "value_amount": relationship.get("value_amount"),
                "currency": relationship.get("currency", ""),
                "value_status": relationship.get("value_status", "unknown"),
                "time_period": relationship.get("time_period", ""),
                "ownership_control": relationship.get("ownership_control", ""),
                "valid_from": relationship.get("valid_from", ""),
                "valid_to": relationship.get("valid_to", ""),
                "verification_status": relationship.get("verification_status", "potential"),
                "confidence": relationship.get("confidence", 0.5),
                "source_id": relationship.get("source_id"),
            }
        )
    return {
        "status": "not_mapped" if not relationships else "mapped",
        "relationship_count": len(relationships),
        "structured_flow_count": structured_flow_count,
        "verified_relationship_count": verified_count,
        "potential_relationship_count": potential_count,
        "provenance_complete_count": provenance_complete_count,
        "missing_field_counts": missing_field_counts,
        "relationships": relationship_records,
        "verification_rule": (
            "Potential relationships remain distinct from verified relationships; "
            "verification status and confidence are preserved."
        ),
        "temporal_rule": (
            "valid_from, valid_to, and time_period are retained as supplied; "
            "no temporal validity is inferred when absent."
        ),
    }


def _build_opportunity_state_summary(
    pathway_evaluations: list[dict[str, Any]],
    opportunities: list[dict[str, Any]],
) -> dict[str, Any]:
    counts = {state: 0 for state in OPPORTUNITY_STATE_DEFINITIONS}
    counts["economic_signal"] = sum(
        evaluation["indicated"] for evaluation in pathway_evaluations
    )
    for opportunity in opportunities:
        lifecycle_state = opportunity["quality"].get(
            "lifecycle_state",
            "opportunity_hypothesis",
        )
        if lifecycle_state in counts:
            counts[lifecycle_state] += 1
    return {
        "definitions": OPPORTUNITY_STATE_DEFINITIONS,
        "counts": counts,
        "current_records_are_hypotheses": True,
        "validation_rule": (
            "Screening creates economic signals and opportunity hypotheses only. "
            "Under-investigation, validated, and commercially feasible states require "
            "explicit evidence and validation records; they are not inferred from a "
            "pathway indication, score, or passing calculation."
        ),
    }


def _build_opportunity_quality(
    evaluation: dict[str, Any],
    evidence: dict[str, Any],
    unknowns: list[str],
    hard_gates: list[dict[str, Any]],
    hard_gate_decision: dict[str, Any],
    economic_model: dict[str, Any],
) -> dict[str, Any]:
    calculated_ids = [
        calculation["id"]
        for calculation in economic_model["calculations"]
        if calculation["status"] == CALCULATION_STATUS_CALCULATED
    ]
    next_validation_requirements = [
        "Identify and evidence the payer or beneficiary and willingness to pay.",
        "Confirm resource access, ownership, control, and operating constraints.",
        "Validate the economic mechanism under the documented conditions.",
    ]
    if hard_gate_decision["status"] != "passed":
        next_validation_requirements.append(
            "Resolve every non-passing Economic Hard Gate before validation."
        )
    if evidence["evidence_level"] in {"E0", "E1", "E2"}:
        next_validation_requirements.append(
            "Obtain stronger evidence and independent corroboration for material claims."
        )
    if not calculated_ids:
        next_validation_requirements.append(
            "Register compatible quantities, values, units, and periods before relying on economic calculations."
        )
    return {
        "classification": "opportunity_hypothesis",
        "lifecycle_state": "opportunity_hypothesis",
        "validation_state": "hypothesis",
        "commercial_feasibility": "not_assessed",
        "state_definitions": OPPORTUNITY_STATE_DEFINITIONS,
        "economic_mechanism": (
            f"{evaluation['name']} connects an economic signal to a possible "
            "value-creating action; the mechanism remains to be validated."
        ),
        "discovery_reasoning": evaluation.get("reasoning", []),
        "semantic_concepts": [
            match["concept"] for match in evaluation.get("semantic_matches", [])
        ],
        "value_creation": {
            "calculated_measurement_ids": calculated_ids,
            "statement": (
                "Potential value creation is not established unless the registered "
                "evidence and deterministic calculations support it."
            ),
        },
        "payer_or_beneficiary": "Not established",
        "resource_and_access_requirements": [
            "Relevant resource, asset, activity, and access conditions must be mapped.",
        ],
        "economic_logic": {
            "calculation_ids": calculated_ids,
            "model_version": economic_model["version"],
        },
        "uncertainties": unknowns,
        "hard_gate_status": {
            "decision": hard_gate_decision,
            "gates": hard_gates,
        },
        "next_validation_requirements": next_validation_requirements,
        "limitations": [
            "This record is an opportunity hypothesis, not a validated or commercially feasible opportunity.",
            "AI-assisted interpretation cannot override deterministic calculations or Economic Hard Gates.",
        ],
    }


def _economic_logic(
    investigation: dict[str, Any],
    claims: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
    economic_model: dict[str, Any],
) -> dict[str, Any]:
    return {
        "context": {
            "mode": investigation.get("mode", "M2O"),
            "country": investigation.get("country", ""),
            "geography": investigation.get("geography", ""),
            "market": investigation.get("market", ""),
            "activity": investigation.get("activity", ""),
            "asset_context": investigation.get("asset_context", ""),
        },
        "mechanism": (
            "Connect an identified economic signal, resource, problem, process, "
            "market model, or asset condition to a potential value-creating action."
        ),
        "known_inputs": [
            claim["text"] for claim in claims if claim.get("evidence_level") != "E0"
        ],
        "mapped_entity_count": len(entities),
        "mapped_relationship_count": len(relationships),
        "flow_validation": economic_model["flow_validation"],
        "deterministic_calculation_ids": [
            calculation["id"] for calculation in economic_model["calculations"]
        ],
        "deterministic_calculations": economic_model["calculations"],
        "payer": "Not established",
        "value_capture": "Not quantified",
        "cost_and_capital": "Not quantified",
        "validation_state": "Preliminary; requires validation evidence and economic modeling.",
    }


def _matching_terms(
    text: str,
    terms: tuple[str, ...],
    respect_negation: bool = True,
) -> list[str]:
    matched: list[str] = []
    for term in terms:
        pattern = rf"(?<!\w){re.escape(term)}(?:\w+)?(?!\w)"
        for occurrence in re.finditer(pattern, text):
            if (
                (not respect_negation or not _is_negated(text, occurrence.start()))
                and not _is_hypothetical_statement(text, occurrence.start())
            ):
                matched.append(term)
                break
    return matched


def _normalize_analysis(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\w){re.escape(_normalize_analysis(alias))}"
            rf"(?:\s+\w+){{0,6}}\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES_ANALYSIS
    )


def _is_hypothetical_statement(text: str, start: int) -> bool:
    sentence_start = max(
        text.rfind(".", 0, start),
        text.rfind("!", 0, start),
        text.rfind("?", 0, start),
        text.rfind(";", 0, start),
    ) + 1
    sentence_end_candidates = [
        index
        for index in (
            text.find(".", start),
            text.find("!", start),
            text.find("?", start),
            text.find(";", start),
        )
        if index >= 0
    ]
    sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(text)
    sentence = text[sentence_start:sentence_end]
    if "?" in text[start:sentence_end + 1]:
        return True
    marker_pattern = "|".join(re.escape(marker) for marker in HYPOTHETICAL_MARKERS_ANALYSIS)
    return bool(
        re.search(
            rf"(?<!\w)(?:{marker_pattern})(?!\w)",
            sentence,
        )
    )
