"""Application services for the OPPORTUNITY FACTORY first working slice."""
