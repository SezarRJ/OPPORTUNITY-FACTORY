from __future__ import annotations

import re
import unicodedata
from typing import Any


SEMANTIC_RULE_VERSION = "OF-SEMANTIC-RULES-0.3"

SEMANTIC_CONCEPTS = {
    "underutilized_capacity": {
        "aliases": (
            "underutilized capacity",
            "underused capacity",
            "idle capacity",
            "unused capacity",
            "capacity not fully used",
            "operating below capacity",
            "infrastructure operating below capacity",
            "operates below its design limit",
            "capacity remains available",
            "underutilized asset",
            "idle asset",
            "unused byproduct",
            "unused by-products",
            "discarded byproduct",
            "discarded by-products",
            "surplus resource",
            "capacidad ociosa",
            "capacidad infrautilizada",
            "capacidad no utilizada",
            "recurso subutilizado",
            "subproductos no utilizados",
            "قدرة غير مستغلة",
            "طاقة غير مستغلة",
            "أصل غير مستغل",
            "مورد غير مستغل",
            "half-empty",
            "half empty",
            "sitting idle",
            "sitting half-empty",
            "sub-optimal utilisation",
            "suboptimal utilisation",
            "headroom",
            "underleveraged",
            "latent capacity",
            "underleveraged asset",
            "latent capability",
            "significant unused",
        ),
        "reason": (
            "The context describes available capacity, resources, or assets that "
            "are not fully used."
        ),
    },
    "unmet_demand": {
        "aliases": (
            "unmet demand",
            "unserved demand",
            "unserved need",
            "demand outstrips supply",
            "demand exceeds supply",
            "service deficit",
            "buyers cannot obtain",
            "local demand is not served",
            "demanda insatisfecha",
            "la demanda supera la oferta",
            "necesidad no atendida",
            "الطلب غير الملبى",
            "الطلب يتجاوز العرض",
            "فجوة بين العرض والطلب",
            "حاجة غير ملباة",
            "supply-demand disequilibrium",
            "demand outpaces supply",
            "demand outpacing supply",
            "demand disequilibrium",
            "persistent supply-demand",
            "quantitative analysis reveals",
        ),
        "reason": (
            "The context describes demand, need, or buyers that are not met by "
            "available supply or service."
        ),
    },
    "process_loss": {
        "aliases": (
            "yield loss",
            "material attrition",
            "conversion loss",
            "value escapes between stages",
            "losses between value chain stages",
            "value chain leakage",
            "post harvest losses",
            "yield reduction between value chain stages",
            "throughput bottleneck",
            "process leakage",
            "pérdida de rendimiento",
            "pérdida de material",
            "cuello de botella",
            "فاقد المواد",
            "هدر سلسلة القيمة",
            "تسرب القيمة",
            "عنق الزجاجة",
            "خسارة التحويل",
            "OEE",
            "availability losses",
            "quality losses",
            "availability loss",
            "quality loss",
            "significant availability",
            "significant quality",
            "fuga de valor",
            "pérdidas de rendimiento",
            "مراحل التحويل التصنيعي",
            "هدر كبير",
            "deadweight loss",
            "allocative inefficiency",
        ),
        "reason": (
            "The context describes loss, leakage, waste, or a bottleneck in a "
            "production or value-chain process."
        ),
    },
    "cross_market_replication": {
        "aliases": (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "replicate the",
            "replicate a",
            "replicate an",
            "replicate from",
            "port to",
            "porting to",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "proven model from",
            "proven model we can replicate",
            "proven playbook",
            "proven format",
            "proven scheme",
            "proven approach",
            "successful model in another market",
            "successful model abroad",
            "successful model from",
            "established service in another market",
            "established service abroad",
            "established service from",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "transferable model from",
            "business model operating elsewhere",
            "service model from another market",
            "service model from abroad",
            "service model from overseas",
            "existing business model in another market",
            "existing business model abroad",
            "modelo probado en otro mercado",
            "modelo exitoso en otro mercado",
            "modelo de negocio en otro mercado",
            "replicar en otro mercado",
            "replicar en el extranjero",
            "replicar internacionalmente",
            "نموذج أعمال مثبت في سوق آخر",
            "نموذج ناجح في سوق آخر",
            "نموذج قائم في سوق آخر",
            "تكرار نموذج في سوق آخر",
            "نقل نموذج إلى سوق آخر",
            "model from",
            "model in",
            "operates in",
        ),
        "reason": (
            "The context describes an existing model, product, or service that "
            "may be adapted or replicated across markets. Requires explicit "
            "cross-market context (another market, abroad, overseas, internationally, from another)."
        ),
    },
    "combination": {
        "aliases": (
            "combine complementary capabilities",
            "link separate capabilities",
            "joint arrangement",
            "bundle resources and demand",
            "integrate complementary resources",
            "link an available resource with industrial capacity",
            "available resource and processing capability can be linked",
            "feedstock and processing capability can be linked",
            "feedstock and transformation capability can be linked",
            "match resource with processing",
            "combinar capacidades complementarias",
            "ربط قدرات متكاملة",
            "دمج موارد وقدرات",
            "ترتيب مشترك",
            "strategic alignment",
            "JV thesis",
            "joint venture thesis",
            "partnership thesis",
            "byproduct to input",
            "industrial symbiosis",
            "three actor",
            "cold chain",
            "connecting all three",
            "logistics company",
            "empty return trips",
            "retailer needs",
            "consistent supply",
            "steel mill slag",
            "cement plant",
            "supplementary cementitious",
            "clinker factor",
            "disposal costs",
            "port has unused",
            "berth capacity",
            "rail connection",
            "integrated operator",
            "delay cost savings",
        ),
        "reason": (
            "The context explicitly describes combining or linking complementary "
            "resources, capabilities, activities, or demand."
        ),
    },
    "asset_reconfiguration": {
        "aliases": (
            "repurpose facility",
            "alternative use for asset",
            "reconfigure operation",
            "distressed plant",
            "asset turnaround",
            "reutilizar una instalación",
            "reconfigurar una operación",
            "إعادة استخدام منشأة",
            "استخدام بديل للأصل",
            "إعادة تهيئة العملية",
            "مصنع متعثر",
            "brownfield",
            "adaptive reuse",
            "last-mile logistics",
            "last mile logistics",
            "repurpose",
            "redevelop",
            "convert",
            "zoning",
            "ceiling height",
            "buy the distressed",
            "sell the land",
            "equipment has no buyers",
        ),
        "reason": (
            "The context describes changing the use, configuration, or operation "
            "of an existing asset or facility."
        ),
    },
    "price_difference": {
        "aliases": (
            "price gap between markets",
            "same product sells for different prices",
            "regional price differential",
            "cross-market price difference",
            "same product commands different prices",
            "higher price in another region",
            "different prices across regions",
            "diferencia de precios entre mercados",
            "فرق السعر بين الأسواق",
            "اختلاف الأسعار بين الأسواق",
        ),
        "reason": (
            "The context describes a geographic or market price difference that "
            "may support a cross-market mechanism."
        ),
    },
    "missing_economic_link": {
        "aliases": (
            "missing link between producer and buyer",
            "unconnected economic actors",
            "no connection between activities",
            "missing value-chain link",
            "producers and buyers are not connected",
            "producers are disconnected from buyers",
            "producers and buyers are disconnected",
            "actors are not linked",
            "enlace faltante entre productor y comprador",
            "حلقة مفقودة بين المنتج والمشتري",
            "جهات اقتصادية غير مترابطة",
        ),
        "reason": (
            "The context explicitly describes an absent or incomplete link between "
            "actors, activities, or stages of a value chain."
        ),
    },
    "import_substitution": {
        "aliases": (
            "imports exceed domestic production",
            "replace imports with local production",
            "import substitution",
            "domestic market relies on imported supply",
            "local production could replace imported supply",
            "import dependence",
            "sustitución de importaciones",
            "إحلال الواردات",
            "الواردات تتجاوز الإنتاج المحلي",
        ),
        "reason": (
            "The context describes an import-dependent market and a possible local "
            "production or supply response."
        ),
    },
}

PATHWAY_CONCEPTS = {
    "P1": ("underutilized_capacity",),
    "P2": ("unmet_demand", "import_substitution"),
    "P3": ("process_loss",),
    "P4": ("cross_market_replication", "price_difference", "import_substitution"),
    "P5": ("combination", "missing_economic_link"),
    "P6": ("asset_reconfiguration",),
}

NEGATION_ALIASES = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "absent",
    "devoid of",
    "free from",
    "no sign of",
    "no evidence of",
    "does not have",
    "does not operate",
    "does not exist",
    "is not",
    "are not",
    "was not",
    "were not",
    "has no",
    "have no",
    "had no",
    "without any",
    "sin",
    "no hay",
    "no existe",
    "no hay evidencia",
    "sin evidencia",
    "لا",
    "ليس",
    "بدون",
    "غير",
    "لا يوجد",
    "ليس هناك",
    "لا دليل على",
    "غير متوفر",
    "ما في",
    "ما فيه",
    "ماكو",
    "موجودش",
    "لا يوجد",
    "nicht",
    "kein",
    "keine",
    "keiner",
    "keines",
    "ohne",
    "fehlt",
    "not true that",
    "it is not true that",
    "it is not the case that",
    "it is false that",
    "contrary to",
    "despite",
    "although",
    "even though",
    "however",
    "but",
    "except",
    "except for",
    "other than",
    "rather than",
    "instead of",
    "لا يوجد",
    "لا صحة",
    "غير صحيح",
    "ليس صحيح",
    "خطأ",
    "كذب",
    "عكس",
    "على عكس",
    "رغم",
    "على الرغم",
    "ولكن",
    "سوى",
    "ما عدا",
    "بدل",
    "instead of",
    "no es cierto",
    "es falso",
    "contrario",
    "a pesar de",
    "aunque",
    "sin embargo",
    "pero",
    "excepto",
    "salvo",
    "en lugar de",
    "nicht wahr",
    "falsch",
    "entgegen",
    "trotz",
    "obwohl",
    "jedoch",
    "aber",
    "außer",
    "statt",
)

HYPOTHETICAL_MARKERS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
    "projected",
    "forecast",
    "scenario analysis",
    "what if",
    "suppose",
    "supposing",
    "assuming",
    "in theory",
    "theoretically",
    "on paper",
    "envisage",
    "envision",
    "contemplate",
    "consider",
    "explore",
    "investigate",
    "evaluate",
    "assess",
    "دراسة",
    "تحليل",
    "سيناريو",
    "افتراض",
    "مقترح",
    "توقع",
    "مشروط",
    "في حال",
    "لو",
    "في حالة",
    "si",
    "caso",
    "supongamos",
    "hipotéticamente",
    "proyectado",
    "pronóstico",
    "análisis de escenario",
    "maybe",
    "perhaps",
    "possibly",
    "likely",
    "probable",
    "conceivable",
    "imaginable",
    "think",
    "believe",
    "suggest",
    "propose",
    "recommend",
    "might be",
    "could be",
    "would be",
    "should",
    "ought to",
    "ربّما",
    "ربما",
    "محتمل",
    "متوقع",
    "يمكن",
    "قد",
    "ظن",
    "أعتقد",
    "أظن",
    "أتصور",
    "tal vez",
    "quizás",
    "posiblemente",
    "probablemente",
    "concebible",
    "imaginable",
    "creo",
    "pienso",
    "sugiero",
    "propongo",
    "recomiendo",
    "podría ser",
    "debería",
    "vielleicht",
    "möglicherweise",
    "wahrscheinlich",
    "denkbar",
    "vorstellbar",
    "glaube",
    "denke",
    "schlage vor",
    "empfehle",
    "könnte sein",
    "sollte",
)

GENERALIZED_REGEX_RULES = (
    {
        "id": "capacity_ratio_below_nominal",
        "concept": "underutilized_capacity",
        "patterns": (
            r"\b\d+(?:\s+percent)?\s+of\s+(?:its\s+)?"
            r"(?:rated|nameplate|nominal|design)\s+"
            r"(?:output|throughput|production|capacity)\b",
            r"\b(?:plant|line|facility|site|mill|warehouse)\s+"
            r"(?:runs?|operates?)\s+(?:at\s+)?"
            r"(?:half|one\s+third|two\s+thirds)\b",
            r"\b(?:بنصف|بنص|نصف|ربع|ثلث)\s+طاق\w*"
            r"(?:\s+(?:التصميمية|الاسمية))?\b",
        ),
        "reason": (
            "The registered wording describes output or operation below a stated "
            "nominal capacity boundary."
        ),
    },
    {
        "id": "unserved_queue_or_pending_requests",
        "concept": "unmet_demand",
        "patterns": (
            r"\b(?:waiting|wait)\s+(?:list|lists|queue|queues)\b",
            r"\b(?:orders?|requests?|appointments?|cases?|pedidos|solicitudes)\s+"
            r"(?:remain|are|were|quedan|siguen)\s+"
            r"(?:unfilled|unserved|pending|unmet|pendientes)\b",
            r"\b(?:customers?|patients?|clients?|users?)\s+(?:are\s+)?"
            r"(?:turned\s+away|left\s+without|unable\s+to\s+obtain)\b",
            r"\b(?:clinicas?|pacientes?|clientes?)\b.{0,30}\b"
            r"(?:sin\s+(?:cita|atencion|servicio)|fuera)\b",
            r"\b(?:المرضى|الزبائن|الناس)\s+ينتظرون\s+(?:دورهم|دور)\b",
        ),
        "reason": (
            "The registered wording describes requests, customers, or users that "
            "cannot currently be served."
        ),
    },
    {
        "id": "material_rejection_or_disposal",
        "concept": "process_loss",
        "patterns": (
            r"\b(?:rejected?|rejects?|scrapped?|scrap|spoiled?|spoilage|"
            r"shrinkage|rework)\b",
            r"\b(?:material|product|output|batches?)\b.{0,30}\b"
            r"(?:landfill|disposal)\b",
            r"\b(?:merma|rechazos?|desperdicio)\b",
            r"\b(?:هالك|تلف|مرفوضات)\b",
        ),
        "reason": (
            "The registered wording describes rejected, spoiled, scrapped, or "
            "disposed output within an economic process."
        ),
    },
    {
        "id": "established_operation_outside_market",
        "concept": "cross_market_replication",
        "patterns": (
            r"\b(?:service|business|format|scheme|franchise|approach)\b.{0,30}\b"
            r"(?:operates?|operated|worked|succeeded|scaled)\b.{0,40}\b"
            r"(?:overseas|internationally|foreign|abroad)\b",
            r"\b(?:servicio|negocio|modelo)\b.{0,30}\b"
            r"(?:opera|funciona|crece)\b.{0,40}\b"
            r"(?:exterior|internacional)\b",
            r"\b(?:خدمة|نموذج|شركة)\b.{0,30}\b"
            r"(?:تعمل|نجحت)\b.{0,40}\b"
            r"(?:خارج|دول\s+اخرى|اسواق\s+خارجية)\b",
        ),
        "reason": (
            "The registered wording describes an established operating model outside "
            "the current market context."
        ),
    },
    {
        "id": "cross_market_price_spread",
        "concept": "price_difference",
        "patterns": (
            r"\b(?:premium|discount|margin|price)\b.{0,30}\b"
            r"(?:higher|lower|wider|narrower|different)\b.{0,40}\b"
            r"(?:region|market|city|country)\b",
            r"\b(?:buyers?|traders?)\b.{0,30}\bpay\b.{0,30}\b"
            r"(?:more|less)\b.{0,30}\b(?:region|market|city|country)\b",
        ),
        "reason": (
            "The registered wording describes a geographic or market price spread "
            "that may warrant cross-market investigation."
        ),
    },
    {
        "id": "asset_conversion_action",
        "concept": "asset_reconfiguration",
        "patterns": (
            r"\b(?:retrofit\w*|convert\w*|refit\w*|redeploy\w*|"
            r"repurpos\w*|adapt\w*)\s+(?:an?\s+|the\s+)?"
            r"(?:warehouse|plant|factory|facility|mill|site|line|equipment)\b",
        ),
        "reason": (
            "The registered wording describes a concrete change to the use or "
            "configuration of an existing asset."
        ),
    },
)

GENERALIZED_GROUP_RULES = (
    {
        "id": "import_exposure_with_local_capability",
        "concept": "import_substitution",
        "groups": (
            (
                r"\b(?:imports?|foreign|overseas|external)\s+"
                r"(?:suppliers?|goods|inputs?|components?)\b",
            ),
            (
                r"\b(?:local|domestic)\s+"
                r"(?:producers?|manufacturers?|workshops?|suppliers?)\b",
            ),
            (r"\b(?:supply|produce|manufacture|make|serve)\b",),
        ),
        "reason": (
            "The registered wording combines external supply exposure with a stated "
            "local capability to supply, produce, or serve."
        ),
    },
    {
        "id": "discarded_output_with_input_demand",
        "concept": "combination",
        "groups": (
            (r"\b(?:mill|mills|farm|farms|producer|producers|factory|factories)\b",),
            (r"\b(?:discard\w*|dispose\w*|landfill|residue|byproduct\w*)\b",),
            (
                r"\b(?:processor|processors|manufacturer|manufacturers|"
                r"brickmaker|brickmakers|buyer|buyers)\b",
            ),
            (r"\b(?:buy\w*|import\w*|need\w*|source\w*)\b",),
        ),
        "reason": (
            "The registered wording links a discarded or surplus output with another "
            "actor's stated input demand; it is a linkage hypothesis, not a verified "
            "transaction."
        ),
    },
)

CONCEPT_COUNTER_PATTERNS = {
    "underutilized_capacity": (
        r"\b(?:full|100)\s+(?:percent\s+)?(?:capacity|utilization)\b",
        r"\bno\s+(?:spare|unused)\s+(?:capacity|shift|hours)\b",
    ),
    "unmet_demand": (
        r"\bno\s+(?:waiting|wait)\s+(?:list|queue)s?\b",
        r"\b(?:all|every)\s+(?:orders?|requests?|patients?|customers?|clients?)\s+"
        r"(?:are|is)\s+(?:met|served|filled|completed)\b",
    ),
    "process_loss": (
        r"\b(?:zero|no)\s+(?:scrap|rejections?|spoilage|waste)\b",
    ),
    "cross_market_replication": (
        r"\b(?:not|no)\s+(?:replicate|replicating|transfer|transferring)\b.{0,30}\b(?:another|other|abroad|overseas|internationally)\b",
        r"\b(?:local|domestic|this market|current market|same market)\s+only\b",
        r"\bno\s+(?:cross.?market|international|overseas|foreign)\s+(?:model|plan|expansion|replication)\b",
        r"\b(?:proven|successful|established)\s+(?:model|service|business)\s+(?:here|locally|domestically)\b",
    ),
}


def interpret_economic_context(
    investigation: dict[str, Any],
    metrics: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
    economic_model: dict[str, Any],
) -> dict[str, Any]:
    segments = _text_segments(investigation, metrics, entities, relationships)
    concepts: dict[str, dict[str, Any]] = {}
    suppressed_candidates: list[dict[str, str]] = []
    for concept_name, definition in SEMANTIC_CONCEPTS.items():
        matches = _terminology_matches(definition["aliases"], segments)
        suppressed_candidates.extend(matches["suppressed_candidates"])
        if matches["matched_terms"]:
            _record_concept(
                concepts,
                concept_name,
                basis="terminology",
                reason=definition["reason"],
                matched_terms=matches["matched_terms"],
                evidence_refs=matches["evidence_refs"],
                supporting_observations=matches["supporting_observations"],
            )

    for rule in GENERALIZED_REGEX_RULES:
        matches = _regex_rule_matches(rule, segments)
        suppressed_candidates.extend(matches["suppressed_candidates"])
        if matches["evidence_refs"]:
            _record_concept(
                concepts,
                rule["concept"],
                basis="generalized_rule",
                reason=rule["reason"],
                matched_terms=matches["matched_terms"],
                evidence_refs=matches["evidence_refs"],
                rule_ids=[rule["id"]],
                supporting_observations=matches["supporting_observations"],
            )

    for rule in GENERALIZED_GROUP_RULES:
        matches = _group_rule_matches(rule, segments)
        suppressed_candidates.extend(matches["suppressed_candidates"])
        if matches["evidence_refs"]:
            _record_concept(
                concepts,
                rule["concept"],
                basis="generalized_rule",
                reason=rule["reason"],
                matched_terms=matches["matched_terms"],
                evidence_refs=matches["evidence_refs"],
                rule_ids=[rule["id"]],
                supporting_observations=matches["supporting_observations"],
            )

    calculations = {
        calculation["id"]: calculation
        for calculation in economic_model.get("calculations", [])
    }
    _add_calculated_concept(
        concepts,
        "underutilized_capacity",
        calculations.get("EC-001"),
        lambda value: value < 1,
        (
            "The deterministic capacity-utilization calculation shows registered "
            "capacity is not fully utilized."
        ),
    )
    _add_calculated_concept(
        concepts,
        "unmet_demand",
        calculations.get("EC-002"),
        lambda value: value > 0,
        (
            "The deterministic supply-demand calculation shows demand exceeds "
            "registered supply."
        ),
    )
    _add_calculated_concept(
        concepts,
        "process_loss",
        calculations.get("EC-005"),
        lambda value: value > 0,
        (
            "The deterministic input-output calculation shows positive material "
            "loss within the registered boundary."
        ),
    )
    if investigation.get("mode") == "A2V" and investigation.get("asset_context", "").strip():
        _record_concept(
            concepts,
            "asset_reconfiguration",
            basis="structured_context",
            reason=(
                "The investigation explicitly supplies an A2V asset or operation "
                "context; no physical or commercial outcome is inferred."
            ),
            evidence_refs=["investigation:asset_context"],
            supporting_observations=[
                _observation(
                    "investigation:asset_context",
                    str(investigation.get("asset_context", "")),
                    "A2V asset context",
                    "structured_context",
                )
            ],
        )

    material_linkages = _structured_material_linkages(entities, relationships)
    for linkage in material_linkages:
        _record_concept(
            concepts,
            "combination",
            basis="structured_relationship_pattern",
            reason=(
                "Registered relationships describe a discarded or unutilized material "
                "alongside a separate input requirement for the same registered item."
            ),
            matched_terms=["structured material linkage"],
            evidence_refs=linkage["evidence_refs"],
            rule_ids=["structured_material_linkage"],
            supporting_observations=linkage["supporting_observations"],
        )

    ambiguities = _detect_concept_ambiguities(concepts, segments)

    pathway_signals: dict[str, list[dict[str, Any]]] = {}
    for pathway_id, concept_names in PATHWAY_CONCEPTS.items():
        pathway_signals[pathway_id] = []
        for concept_name in concept_names:
            concept = concepts.get(concept_name)
            if concept is None:
                continue
            pathway_signals[pathway_id].append(
                {
                    "concept": concept_name,
                    "basis": concept["basis"],
                    "matched_terms": concept["matched_terms"],
                    "evidence_refs": concept["evidence_refs"],
                    "rule_ids": concept["rule_ids"],
                    "supporting_observations": concept["supporting_observations"],
                    "conflicting_evidence_refs": concept["conflicting_evidence_refs"],
                    "reason": concept["reason"],
                }
            )

    return {
        "version": SEMANTIC_RULE_VERSION,
        "method": (
            "Deterministic multilingual terminology normalization plus explicit "
            "structured economic calculations and records."
        ),
        "concepts": concepts,
        "pathway_signals": pathway_signals,
        "registered_economic_context": _registered_economic_context(
            investigation,
            metrics,
            entities,
            relationships,
            material_linkages,
        ),
        "suppressed_candidates": suppressed_candidates,
        "ambiguities": ambiguities,
        "source_terminology_preserved": True,
        "provenance_rule": (
            "Semantic matches reference original source, claim, entity, metric, or "
            "investigation records; interpretation does not replace source content."
        ),
        "non_inference_rules": (
            "Semantic interpretation does not invent quantities, prices, costs, "
            "supply, demand, source independence, actor relationships, or "
            "commercial outcomes."
        ),
    }


def _text_segments(
    investigation: dict[str, Any],
    metrics: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    segments: list[tuple[str, str]] = []
    for field_name in (
        "title",
        "country",
        "geography",
        "market",
        "activity",
        "objective",
        "asset_context",
    ):
        value = investigation.get(field_name, "")
        if value:
            segments.append((f"investigation:{field_name}", str(value)))
    for source in investigation.get("sources", []):
        segments.append(
            (
                f"source:{source.get('id')}",
                " ".join(
                    str(source.get(field, ""))
                    for field in ("title", "data_domain", "content")
                ),
            )
        )
    for claim in investigation.get("claims", []):
        segments.append((f"claim:{claim.get('id')}", str(claim.get("text", ""))))
    for entity in entities:
        segments.append(
            (
                f"entity:{entity.get('id')}",
                " ".join(
                    str(entity.get(field, ""))
                    for field in ("entity_type", "name", "activity", "asset_context")
                ),
            )
        )
    for relationship in relationships:
        segments.append(
            (
                f"relationship:{relationship.get('id')}",
                " ".join(
                    str(relationship.get(field, ""))
                    for field in (
                        "relationship_type",
                        "flow_type",
                        "economic_activity",
                        "notes",
                    )
                ),
            )
        )
    for metric in metrics:
        segments.append(
            (
                f"metric:{metric.get('id')}",
                " ".join(
                    str(metric.get(field, ""))
                    for field in ("metric_type", "name", "economic_activity", "notes")
                ),
            )
        )
    return segments


def _terminology_matches(
    aliases: tuple[str, ...],
    segments: list[tuple[str, str]],
) -> dict[str, Any]:
    matched_terms: set[str] = set()
    evidence_refs: set[str] = set()
    supporting_observations: list[dict[str, str]] = []
    suppressed_candidates: list[dict[str, str]] = []
    for alias in aliases:
        normalized_alias = _normalize(alias)
        if not normalized_alias:
            continue
        pattern = rf"(?<!\w){re.escape(normalized_alias)}(?!\w)"
        for evidence_ref, raw_text in segments:
            normalized_text = _normalize(raw_text)
            for occurrence in re.finditer(pattern, normalized_text):
                suppression_reason = _suppression_reason(
                    normalized_text,
                    raw_text,
                    occurrence.start(),
                )
                if suppression_reason:
                    suppressed_candidates.append(
                        _suppressed_candidate(
                            evidence_ref,
                            raw_text,
                            alias,
                            suppression_reason,
                        )
                    )
                    continue
                matched_terms.add(alias)
                evidence_refs.add(evidence_ref)
                supporting_observations.append(
                    _observation(
                        evidence_ref,
                        raw_text,
                        alias,
                        "terminology",
                    )
                )
                break
    return {
        "matched_terms": sorted(matched_terms),
        "evidence_refs": sorted(evidence_refs),
        "supporting_observations": _unique_observations(supporting_observations),
        "suppressed_candidates": _unique_suppressed_candidates(suppressed_candidates),
    }


def _regex_rule_matches(
    rule: dict[str, Any],
    segments: list[tuple[str, str]],
) -> dict[str, Any]:
    matched_terms: set[str] = set()
    evidence_refs: set[str] = set()
    supporting_observations: list[dict[str, str]] = []
    suppressed_candidates: list[dict[str, str]] = []
    rule_label = f"generalized rule:{rule['id']}"
    for evidence_ref, raw_text in segments:
        normalized_text = _normalize(raw_text)
        for pattern in rule["patterns"]:
            for occurrence in re.finditer(pattern, normalized_text):
                suppression_reason = _suppression_reason(
                    normalized_text,
                    raw_text,
                    occurrence.start(),
                )
                if suppression_reason:
                    suppressed_candidates.append(
                        _suppressed_candidate(
                            evidence_ref,
                            raw_text,
                            rule_label,
                            suppression_reason,
                        )
                    )
                    continue
                matched_terms.add(rule_label)
                evidence_refs.add(evidence_ref)
                supporting_observations.append(
                    _observation(
                        evidence_ref,
                        raw_text,
                        rule_label,
                        "generalized_rule",
                    )
                )
                break
    return {
        "matched_terms": sorted(matched_terms),
        "evidence_refs": sorted(evidence_refs),
        "supporting_observations": _unique_observations(supporting_observations),
        "suppressed_candidates": _unique_suppressed_candidates(suppressed_candidates),
    }


def _group_rule_matches(
    rule: dict[str, Any],
    segments: list[tuple[str, str]],
) -> dict[str, Any]:
    matched_terms: set[str] = set()
    evidence_refs: set[str] = set()
    supporting_observations: list[dict[str, str]] = []
    suppressed_candidates: list[dict[str, str]] = []
    rule_label = f"generalized rule:{rule['id']}"
    for evidence_ref, raw_text in segments:
        normalized_text = _normalize(raw_text)
        group_matched = True
        for patterns in rule["groups"]:
            occurrence = next(
                (
                    candidate
                    for pattern in patterns
                    for candidate in re.finditer(pattern, normalized_text)
                    if not _suppression_reason(
                        normalized_text,
                        raw_text,
                        candidate.start(),
                    )
                ),
                None,
            )
            if occurrence is None:
                group_matched = False
                break
        if not group_matched:
            continue
        matched_terms.add(rule_label)
        evidence_refs.add(evidence_ref)
        supporting_observations.append(
            _observation(
                evidence_ref,
                raw_text,
                rule_label,
                "generalized_rule",
            )
        )
    return {
        "matched_terms": sorted(matched_terms),
        "evidence_refs": sorted(evidence_refs),
        "supporting_observations": _unique_observations(supporting_observations),
        "suppressed_candidates": _unique_suppressed_candidates(suppressed_candidates),
    }


def _suppression_reason(
    normalized_text: str,
    raw_text: str,
    start: int,
) -> str | None:
    if _is_negated(normalized_text, start):
        return "negated"
    if _is_hypothetical_or_question(normalized_text, raw_text, start):
        return "hypothetical_or_question"
    return None


def _is_hypothetical_or_question(
    normalized_text: str,
    raw_text: str,
    start: int,
) -> bool:
    if "?" in raw_text:
        return True
    leading_context = normalized_text[max(0, start - 80) : start]
    marker_pattern = "|".join(re.escape(marker) for marker in HYPOTHETICAL_MARKERS)
    return bool(
        re.search(
            rf"(?<!\w)(?:{marker_pattern})(?!\w)"
            rf"(?:\s+\w+){{0,8}}\s*$",
            leading_context,
        )
    )


def _observation(
    evidence_ref: str,
    raw_text: str,
    match: str,
    basis: str,
) -> dict[str, str]:
    return {
        "reference": evidence_ref,
        "excerpt": _excerpt(raw_text),
        "match": match,
        "basis": basis,
    }


def _suppressed_candidate(
    evidence_ref: str,
    raw_text: str,
    candidate: str,
    reason: str,
) -> dict[str, str]:
    return {
        "reference": evidence_ref,
        "excerpt": _excerpt(raw_text),
        "candidate": candidate,
        "reason": reason,
    }


def _excerpt(raw_text: str, limit: int = 280) -> str:
    normalized_whitespace = " ".join(str(raw_text).strip().split())
    if len(normalized_whitespace) <= limit:
        return normalized_whitespace
    return f"{normalized_whitespace[: limit - 1]}…"


def _unique_observations(
    observations: list[dict[str, str]],
) -> list[dict[str, str]]:
    deduplicated = {
        (
            observation["reference"],
            observation["match"],
            observation["basis"],
            observation["excerpt"],
        ): observation
        for observation in observations
    }
    return [
        deduplicated[key]
        for key in sorted(deduplicated)
    ]


def _unique_suppressed_candidates(
    candidates: list[dict[str, str]],
) -> list[dict[str, str]]:
    deduplicated = {
        (
            candidate["reference"],
            candidate["candidate"],
            candidate["reason"],
            candidate["excerpt"],
        ): candidate
        for candidate in candidates
    }
    return [
        deduplicated[key]
        for key in sorted(deduplicated)
    ]


def _add_calculated_concept(
    concepts: dict[str, dict[str, Any]],
    concept_name: str,
    calculation: dict[str, Any] | None,
    predicate: Any,
    reason: str,
) -> None:
    if calculation is None or calculation.get("status") != "calculated":
        return
    value = calculation.get("result")
    if not isinstance(value, (int, float)) or not predicate(value):
        return
    evidence_refs = [f"calculation:{calculation['id']}"]
    evidence_refs.extend(
        f"metric:{item['metric_id']}"
        for item in calculation.get("inputs", [])
        if item.get("metric_id") is not None
    )
    _record_concept(
        concepts,
        concept_name,
        basis="deterministic_calculation",
        reason=reason,
        evidence_refs=evidence_refs,
        supporting_observations=[
            _observation(
                f"calculation:{calculation['id']}",
                (
                    f"{calculation.get('name', calculation['id'])}: "
                    f"{calculation.get('result')}"
                ),
                calculation["id"],
                "deterministic_calculation",
            )
        ],
    )


def _record_concept(
    concepts: dict[str, dict[str, Any]],
    concept_name: str,
    *,
    basis: str,
    reason: str,
    matched_terms: list[str] | None = None,
    evidence_refs: list[str] | None = None,
    rule_ids: list[str] | None = None,
    supporting_observations: list[dict[str, str]] | None = None,
) -> None:
    concept = concepts.setdefault(
        concept_name,
        {
            "basis": [],
            "matched_terms": [],
            "evidence_refs": [],
            "rule_ids": [],
            "supporting_observations": [],
            "conflicting_evidence_refs": [],
            "reason": reason,
        },
    )
    concept["basis"] = sorted(set(concept["basis"]) | {basis})
    concept["matched_terms"] = sorted(
        set(concept["matched_terms"]) | set(matched_terms or [])
    )
    concept["evidence_refs"] = sorted(
        set(concept["evidence_refs"]) | set(evidence_refs or [])
    )
    concept["rule_ids"] = sorted(set(concept["rule_ids"]) | set(rule_ids or []))
    concept["supporting_observations"] = _unique_observations(
        concept["supporting_observations"] + list(supporting_observations or [])
    )
    concept["reason"] = reason


def _structured_material_linkages(
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    entity_names = {
        entity.get("id"): str(entity.get("name", "")).strip()
        for entity in entities
        if entity.get("id") is not None
    }
    relationship_groups: dict[int, list[dict[str, Any]]] = {}
    for relationship in relationships:
        for entity_id in (
            relationship.get("subject_entity_id"),
            relationship.get("object_entity_id"),
        ):
            if entity_id is not None:
                relationship_groups.setdefault(entity_id, []).append(relationship)

    linkages: list[dict[str, Any]] = []
    for entity_id, connected_relationships in relationship_groups.items():
        disposal_relationships = [
            relationship
            for relationship in connected_relationships
            if _relationship_has_signal(
                relationship,
                ("discard", "dispose", "waste", "landfill", "residue", "byproduct"),
            )
        ]
        input_relationships = [
            relationship
            for relationship in connected_relationships
            if _relationship_has_signal(
                relationship,
                ("purchase", "buy", "use", "consume", "need", "input", "source"),
            )
        ]
        if not disposal_relationships or not input_relationships:
            continue
        if all(
            disposal_relationship.get("id") == input_relationship.get("id")
            for disposal_relationship in disposal_relationships
            for input_relationship in input_relationships
        ):
            continue

        involved_relationships = disposal_relationships + input_relationships
        evidence_refs = [
            f"relationship:{relationship.get('id')}"
            for relationship in involved_relationships
            if relationship.get("id") is not None
        ]
        supporting_observations = [
            _observation(
                f"relationship:{relationship.get('id')}",
                _relationship_summary(relationship),
                "structured material linkage",
                "structured_relationship_pattern",
            )
            for relationship in involved_relationships
            if relationship.get("id") is not None
        ]
        linkages.append(
            {
                "shared_entity_id": entity_id,
                "shared_entity_name": entity_names.get(entity_id, ""),
                "evidence_refs": sorted(set(evidence_refs)),
                "supporting_observations": _unique_observations(
                    supporting_observations
                ),
            }
        )
    return linkages


def _relationship_has_signal(
    relationship: dict[str, Any],
    markers: tuple[str, ...],
) -> bool:
    normalized = _normalize(_relationship_summary(relationship))
    return any(marker in normalized for marker in markers)


def _relationship_summary(relationship: dict[str, Any]) -> str:
    return " ".join(
        str(relationship.get(field, ""))
        for field in (
            "relationship_type",
            "flow_type",
            "economic_activity",
            "notes",
        )
    )


def _detect_concept_ambiguities(
    concepts: dict[str, dict[str, Any]],
    segments: list[tuple[str, str]],
) -> list[dict[str, Any]]:
    ambiguities: list[dict[str, Any]] = []
    for concept_name, concept in concepts.items():
        counter_patterns = CONCEPT_COUNTER_PATTERNS.get(concept_name, ())
        if not counter_patterns:
            continue
        counter_observations: list[dict[str, str]] = []
        for evidence_ref, raw_text in segments:
            normalized_text = _normalize(raw_text)
            for pattern in counter_patterns:
                if re.search(pattern, normalized_text):
                    counter_observations.append(
                        _observation(
                            evidence_ref,
                            raw_text,
                            f"counter-evidence:{concept_name}",
                            "counter_evidence",
                        )
                    )
                    break
        if not counter_observations:
            continue
        unique_observations = _unique_observations(counter_observations)
        counter_refs = sorted(
            {observation["reference"] for observation in unique_observations}
        )
        concept["conflicting_evidence_refs"] = counter_refs
        ambiguities.append(
            {
                "concept": concept_name,
                "status": "conflicting",
                "positive_evidence_refs": concept["evidence_refs"],
                "counter_evidence_refs": counter_refs,
                "counter_observations": unique_observations,
                "note": (
                    "Conflicting registered observations require human or documented "
                    "validation; semantic screening does not resolve the conflict."
                ),
            }
        )
    return ambiguities


def _registered_economic_context(
    investigation: dict[str, Any],
    metrics: list[dict[str, Any]],
    entities: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
    material_linkages: list[dict[str, Any]],
) -> dict[str, Any]:
    activities = {
        str(value).strip()
        for value in (
            investigation.get("activity", ""),
            *[entity.get("activity", "") for entity in entities],
            *[relationship.get("economic_activity", "") for relationship in relationships],
            *[metric.get("economic_activity", "") for metric in metrics],
        )
        if str(value).strip()
    }
    return {
        "actors": [
            {
                "reference": f"entity:{entity.get('id')}",
                "entity_type": entity.get("entity_type", ""),
                "name": entity.get("name", ""),
                "activity": entity.get("activity", ""),
                "verification_status": entity.get("verification_status", "potential"),
            }
            for entity in entities
        ],
        "activities": sorted(activities),
        "relationships": [
            {
                "reference": f"relationship:{relationship.get('id')}",
                "relationship_type": relationship.get("relationship_type", ""),
                "flow_type": relationship.get("flow_type", ""),
                "economic_activity": relationship.get("economic_activity", ""),
                "verification_status": relationship.get(
                    "verification_status",
                    "potential",
                ),
                "source_id": relationship.get("source_id"),
            }
            for relationship in relationships
        ],
        "metric_refs": [
            f"metric:{metric.get('id')}"
            for metric in metrics
            if metric.get("id") is not None
        ],
        "material_linkage_signals": material_linkages,
        "rule": (
            "Only registered entities, activities, relationships, and metrics are "
            "listed here; free-text interpretation does not create facts or entities."
        ),
    }


def _normalize(value: Any) -> str:
    decomposed = unicodedata.normalize("NFKD", str(value).casefold())
    without_marks = "".join(
        character for character in decomposed if not unicodedata.combining(character)
    )
    return " ".join(re.sub(r"[^\w]+", " ", without_marks).split())


def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\w){re.escape(_normalize(alias))}"
            rf"(?:\s+\w+){{0,6}}\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES
    )
