from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator


EvidenceLevel = Literal["E0", "E1", "E2", "E3", "E4"]
OperationMode = Literal["M2O", "A2V"]
MeasurementStatus = Literal["known", "estimated", "missing", "uncertain", "unknown"]


class InvestigationCreate(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    mode: OperationMode = "M2O"
    country: str = Field(min_length=2, max_length=120)
    geography: str = Field(default="", max_length=200)
    market: str = Field(min_length=2, max_length=200)
    activity: str = Field(min_length=2, max_length=200)
    objective: str = Field(min_length=3, max_length=1000)
    asset_context: str = Field(default="", max_length=1000)

    @model_validator(mode="after")
    def require_asset_context_for_a2v(self) -> "InvestigationCreate":
        if self.mode == "A2V" and not self.asset_context.strip():
            raise ValueError("A2V investigations require an asset or operation context")
        return self


class InvestigationUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    mode: OperationMode | None = None
    country: str | None = Field(default=None, min_length=2, max_length=120)
    geography: str | None = Field(default=None, max_length=200)
    market: str | None = Field(default=None, min_length=2, max_length=200)
    activity: str | None = Field(default=None, min_length=2, max_length=200)
    objective: str | None = Field(default=None, min_length=3, max_length=1000)
    asset_context: str | None = Field(default=None, max_length=1000)


class SourceCreate(BaseModel):
    title: str = Field(min_length=2, max_length=240)
    uri: str = Field(default="", max_length=1000)
    source_type: str = Field(default="user-provided", max_length=80)
    country: str = Field(default="", max_length=120)
    data_domain: str = Field(default="", max_length=160)
    published_at: str = Field(default="", max_length=80)
    last_updated: str = Field(default="", max_length=80)
    reliability: float = Field(default=0.5, ge=0, le=1)
    independence_score: float = Field(default=0.5, ge=0, le=1)
    source_family: str = Field(default="", max_length=200)
    access_limitations: str = Field(default="", max_length=1000)
    evidence_level: EvidenceLevel = "E0"
    content: str = Field(min_length=3, max_length=20000)


class ClaimCreate(BaseModel):
    text: str = Field(min_length=3, max_length=2000)
    source_id: int | None = None
    claim_type: str = Field(default="economic-observation", max_length=120)
    evidence_level: EvidenceLevel = "E0"
    confidence: float = Field(default=0.5, ge=0, le=1)


class EntityCreate(BaseModel):
    entity_type: str = Field(min_length=2, max_length=80)
    name: str = Field(min_length=2, max_length=240)
    country: str = Field(default="", max_length=120)
    geography: str = Field(default="", max_length=200)
    activity: str = Field(default="", max_length=200)
    asset_context: str = Field(default="", max_length=1000)
    verification_status: str = Field(default="potential", max_length=80)
    confidence: float = Field(default=0.5, ge=0, le=1)


class RelationshipCreate(BaseModel):
    subject_entity_id: int
    object_entity_id: int
    relationship_type: str = Field(min_length=2, max_length=120)
    direction: str = Field(default="subject-to-object", max_length=80)
    flow_type: str = Field(default="relationship", max_length=80)
    economic_activity: str = Field(default="", max_length=200)
    quantity: float | None = None
    quantity_unit: str = Field(default="", max_length=80)
    quantity_status: MeasurementStatus = "unknown"
    value_amount: float | None = None
    currency: str = Field(default="", max_length=12)
    value_status: MeasurementStatus = "unknown"
    time_period: str = Field(default="", max_length=120)
    ownership_control: str = Field(default="", max_length=120)
    valid_from: str = Field(default="", max_length=80)
    valid_to: str = Field(default="", max_length=80)
    verification_status: str = Field(default="potential", max_length=80)
    confidence: float = Field(default=0.5, ge=0, le=1)
    source_id: int | None = None
    notes: str = Field(default="", max_length=1000)


class EconomicMetricCreate(BaseModel):
    entity_id: int | None = None
    metric_type: str = Field(min_length=2, max_length=100)
    name: str = Field(min_length=2, max_length=200)
    value: float | None = None
    unit: str = Field(default="", max_length=80)
    currency: str = Field(default="", max_length=12)
    status: MeasurementStatus = "known"
    verification_status: str = Field(default="potential", max_length=80)
    period_start: str = Field(default="", max_length=80)
    period_end: str = Field(default="", max_length=80)
    economic_activity: str = Field(default="", max_length=200)
    source_id: int | None = None
    notes: str = Field(default="", max_length=1000)


class EconomicMetricUpdate(BaseModel):
    entity_id: int | None = None
    metric_type: str | None = Field(default=None, min_length=2, max_length=100)
    name: str | None = Field(default=None, min_length=2, max_length=200)
    value: float | None = None
    unit: str | None = Field(default=None, max_length=80)
    currency: str | None = Field(default=None, max_length=12)
    status: MeasurementStatus | None = None
    verification_status: str | None = Field(default=None, max_length=80)
    period_start: str | None = Field(default=None, max_length=80)
    period_end: str | None = Field(default=None, max_length=80)
    economic_activity: str | None = Field(default=None, max_length=200)
    source_id: int | None = None
    notes: str | None = Field(default=None, max_length=1000)


class LoginRequest(BaseModel):
    token: str = Field(min_length=1, max_length=500)
