from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATABASE_PATH = PROJECT_ROOT / "data" / "opportunity_factory.sqlite3"


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def resolve_database_path(database_path: str | Path | None = None) -> Path:
    configured_path = database_path or DEFAULT_DATABASE_PATH
    path = Path(configured_path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def connect(database_path: str | Path | None = None) -> sqlite3.Connection:
    connection = sqlite3.connect(resolve_database_path(database_path))
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db(database_path: str | Path | None = None) -> None:
    with connect(database_path) as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS investigations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                mode TEXT NOT NULL DEFAULT 'M2O',
                country TEXT NOT NULL,
                geography TEXT NOT NULL DEFAULT '',
                market TEXT NOT NULL,
                activity TEXT NOT NULL,
                objective TEXT NOT NULL,
                asset_context TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                uri TEXT NOT NULL DEFAULT '',
                source_type TEXT NOT NULL DEFAULT 'user-provided',
                country TEXT NOT NULL DEFAULT '',
                data_domain TEXT NOT NULL DEFAULT '',
                published_at TEXT NOT NULL DEFAULT '',
                last_updated TEXT NOT NULL DEFAULT '',
                reliability REAL NOT NULL DEFAULT 0.5,
                independence_score REAL NOT NULL DEFAULT 0.5,
                source_family TEXT NOT NULL DEFAULT '',
                access_limitations TEXT NOT NULL DEFAULT '',
                evidence_level TEXT NOT NULL DEFAULT 'E0',
                content TEXT NOT NULL,
                file_name TEXT NOT NULL DEFAULT '',
                file_path TEXT NOT NULL DEFAULT '',
                file_content_type TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS claims (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                source_id INTEGER REFERENCES sources(id) ON DELETE SET NULL,
                text TEXT NOT NULL,
                claim_type TEXT NOT NULL DEFAULT 'economic-observation',
                evidence_level TEXT NOT NULL DEFAULT 'E0',
                confidence REAL NOT NULL DEFAULT 0.5,
                status TEXT NOT NULL DEFAULT 'unreviewed',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS economic_entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                entity_type TEXT NOT NULL,
                name TEXT NOT NULL,
                country TEXT NOT NULL DEFAULT '',
                geography TEXT NOT NULL DEFAULT '',
                activity TEXT NOT NULL DEFAULT '',
                asset_context TEXT NOT NULL DEFAULT '',
                verification_status TEXT NOT NULL DEFAULT 'potential',
                confidence REAL NOT NULL DEFAULT 0.5,
                metadata_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                subject_entity_id INTEGER NOT NULL REFERENCES economic_entities(id) ON DELETE CASCADE,
                object_entity_id INTEGER NOT NULL REFERENCES economic_entities(id) ON DELETE CASCADE,
                relationship_type TEXT NOT NULL,
                direction TEXT NOT NULL DEFAULT 'subject-to-object',
                flow_type TEXT NOT NULL DEFAULT 'relationship',
                economic_activity TEXT NOT NULL DEFAULT '',
                quantity REAL,
                quantity_unit TEXT NOT NULL DEFAULT '',
                quantity_status TEXT NOT NULL DEFAULT 'unknown',
                value_amount REAL,
                currency TEXT NOT NULL DEFAULT '',
                value_status TEXT NOT NULL DEFAULT 'unknown',
                time_period TEXT NOT NULL DEFAULT '',
                ownership_control TEXT NOT NULL DEFAULT '',
                valid_from TEXT NOT NULL DEFAULT '',
                valid_to TEXT NOT NULL DEFAULT '',
                verification_status TEXT NOT NULL DEFAULT 'potential',
                confidence REAL NOT NULL DEFAULT 0.5,
                source_id INTEGER REFERENCES sources(id) ON DELETE SET NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS analysis_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                methodology_version TEXT NOT NULL,
                ruleset_version TEXT NOT NULL,
                engine_version TEXT NOT NULL,
                input_snapshot_json TEXT NOT NULL,
                result_json TEXT NOT NULL DEFAULT '{}',
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS opportunities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                analysis_run_id INTEGER NOT NULL REFERENCES analysis_runs(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                origin TEXT NOT NULL,
                pathway TEXT NOT NULL,
                evidence_strength TEXT NOT NULL,
                confidence REAL NOT NULL,
                economic_logic TEXT NOT NULL,
                assumptions_json TEXT NOT NULL,
                unknowns_json TEXT NOT NULL,
                hard_gates_json TEXT NOT NULL,
                pathway_evaluations_json TEXT NOT NULL,
                quality_json TEXT NOT NULL DEFAULT '{}',
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS economic_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                entity_id INTEGER REFERENCES economic_entities(id) ON DELETE SET NULL,
                metric_type TEXT NOT NULL,
                name TEXT NOT NULL,
                value REAL,
                unit TEXT NOT NULL DEFAULT '',
                currency TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'known',
                verification_status TEXT NOT NULL DEFAULT 'potential',
                period_start TEXT NOT NULL DEFAULT '',
                period_end TEXT NOT NULL DEFAULT '',
                economic_activity TEXT NOT NULL DEFAULT '',
                source_id INTEGER REFERENCES sources(id) ON DELETE SET NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                investigation_id INTEGER REFERENCES investigations(id) ON DELETE CASCADE,
                event_type TEXT NOT NULL,
                details_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        _ensure_column(connection, "investigations", "mode", "TEXT NOT NULL DEFAULT 'M2O'")
        _ensure_column(connection, "sources", "source_family", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "sources", "file_name", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "sources", "file_path", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(
            connection,
            "sources",
            "file_content_type",
            "TEXT NOT NULL DEFAULT ''",
        )
        for column_name, column_definition in (
            ("flow_type", "TEXT NOT NULL DEFAULT 'relationship'"),
            ("economic_activity", "TEXT NOT NULL DEFAULT ''"),
            ("quantity", "REAL"),
            ("quantity_unit", "TEXT NOT NULL DEFAULT ''"),
            ("quantity_status", "TEXT NOT NULL DEFAULT 'unknown'"),
            ("value_amount", "REAL"),
            ("currency", "TEXT NOT NULL DEFAULT ''"),
            ("value_status", "TEXT NOT NULL DEFAULT 'unknown'"),
            ("time_period", "TEXT NOT NULL DEFAULT ''"),
            ("ownership_control", "TEXT NOT NULL DEFAULT ''"),
        ):
            _ensure_column(
                connection,
                "relationships",
                column_name,
                column_definition,
            )
        _ensure_column(connection, "opportunities", "quality_json", "TEXT NOT NULL DEFAULT '{}'")
        _ensure_column(connection, "analysis_runs", "result_json", "TEXT NOT NULL DEFAULT '{}'")
        _ensure_column(
            connection,
            "economic_metrics",
            "verification_status",
            "TEXT NOT NULL DEFAULT 'potential'",
        )


def _ensure_column(
    connection: sqlite3.Connection,
    table_name: str,
    column_name: str,
    column_definition: str,
) -> None:
    columns = {
        row["name"]
        for row in connection.execute(f"PRAGMA table_info({table_name})").fetchall()
    }
    if column_name not in columns:
        connection.execute(
            f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_definition}"
        )


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def rows_to_dicts(rows: Iterable[sqlite3.Row]) -> list[dict[str, Any]]:
    return [dict(row) for row in rows]


def json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def parse_json(value: str, default: Any) -> Any:
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default


def record_audit(
    connection: sqlite3.Connection,
    investigation_id: int | None,
    event_type: str,
    details: dict[str, Any],
) -> None:
    connection.execute(
        """
        INSERT INTO audit_events (investigation_id, event_type, details_json, created_at)
        VALUES (?, ?, ?, ?)
        """,
        (investigation_id, event_type, json_text(details), utc_now()),
    )
