from __future__ import annotations

import hashlib
import hmac
import os

from fastapi import HTTPException, Request


ACCESS_TOKEN = os.getenv("OF_ACCESS_TOKEN", "dev-owner")
SESSION_SECRET = os.getenv("OF_SESSION_SECRET", "opportunity-factory-local-session")
SESSION_COOKIE = "of_session"


def session_digest() -> str:
    return hmac.new(
        SESSION_SECRET.encode("utf-8"),
        ACCESS_TOKEN.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def has_api_access(request: Request) -> bool:
    authorization = request.headers.get("authorization", "")
    return hmac.compare_digest(
        authorization.removeprefix("Bearer ").strip(),
        ACCESS_TOKEN,
    )


def has_html_access(request: Request) -> bool:
    return hmac.compare_digest(
        request.cookies.get(SESSION_COOKIE, ""),
        session_digest(),
    )


def require_api_access(request: Request) -> None:
    if not has_api_access(request):
        raise HTTPException(status_code=401, detail="Bearer access token required")
