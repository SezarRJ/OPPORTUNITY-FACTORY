"""OPPORTUNITY FACTORY application package."""
