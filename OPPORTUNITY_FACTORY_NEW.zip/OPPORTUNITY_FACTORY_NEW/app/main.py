from __future__ import annotations

import os
import json
from pathlib import Path
from typing import Any
from uuid import uuid4

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .db import connect, init_db
from .repository import (
    add_claim,
    add_entity,
    add_metric,
    add_relationship,
    add_source,
    create_analysis_run,
    create_investigation,
    get_analysis_run,
    get_investigation,
    list_investigations,
    update_metric,
    update_investigation,
)
from .schemas import (
    ClaimCreate,
    EconomicMetricCreate,
    EconomicMetricUpdate,
    EntityCreate,
    InvestigationCreate,
    InvestigationUpdate,
    RelationshipCreate,
    SourceCreate,
)
from .security import (
    ACCESS_TOKEN,
    SESSION_COOKIE,
    has_api_access,
    has_html_access,
    require_api_access,
    session_digest,
)
from .services.analysis import (
    ENGINE_VERSION,
    METHODOLOGY_VERSION,
    RULESET_VERSION,
    analyze_investigation,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATABASE_PATH = PROJECT_ROOT / "data" / "opportunity_factory.sqlite3"
TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
STATIC_DIR = Path(__file__).resolve().parent / "static"


def create_app(database_path: str | Path | None = None) -> FastAPI:
    configured_path = database_path or os.getenv("OF_DATABASE_PATH") or DEFAULT_DATABASE_PATH
    app = FastAPI(
        title="OPPORTUNITY FACTORY",
        version="0.1.0",
        description="Global Economic Intelligence & Opportunity Creation System",
    )
    app.state.database_path = str(configured_path)
    init_db(app.state.database_path)
    templates = Jinja2Templates(directory=str(TEMPLATE_DIR))
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "service": "opportunity-factory",
            "identity": "Global Economic Intelligence & Opportunity Creation System",
        }

    @app.get("/api/investigations")
    def api_list_investigations(request: Request) -> list[dict[str, Any]]:
        require_api_access(request)
        with connect(app.state.database_path) as connection:
            return list_investigations(connection)

    @app.post("/api/investigations", status_code=201)
    def api_create_investigation(
        payload: InvestigationCreate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        with connect(app.state.database_path) as connection:
            return create_investigation(connection, payload.model_dump())

    @app.patch("/api/investigations/{investigation_id}")
    def api_update_investigation(
        investigation_id: int,
        payload: InvestigationUpdate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return update_investigation(
                    connection,
                    investigation_id,
                    payload.model_dump(exclude_unset=True),
                )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/investigations/{investigation_id}")
    def api_get_investigation(
        investigation_id: int,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return get_investigation(connection, investigation_id, include_children=True)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/sources", status_code=201)
    def api_add_source(
        investigation_id: int,
        payload: SourceCreate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return add_source(connection, investigation_id, payload.model_dump())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/source-file", status_code=201)
    async def api_add_source_file(
        investigation_id: int,
        request: Request,
        file: UploadFile = File(...),
        title: str = Form(""),
        source_type: str = Form("user-upload"),
        data_domain: str = Form(""),
        last_updated: str = Form(""),
        reliability: float = Form(0.5),
        independence_score: float = Form(0.5),
        source_family: str = Form(""),
        access_limitations: str = Form(""),
        evidence_level: str = Form("E0"),
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            payload = await _uploaded_source_payload(
                app.state.database_path,
                investigation_id,
                file,
                title=title,
                source_type=source_type,
                data_domain=data_domain,
                last_updated=last_updated,
                reliability=reliability,
                independence_score=independence_score,
                source_family=source_family,
                access_limitations=access_limitations,
                evidence_level=evidence_level,
            )
            with connect(app.state.database_path) as connection:
                return add_source(connection, investigation_id, payload)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/claims", status_code=201)
    def api_add_claim(
        investigation_id: int,
        payload: ClaimCreate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return add_claim(connection, investigation_id, payload.model_dump())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/entities", status_code=201)
    def api_add_entity(
        investigation_id: int,
        payload: EntityCreate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return add_entity(connection, investigation_id, payload.model_dump())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/relationships", status_code=201)
    def api_add_relationship(
        investigation_id: int,
        payload: RelationshipCreate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return add_relationship(connection, investigation_id, payload.model_dump())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/metrics", status_code=201)
    def api_add_metric(
        investigation_id: int,
        payload: EconomicMetricCreate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return add_metric(connection, investigation_id, payload.model_dump())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.patch("/api/investigations/{investigation_id}/metrics/{metric_id}")
    def api_update_metric(
        investigation_id: int,
        metric_id: int,
        payload: EconomicMetricUpdate,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                return update_metric(
                    connection,
                    investigation_id,
                    metric_id,
                    payload.model_dump(exclude_unset=True),
                )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/investigations/{investigation_id}/analysis")
    def api_run_analysis(
        investigation_id: int,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        return _run_analysis(app.state.database_path, investigation_id)

    @app.get("/api/investigations/{investigation_id}/analysis/latest")
    def api_latest_analysis(
        investigation_id: int,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                bundle = get_investigation(connection, investigation_id, include_children=True)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        if not bundle["analysis_runs"]:
            raise HTTPException(status_code=404, detail="No analysis run exists yet")
        return bundle["analysis_runs"][0]

    @app.post("/api/investigations/{investigation_id}/analysis/{analysis_run_id}/replay")
    def api_replay_analysis(
        investigation_id: int,
        analysis_run_id: int,
        request: Request,
    ) -> dict[str, Any]:
        require_api_access(request)
        try:
            with connect(app.state.database_path) as connection:
                analysis_run = get_analysis_run(
                    connection,
                    investigation_id,
                    analysis_run_id,
                )
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        replayed = analyze_investigation(analysis_run["input_snapshot"])
        original = analysis_run["result"]
        reproducible = json.dumps(original, sort_keys=True) == json.dumps(
            replayed,
            sort_keys=True,
        )
        return {
            "analysis_run_id": analysis_run_id,
            "reproducible": reproducible,
            "original_versions": {
                "methodology_version": analysis_run["methodology_version"],
                "ruleset_version": analysis_run["ruleset_version"],
                "engine_version": analysis_run["engine_version"],
            },
            "original_result": original,
            "replayed_result": replayed,
        }

    @app.get("/login", response_class=HTMLResponse)
    def login_page(request: Request) -> Any:
        if has_html_access(request):
            return RedirectResponse("/", status_code=303)
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"request": request, "error": ""},
        )

    @app.post("/login", response_class=HTMLResponse)
    def login(
        request: Request,
        token: str = Form(""),
    ) -> Any:
        if token != ACCESS_TOKEN:
            return templates.TemplateResponse(
                request=request,
                name="login.html",
                context={"request": request, "error": "Invalid local owner token."},
                status_code=401,
            )
        response = RedirectResponse("/", status_code=303)
        response.set_cookie(
            SESSION_COOKIE,
            session_digest(),
            httponly=True,
            samesite="lax",
        )
        return response

    @app.post("/logout")
    def logout() -> RedirectResponse:
        response = RedirectResponse("/login", status_code=303)
        response.delete_cookie(SESSION_COOKIE)
        return response

    @app.get("/", response_class=HTMLResponse)
    def dashboard(request: Request) -> Any:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        with connect(app.state.database_path) as connection:
            investigations = list_investigations(connection)
        return templates.TemplateResponse(
            request=request,
            name="dashboard.html",
            context={
                "request": request,
                "investigations": investigations,
                "identity": "Global Economic Intelligence & Opportunity Creation System",
            },
        )

    @app.post("/investigations", response_class=HTMLResponse)
    def html_create_investigation(
        request: Request,
        title: str = Form(""),
        mode: str = Form("M2O"),
        country: str = Form(""),
        geography: str = Form(""),
        market: str = Form(""),
        activity: str = Form(""),
        objective: str = Form(""),
        asset_context: str = Form(""),
    ) -> Any:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = InvestigationCreate(
            title=title,
            mode=mode,
            country=country,
            geography=geography,
            market=market,
            activity=activity,
            objective=objective,
            asset_context=asset_context,
        )
        with connect(app.state.database_path) as connection:
            investigation = create_investigation(connection, payload.model_dump())
        return RedirectResponse(
            f"/investigations/{investigation['id']}",
            status_code=303,
        )

    @app.post("/investigations/{investigation_id}/edit")
    def html_update_investigation(
        request: Request,
        investigation_id: int,
        title: str = Form(""),
        mode: str = Form("M2O"),
        country: str = Form(""),
        geography: str = Form(""),
        market: str = Form(""),
        activity: str = Form(""),
        objective: str = Form(""),
        asset_context: str = Form(""),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = InvestigationUpdate(
            title=title,
            mode=mode,
            country=country,
            geography=geography,
            market=market,
            activity=activity,
            objective=objective,
            asset_context=asset_context,
        )
        with connect(app.state.database_path) as connection:
            update_investigation(connection, investigation_id, payload.model_dump())
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.get("/investigations/{investigation_id}", response_class=HTMLResponse)
    def investigation_page(request: Request, investigation_id: int) -> Any:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        try:
            with connect(app.state.database_path) as connection:
                bundle = get_investigation(connection, investigation_id, include_children=True)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        latest_result = (
            bundle["analysis_runs"][0]["result"] if bundle["analysis_runs"] else None
        )
        return templates.TemplateResponse(
            request=request,
            name="investigation.html",
            context={
                "request": request,
                "investigation": bundle,
                "latest_result": latest_result,
                "error": "",
            },
        )

    @app.post("/investigations/{investigation_id}/sources")
    def html_add_source(
        request: Request,
        investigation_id: int,
        title: str = Form(""),
        uri: str = Form(""),
        source_type: str = Form("user-provided"),
        data_domain: str = Form(""),
        last_updated: str = Form(""),
        reliability: float = Form(0.5),
        independence_score: float = Form(0.5),
        source_family: str = Form(""),
        access_limitations: str = Form(""),
        evidence_level: str = Form("E0"),
        content: str = Form(""),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = SourceCreate(
            title=title,
            uri=uri,
            source_type=source_type,
            data_domain=data_domain,
            last_updated=last_updated,
            reliability=reliability,
            independence_score=independence_score,
            source_family=source_family,
            access_limitations=access_limitations,
            evidence_level=evidence_level,
            content=content,
        )
        with connect(app.state.database_path) as connection:
            add_source(connection, investigation_id, payload.model_dump())
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/source-file")
    async def html_add_source_file(
        request: Request,
        investigation_id: int,
        file: UploadFile = File(...),
        title: str = Form(""),
        source_type: str = Form("user-upload"),
        data_domain: str = Form(""),
        last_updated: str = Form(""),
        reliability: float = Form(0.5),
        independence_score: float = Form(0.5),
        source_family: str = Form(""),
        access_limitations: str = Form(""),
        evidence_level: str = Form("E0"),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = await _uploaded_source_payload(
            app.state.database_path,
            investigation_id,
            file,
            title=title,
            source_type=source_type,
            data_domain=data_domain,
            last_updated=last_updated,
            reliability=reliability,
            independence_score=independence_score,
            source_family=source_family,
            access_limitations=access_limitations,
            evidence_level=evidence_level,
        )
        with connect(app.state.database_path) as connection:
            add_source(connection, investigation_id, payload)
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/claims")
    def html_add_claim(
        request: Request,
        investigation_id: int,
        text: str = Form(""),
        source_id: int | None = Form(None),
        claim_type: str = Form("economic-observation"),
        evidence_level: str = Form("E0"),
        confidence: float = Form(0.5),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = ClaimCreate(
            text=text,
            source_id=source_id,
            claim_type=claim_type,
            evidence_level=evidence_level,
            confidence=confidence,
        )
        with connect(app.state.database_path) as connection:
            add_claim(connection, investigation_id, payload.model_dump())
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/entities")
    def html_add_entity(
        request: Request,
        investigation_id: int,
        entity_type: str = Form(""),
        name: str = Form(""),
        country: str = Form(""),
        geography: str = Form(""),
        activity: str = Form(""),
        asset_context: str = Form(""),
        verification_status: str = Form("potential"),
        confidence: float = Form(0.5),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = EntityCreate(
            entity_type=entity_type,
            name=name,
            country=country,
            geography=geography,
            activity=activity,
            asset_context=asset_context,
            verification_status=verification_status,
            confidence=confidence,
        )
        with connect(app.state.database_path) as connection:
            add_entity(connection, investigation_id, payload.model_dump())
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/relationships")
    def html_add_relationship(
        request: Request,
        investigation_id: int,
        subject_entity_id: int = Form(...),
        object_entity_id: int = Form(...),
        relationship_type: str = Form(""),
        direction: str = Form("subject-to-object"),
        flow_type: str = Form("relationship"),
        economic_activity: str = Form(""),
        quantity: float | None = Form(None),
        quantity_unit: str = Form(""),
        quantity_status: str = Form("unknown"),
        value_amount: float | None = Form(None),
        currency: str = Form(""),
        value_status: str = Form("unknown"),
        time_period: str = Form(""),
        ownership_control: str = Form(""),
        valid_from: str = Form(""),
        valid_to: str = Form(""),
        verification_status: str = Form("potential"),
        confidence: float = Form(0.5),
        source_id: int | None = Form(None),
        notes: str = Form(""),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = RelationshipCreate(
            subject_entity_id=subject_entity_id,
            object_entity_id=object_entity_id,
            relationship_type=relationship_type,
            direction=direction,
            flow_type=flow_type,
            economic_activity=economic_activity,
            quantity=quantity,
            quantity_unit=quantity_unit,
            quantity_status=quantity_status,
            value_amount=value_amount,
            currency=currency,
            value_status=value_status,
            time_period=time_period,
            ownership_control=ownership_control,
            valid_from=valid_from,
            valid_to=valid_to,
            verification_status=verification_status,
            confidence=confidence,
            source_id=source_id,
            notes=notes,
        )
        with connect(app.state.database_path) as connection:
            add_relationship(connection, investigation_id, payload.model_dump())
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/metrics")
    def html_add_metric(
        request: Request,
        investigation_id: int,
        entity_id: int | None = Form(None),
        metric_type: str = Form(""),
        name: str = Form(""),
        value: float | None = Form(None),
        unit: str = Form(""),
        currency: str = Form(""),
        status: str = Form("known"),
        verification_status: str = Form("potential"),
        period_start: str = Form(""),
        period_end: str = Form(""),
        economic_activity: str = Form(""),
        source_id: int | None = Form(None),
        notes: str = Form(""),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = EconomicMetricCreate(
            entity_id=entity_id,
            metric_type=metric_type,
            name=name,
            value=value,
            unit=unit,
            currency=currency,
            status=status,
            verification_status=verification_status,
            period_start=period_start,
            period_end=period_end,
            economic_activity=economic_activity,
            source_id=source_id,
            notes=notes,
        )
        with connect(app.state.database_path) as connection:
            add_metric(connection, investigation_id, payload.model_dump())
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/metrics/{metric_id}")
    def html_update_metric(
        request: Request,
        investigation_id: int,
        metric_id: int,
        entity_id: int | None = Form(None),
        metric_type: str = Form(""),
        name: str = Form(""),
        value: float | None = Form(None),
        unit: str = Form(""),
        currency: str = Form(""),
        status: str = Form("known"),
        verification_status: str = Form("potential"),
        period_start: str = Form(""),
        period_end: str = Form(""),
        economic_activity: str = Form(""),
        source_id: int | None = Form(None),
        notes: str = Form(""),
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        payload = EconomicMetricUpdate(
            entity_id=entity_id,
            metric_type=metric_type,
            name=name,
            value=value,
            unit=unit,
            currency=currency,
            status=status,
            verification_status=verification_status,
            period_start=period_start,
            period_end=period_end,
            economic_activity=economic_activity,
            source_id=source_id,
            notes=notes,
        )
        with connect(app.state.database_path) as connection:
            update_metric(
                connection,
                investigation_id,
                metric_id,
                payload.model_dump(exclude_unset=True),
            )
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.post("/investigations/{investigation_id}/analysis")
    def html_run_analysis(
        request: Request,
        investigation_id: int,
    ) -> RedirectResponse:
        if not has_html_access(request):
            return RedirectResponse("/login", status_code=303)
        _run_analysis(app.state.database_path, investigation_id)
        return RedirectResponse(f"/investigations/{investigation_id}", status_code=303)

    @app.exception_handler(ValueError)
    async def value_error_handler(
        request: Request,
        exc: ValueError,
    ) -> JSONResponse:
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    return app


async def _uploaded_source_payload(
    database_path: str,
    investigation_id: int,
    file: UploadFile,
    **metadata: Any,
) -> dict[str, Any]:
    filename = Path(file.filename or "evidence.bin").name
    if filename in {"", ".", ".."}:
        raise ValueError("Uploaded evidence must have a valid filename")
    content_bytes = await file.read(2_000_001)
    if len(content_bytes) > 2_000_000:
        raise ValueError("Uploaded evidence exceeds the 2 MB first-slice limit")
    storage_root = Path(database_path).resolve().parent / "evidence" / str(investigation_id)
    storage_root.mkdir(parents=True, exist_ok=True)
    stored_name = f"{uuid4().hex}-{filename}"
    stored_path = storage_root / stored_name
    stored_path.write_bytes(content_bytes)
    content_type = file.content_type or "application/octet-stream"
    is_text = content_type.startswith("text/") or Path(filename).suffix.lower() in {
        ".txt",
        ".md",
        ".csv",
        ".json",
    }
    if is_text:
        content = content_bytes.decode("utf-8", errors="replace")
    else:
        content = (
            "Binary evidence stored locally. Text extraction is not performed in "
            "the first slice."
        )
    relative_path = stored_path.relative_to(Path(database_path).resolve().parent).as_posix()
    return {
        "title": metadata.get("title") or filename,
        "uri": f"local://{relative_path}",
        "source_type": metadata.get("source_type", "user-upload"),
        "data_domain": metadata.get("data_domain", ""),
        "last_updated": metadata.get("last_updated", ""),
        "reliability": metadata.get("reliability", 0.5),
        "independence_score": metadata.get("independence_score", 0.5),
        "source_family": metadata.get("source_family", ""),
        "access_limitations": metadata.get("access_limitations", ""),
        "evidence_level": metadata.get("evidence_level", "E0"),
        "content": content,
        "file_name": filename,
        "file_path": relative_path,
        "file_content_type": content_type,
    }


def _run_analysis(database_path: str, investigation_id: int) -> dict[str, Any]:
    with connect(database_path) as connection:
        bundle = get_investigation(connection, investigation_id, include_children=True)
        result = analyze_investigation(bundle)
        input_snapshot = {
            key: bundle[key]
            for key in (
                "id",
                "title",
                "country",
                "geography",
                "market",
                "activity",
                "objective",
                "asset_context",
                "mode",
                "sources",
                "claims",
                "entities",
                "relationships",
                "metrics",
            )
        }
        input_snapshot["analysis_date"] = result["analysis_date"]
        analysis_run = create_analysis_run(
            connection,
            investigation_id,
            METHODOLOGY_VERSION,
            RULESET_VERSION,
            ENGINE_VERSION,
            input_snapshot,
            result,
            result["opportunities"],
        )
        return {
            "analysis_run": analysis_run,
            "result": result,
        }


app = create_app()
