from __future__ import annotations

import re
import sqlite3
from math import isfinite
from typing import Any

from .db import json_text, parse_json, record_audit, utc_now


def _require_investigation(connection: sqlite3.Connection, investigation_id: int) -> None:
    row = connection.execute(
        "SELECT id FROM investigations WHERE id = ?",
        (investigation_id,),
    ).fetchone()
    if row is None:
        raise ValueError(f"Investigation {investigation_id} was not found")


def _require_source(
    connection: sqlite3.Connection,
    investigation_id: int,
    source_id: int,
) -> None:
    row = connection.execute(
        "SELECT id FROM sources WHERE id = ? AND investigation_id = ?",
        (source_id, investigation_id),
    ).fetchone()
    if row is None:
        raise ValueError(f"Source {source_id} does not belong to investigation {investigation_id}")


def _require_entity(
    connection: sqlite3.Connection,
    investigation_id: int,
    entity_id: int,
) -> None:
    row = connection.execute(
        """
        SELECT id FROM economic_entities
        WHERE id = ? AND investigation_id = ?
        """,
        (entity_id, investigation_id),
    ).fetchone()
    if row is None:
        raise ValueError(f"Entity {entity_id} does not belong to investigation {investigation_id}")


def _require_metric(
    connection: sqlite3.Connection,
    investigation_id: int,
    metric_id: int,
) -> sqlite3.Row:
    row = connection.execute(
        """
        SELECT * FROM economic_metrics
        WHERE id = ? AND investigation_id = ?
        """,
        (metric_id, investigation_id),
    ).fetchone()
    if row is None:
        raise ValueError(f"Metric {metric_id} was not found for investigation {investigation_id}")
    return row


def _validate_metric_payload(payload: dict[str, Any]) -> None:
    status = payload.get("status", "known")
    value = payload.get("value")
    verification_status = payload.get("verification_status", "potential")
    if verification_status == "verified" and (
        status not in {"known", "estimated"}
        or value is None
        or payload.get("source_id") is None
    ):
        raise ValueError(
            "Verified economic metrics require a known or estimated value and a source"
        )
    if status in {"unknown", "missing", "uncertain"} and value is not None:
        raise ValueError("Unknown, missing, or uncertain metrics must not assert a numeric value")
    if value is None or status not in {"known", "estimated"}:
        return
    try:
        numeric_value = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("Economic metric values must be numeric") from exc
    if not numeric_value == numeric_value or numeric_value in {float("inf"), float("-inf")}:
        raise ValueError("Economic metric values must be finite")
    normalized = re.sub(
        r"[^a-z0-9]+",
        " ",
        f"{payload.get('metric_type', '')} {payload.get('name', '')}".lower(),
    )
    non_negative_terms = (
        "capacity",
        "utilized",
        "supply",
        "demand",
        "quantity",
        "revenue",
        "cost",
        "resource",
        "recover",
        "value",
        "price",
        "margin",
    )
    if numeric_value < 0 and any(term in normalized for term in non_negative_terms):
        raise ValueError(
            "Negative values are not accepted for non-negative economic measurements"
        )


def _validate_relationship_payload(payload: dict[str, Any]) -> None:
    for field_name, status_name in (
        ("quantity", "quantity_status"),
        ("value_amount", "value_status"),
    ):
        value = payload.get(field_name)
        status = payload.get(status_name, "unknown")
        if status in {"unknown", "missing", "uncertain"} and value is not None:
            raise ValueError(
                f"{field_name} must be empty when {status_name} is {status}"
            )
        if status in {"known", "estimated"} and value is None:
            raise ValueError(
                f"{field_name} is required when {status_name} is {status}"
            )
        if value is None:
            continue
        try:
            numeric_value = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{field_name} must be numeric") from exc
        if not isfinite(numeric_value):
            raise ValueError(f"{field_name} must be finite")
        if numeric_value < 0:
            raise ValueError(f"{field_name} must not be negative")


def create_investigation(
    connection: sqlite3.Connection,
    payload: dict[str, Any],
) -> dict[str, Any]:
    created_at = utc_now()
    cursor = connection.execute(
        """
        INSERT INTO investigations (
            title, mode, country, geography, market, activity, objective, asset_context, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            payload["title"],
            payload.get("mode", "M2O"),
            payload["country"],
            payload.get("geography", ""),
            payload["market"],
            payload["activity"],
            payload["objective"],
            payload.get("asset_context", ""),
            created_at,
        ),
    )
    investigation_id = cursor.lastrowid
    record_audit(
        connection,
        investigation_id,
        "investigation.created",
        {"title": payload["title"]},
    )
    return get_investigation(connection, investigation_id)  # type: ignore[arg-type]


def update_investigation(
    connection: sqlite3.Connection,
    investigation_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    fields = {
        key: value
        for key, value in payload.items()
        if value is not None
        and key in {
            "title",
            "mode",
            "country",
            "geography",
            "market",
            "activity",
            "objective",
            "asset_context",
        }
    }
    if not fields:
        raise ValueError("At least one investigation field is required for an update")
    current = get_investigation(connection, investigation_id)
    if (
        fields.get("mode", current.get("mode")) == "A2V"
        and not fields.get("asset_context", current.get("asset_context", "")).strip()
    ):
        raise ValueError("A2V investigations require an asset or operation context")
    assignments = ", ".join(f"{field} = ?" for field in fields)
    connection.execute(
        f"UPDATE investigations SET {assignments} WHERE id = ?",
        (*fields.values(), investigation_id),
    )
    record_audit(
        connection,
        investigation_id,
        "investigation.updated",
        {"fields": sorted(fields)},
    )
    return get_investigation(connection, investigation_id)


def list_investigations(connection: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = connection.execute(
        """
        SELECT
            i.*,
            (SELECT COUNT(*) FROM sources s WHERE s.investigation_id = i.id) AS source_count,
            (SELECT COUNT(*) FROM claims c WHERE c.investigation_id = i.id) AS claim_count,
            (SELECT COUNT(*) FROM opportunities o WHERE o.investigation_id = i.id) AS opportunity_count
        FROM investigations i
        ORDER BY i.created_at DESC, i.id DESC
        """
    ).fetchall()
    return [dict(row) for row in rows]


def add_source(
    connection: sqlite3.Connection,
    investigation_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    cursor = connection.execute(
        """
        INSERT INTO sources (
            investigation_id, title, uri, source_type, country, data_domain,
            published_at, last_updated, reliability, independence_score,
            source_family, access_limitations, evidence_level, content,
            file_name, file_path, file_content_type, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            investigation_id,
            payload["title"],
            payload.get("uri", ""),
            payload.get("source_type", "user-provided"),
            payload.get("country", ""),
            payload.get("data_domain", ""),
            payload.get("published_at", ""),
            payload.get("last_updated", ""),
            payload.get("reliability", 0.5),
            payload.get("independence_score", 0.5),
            payload.get("source_family", ""),
            payload.get("access_limitations", ""),
            payload.get("evidence_level", "E0"),
            payload["content"],
            payload.get("file_name", ""),
            payload.get("file_path", ""),
            payload.get("file_content_type", ""),
            utc_now(),
        ),
    )
    source_id = cursor.lastrowid
    record_audit(
        connection,
        investigation_id,
        "source.created",
        {"source_id": source_id, "title": payload["title"]},
    )
    row = connection.execute("SELECT * FROM sources WHERE id = ?", (source_id,)).fetchone()
    return dict(row)


def add_claim(
    connection: sqlite3.Connection,
    investigation_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    source_id = payload.get("source_id")
    if source_id is not None:
        _require_source(connection, investigation_id, source_id)
    if (
        payload.get("quantity_status") in {"unknown", "missing", "uncertain"}
        and payload.get("quantity") is not None
    ):
        raise ValueError(
            "Unknown, missing, or uncertain quantities must not assert a numeric value"
        )
    if (
        payload.get("value_status") in {"unknown", "missing", "uncertain"}
        and payload.get("value_amount") is not None
    ):
        raise ValueError(
            "Unknown, missing, or uncertain values must not assert a numeric amount"
        )
    cursor = connection.execute(
        """
        INSERT INTO claims (
            investigation_id, source_id, text, claim_type,
            evidence_level, confidence, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'unreviewed', ?)
        """,
        (
            investigation_id,
            source_id,
            payload["text"],
            payload.get("claim_type", "economic-observation"),
            payload.get("evidence_level", "E0"),
            payload.get("confidence", 0.5),
            utc_now(),
        ),
    )
    claim_id = cursor.lastrowid
    record_audit(
        connection,
        investigation_id,
        "claim.created",
        {"claim_id": claim_id, "source_id": source_id},
    )
    row = connection.execute("SELECT * FROM claims WHERE id = ?", (claim_id,)).fetchone()
    return dict(row)


def add_entity(
    connection: sqlite3.Connection,
    investigation_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    cursor = connection.execute(
        """
        INSERT INTO economic_entities (
            investigation_id, entity_type, name, country, geography,
            activity, asset_context, verification_status, confidence,
            metadata_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '{}', ?)
        """,
        (
            investigation_id,
            payload["entity_type"],
            payload["name"],
            payload.get("country", ""),
            payload.get("geography", ""),
            payload.get("activity", ""),
            payload.get("asset_context", ""),
            payload.get("verification_status", "potential"),
            payload.get("confidence", 0.5),
            utc_now(),
        ),
    )
    entity_id = cursor.lastrowid
    record_audit(
        connection,
        investigation_id,
        "entity.created",
        {"entity_id": entity_id, "entity_type": payload["entity_type"]},
    )
    row = connection.execute(
        "SELECT * FROM economic_entities WHERE id = ?",
        (entity_id,),
    ).fetchone()
    return dict(row)


def add_relationship(
    connection: sqlite3.Connection,
    investigation_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    entity_ids = {
        row["id"]
        for row in connection.execute(
            "SELECT id FROM economic_entities WHERE investigation_id = ?",
            (investigation_id,),
        ).fetchall()
    }
    if payload["subject_entity_id"] not in entity_ids:
        raise ValueError("Subject entity does not belong to this investigation")
    if payload["object_entity_id"] not in entity_ids:
        raise ValueError("Object entity does not belong to this investigation")
    source_id = payload.get("source_id")
    if source_id is not None:
        _require_source(connection, investigation_id, source_id)
    if payload.get("verification_status") == "verified" and source_id is None:
        raise ValueError("Verified relationships require a source")
    _validate_relationship_payload(payload)
    cursor = connection.execute(
        """
        INSERT INTO relationships (
            investigation_id, subject_entity_id, object_entity_id,
            relationship_type, direction, flow_type, economic_activity,
            quantity, quantity_unit, quantity_status, value_amount, currency,
            value_status, time_period, ownership_control, valid_from, valid_to,
            verification_status, confidence, source_id, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            investigation_id,
            payload["subject_entity_id"],
            payload["object_entity_id"],
            payload["relationship_type"],
            payload.get("direction", "subject-to-object"),
            payload.get("flow_type", "relationship"),
            payload.get("economic_activity", ""),
            payload.get("quantity"),
            payload.get("quantity_unit", ""),
            payload.get("quantity_status", "unknown"),
            payload.get("value_amount"),
            payload.get("currency", ""),
            payload.get("value_status", "unknown"),
            payload.get("time_period", ""),
            payload.get("ownership_control", ""),
            payload.get("valid_from", ""),
            payload.get("valid_to", ""),
            payload.get("verification_status", "potential"),
            payload.get("confidence", 0.5),
            source_id,
            payload.get("notes", ""),
            utc_now(),
        ),
    )
    relationship_id = cursor.lastrowid
    record_audit(
        connection,
        investigation_id,
        "relationship.created",
        {"relationship_id": relationship_id, "source_id": source_id},
    )
    row = connection.execute(
        "SELECT * FROM relationships WHERE id = ?",
        (relationship_id,),
    ).fetchone()
    return dict(row)


def add_metric(
    connection: sqlite3.Connection,
    investigation_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    _validate_metric_payload(payload)
    entity_id = payload.get("entity_id")
    if entity_id is not None:
        _require_entity(connection, investigation_id, entity_id)
    source_id = payload.get("source_id")
    if source_id is not None:
        _require_source(connection, investigation_id, source_id)
    cursor = connection.execute(
        """
        INSERT INTO economic_metrics (
            investigation_id, entity_id, metric_type, name, value, unit,
            currency, status, verification_status, period_start, period_end, economic_activity,
            source_id, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            investigation_id,
            entity_id,
            payload["metric_type"],
            payload["name"],
            payload.get("value"),
            payload.get("unit", ""),
            payload.get("currency", ""),
            payload.get("status", "known"),
            payload.get("verification_status", "potential"),
            payload.get("period_start", ""),
            payload.get("period_end", ""),
            payload.get("economic_activity", ""),
            source_id,
            payload.get("notes", ""),
            utc_now(),
        ),
    )
    metric_id = cursor.lastrowid
    record_audit(
        connection,
        investigation_id,
        "metric.created",
        {"metric_id": metric_id, "metric_type": payload["metric_type"]},
    )
    row = connection.execute(
        "SELECT * FROM economic_metrics WHERE id = ?",
        (metric_id,),
    ).fetchone()
    return dict(row)


def update_metric(
    connection: sqlite3.Connection,
    investigation_id: int,
    metric_id: int,
    payload: dict[str, Any],
) -> dict[str, Any]:
    current = dict(_require_metric(connection, investigation_id, metric_id))
    allowed_fields = {
        "entity_id",
        "metric_type",
        "name",
        "value",
        "unit",
        "currency",
        "status",
        "verification_status",
        "period_start",
        "period_end",
        "economic_activity",
        "source_id",
        "notes",
    }
    fields = {
        key: value
        for key, value in payload.items()
        if key in allowed_fields
    }
    if not fields:
        raise ValueError("At least one economic metric field is required for an update")
    merged = {**current, **fields}
    _validate_metric_payload(merged)
    if merged.get("entity_id") is not None:
        _require_entity(connection, investigation_id, merged["entity_id"])
    if merged.get("source_id") is not None:
        _require_source(connection, investigation_id, merged["source_id"])
    assignments = ", ".join(f"{field} = ?" for field in fields)
    connection.execute(
        f"""
        UPDATE economic_metrics
        SET {assignments}
        WHERE id = ? AND investigation_id = ?
        """,
        (*fields.values(), metric_id, investigation_id),
    )
    record_audit(
        connection,
        investigation_id,
        "metric.updated",
        {"metric_id": metric_id, "fields": sorted(fields)},
    )
    row = connection.execute(
        "SELECT * FROM economic_metrics WHERE id = ?",
        (metric_id,),
    ).fetchone()
    return dict(row)


def list_investigation_rows(
    connection: sqlite3.Connection,
    investigation_id: int,
) -> dict[str, list[dict[str, Any]]]:
    _require_investigation(connection, investigation_id)
    sources = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM sources WHERE investigation_id = ? ORDER BY id",
            (investigation_id,),
        ).fetchall()
    ]
    claims = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM claims WHERE investigation_id = ? ORDER BY id",
            (investigation_id,),
        ).fetchall()
    ]
    entities = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM economic_entities WHERE investigation_id = ? ORDER BY id",
            (investigation_id,),
        ).fetchall()
    ]
    relationships = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM relationships WHERE investigation_id = ? ORDER BY id",
            (investigation_id,),
        ).fetchall()
    ]
    metrics = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM economic_metrics WHERE investigation_id = ? ORDER BY id",
            (investigation_id,),
        ).fetchall()
    ]
    return {
        "sources": sources,
        "claims": claims,
        "entities": entities,
        "relationships": relationships,
        "metrics": metrics,
    }


def get_investigation(
    connection: sqlite3.Connection,
    investigation_id: int,
    include_children: bool = False,
) -> dict[str, Any]:
    row = connection.execute(
        "SELECT * FROM investigations WHERE id = ?",
        (investigation_id,),
    ).fetchone()
    if row is None:
        raise ValueError(f"Investigation {investigation_id} was not found")
    result = dict(row)
    if include_children:
        result.update(list_investigation_rows(connection, investigation_id))
        result["analysis_runs"] = [
            _decode_analysis_run(dict(analysis_row))
            for analysis_row in connection.execute(
                """
                SELECT * FROM analysis_runs
                WHERE investigation_id = ?
                ORDER BY id DESC
                """,
                (investigation_id,),
            ).fetchall()
        ]
        result["opportunities"] = [
            _decode_opportunity(dict(opportunity_row))
            for opportunity_row in connection.execute(
                """
                SELECT * FROM opportunities
                WHERE investigation_id = ?
                ORDER BY id DESC
                """,
                (investigation_id,),
            ).fetchall()
        ]
        result["audit_events"] = [
            _decode_audit(dict(audit_row))
            for audit_row in connection.execute(
                """
                SELECT * FROM audit_events
                WHERE investigation_id = ?
                ORDER BY id DESC
                """,
                (investigation_id,),
            ).fetchall()
        ]
    return result


def create_analysis_run(
    connection: sqlite3.Connection,
    investigation_id: int,
    methodology_version: str,
    ruleset_version: str,
    engine_version: str,
    input_snapshot: dict[str, Any],
    result: dict[str, Any],
    opportunities: list[dict[str, Any]],
) -> dict[str, Any]:
    _require_investigation(connection, investigation_id)
    cursor = connection.execute(
        """
        INSERT INTO analysis_runs (
            investigation_id, methodology_version, ruleset_version,
            engine_version, input_snapshot_json, result_json, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            investigation_id,
            methodology_version,
            ruleset_version,
            engine_version,
            json_text(input_snapshot),
            json_text(result),
            result["status"],
            utc_now(),
        ),
    )
    analysis_run_id = cursor.lastrowid
    for opportunity in opportunities:
        connection.execute(
            """
            INSERT INTO opportunities (
                investigation_id, analysis_run_id, title, description,
                origin, pathway, evidence_strength, confidence,
                economic_logic, assumptions_json, unknowns_json,
                hard_gates_json, pathway_evaluations_json, quality_json,
                status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                investigation_id,
                analysis_run_id,
                opportunity["title"],
                opportunity["description"],
                opportunity["origin"],
                opportunity["pathway"],
                opportunity["evidence_strength"],
                opportunity["confidence"],
                json_text(opportunity["economic_logic"]),
                json_text(opportunity["assumptions"]),
                json_text(opportunity["unknowns"]),
                json_text(opportunity["hard_gates"]),
                json_text(opportunity["pathway_evaluations"]),
                json_text(opportunity["quality"]),
                opportunity["status"],
                utc_now(),
            ),
        )
    record_audit(
        connection,
        investigation_id,
        "analysis.completed",
        {
            "analysis_run_id": analysis_run_id,
            "status": result["status"],
            "opportunity_count": len(opportunities),
        },
    )
    row = connection.execute(
        "SELECT * FROM analysis_runs WHERE id = ?",
        (analysis_run_id,),
    ).fetchone()
    return _decode_analysis_run(dict(row))


def get_analysis_run(
    connection: sqlite3.Connection,
    investigation_id: int,
    analysis_run_id: int,
) -> dict[str, Any]:
    row = connection.execute(
        """
        SELECT * FROM analysis_runs
        WHERE id = ? AND investigation_id = ?
        """,
        (analysis_run_id, investigation_id),
    ).fetchone()
    if row is None:
        raise ValueError(
            f"Analysis run {analysis_run_id} was not found for investigation {investigation_id}"
        )
    return _decode_analysis_run(dict(row))


def _decode_analysis_run(row: dict[str, Any]) -> dict[str, Any]:
    row["input_snapshot"] = parse_json(row.pop("input_snapshot_json", "{}"), {})
    row["result"] = parse_json(row.pop("result_json", "{}"), {})
    return row


def _decode_opportunity(row: dict[str, Any]) -> dict[str, Any]:
    for field in (
        "economic_logic",
        "assumptions_json",
        "unknowns_json",
        "hard_gates_json",
        "pathway_evaluations_json",
        "quality_json",
    ):
        value = row.pop(field, "{}")
        target = field.removesuffix("_json")
        row[target] = parse_json(
            value,
            {} if target in {"economic_logic", "quality"} else [],
        )
    return row


def _decode_audit(row: dict[str, Any]) -> dict[str, Any]:
    row["details"] = parse_json(row.pop("details_json", "{}"), {})
    return row
