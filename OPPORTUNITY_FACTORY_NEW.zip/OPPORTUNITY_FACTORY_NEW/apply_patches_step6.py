with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# 8. Fix _is_negated function - use 80-char window, 6-word lookback
old_is_negated = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 60) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\\w){re.escape(_normalize(alias))}"
            rf"(?:\\s+\\w+){{0,4}}\\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES
    )"""

new_is_negated = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\\w){re.escape(_normalize(alias))}"
            rf"(?:\\s+\\w+){{0,6}}\\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES
    )"""

content = content.replace(old_is_negated, new_is_negated)
print("Step 8a done: _is_negated updated")

# 9. Fix _is_hypothetical_or_question function - expand markers
old_is_hypothetical = """def _is_hypothetical_or_question(
    normalized_text: str,
    raw_text: str,
    start: int,
) -> bool:
    if "?" in raw_text:
        return True
    leading_context = normalized_text[max(0, start - 80) : start]
    marker_pattern = "|".join(re.escape(marker) for marker in HYPOTHETICAL_MARKERS)
    return bool(
        re.search(
            rf"(?<!\\w)(?:{marker_pattern})(?!\\w)"
            rf"(?:\\s+\\w+){{0,6}}\\s*$",
            leading_context,
        )
    )"""

new_is_hypothetical = """def _is_hypothetical_or_question(
    normalized_text: str,
    raw_text: str,
    start: int,
) -> bool:
    if "?" in raw_text:
        return True
    leading_context = normalized_text[max(0, start - 80) : start]
    marker_pattern = "|".join(re.escape(marker) for marker in HYPOTHETICAL_MARKERS)
    return bool(
        re.search(
            rf"(?<!\\w)(?:{marker_pattern})(?!\\w)"
            rf"(?:\\s+\\w+){{0,8}}\\s*$",
            leading_context,
        )
    )"""

content = content.replace(old_is_hypothetical, new_is_hypothetical)
print("Step 8b done: _is_hypothetical_or_question updated")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Step 8 applied successfully!")
