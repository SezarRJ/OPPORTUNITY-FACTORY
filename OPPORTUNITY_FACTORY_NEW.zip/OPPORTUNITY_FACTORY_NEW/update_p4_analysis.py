with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# Update P4 pathway terms to be broader but still require cross-market context
old_p4 = """    (
        "P4",
        "Market \u2192 Market",
        "cross_market_model",
        (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "successful model in another market",
            "successful model abroad",
            "established service in another market",
            "established service abroad",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "cross-market",
            "another market",
            "benchmark",
        ),
    ),"""

new_p4 = """    (
        "P4",
        "Market \u2192 Market",
        "cross_market_model",
        (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "replicate the",
            "replicate a",
            "replicate an",
            "replicate from",
            "port to",
            "porting to",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "proven model from",
            "proven model we can replicate",
            "proven playbook",
            "proven format",
            "proven scheme",
            "proven approach",
            "successful model in another market",
            "successful model abroad",
            "successful model from",
            "established service in another market",
            "established service abroad",
            "established service from",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "transferable model from",
            "cross-market",
            "another market",
            "benchmark",
            "model from",
            "model in",
            "operates in",
        ),
    ),"""

content = content.replace(old_p4, new_p4)
print("P4 pathway terms updated")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)
