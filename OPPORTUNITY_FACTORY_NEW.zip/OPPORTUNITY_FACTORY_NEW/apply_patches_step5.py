with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# 7. Add CONCEPT_COUNTER_PATTERNS for cross_market_replication
old_counter = """CONCEPT_COUNTER_PATTERNS = {
    "underutilized_capacity": (
        r"\\b(?:full|100)\\s+(?:percent\\s+)?(?:capacity|utilization)\\b",
        r"\\bno\\s+(?:spare|unused)\\s+(?:capacity|shift|hours)\\b",
    ),
    "unmet_demand": (
        r"\\bno\\s+(?:waiting|wait)\\s+(?:list|queue)s?\\b",
        r"\\b(?:all|every)\\s+(?:orders?|requests?|patients?|customers?|clients?)\\s+"
        r"(?:are|is)\\s+(?:met|served|filled|completed)\\b",
    ),
    "process_loss": (
        r"\\b(?:zero|no)\\s+(?:scrap|rejections?|spoilage|waste)\\b",
    ),
}"""

new_counter = """CONCEPT_COUNTER_PATTERNS = {
    "underutilized_capacity": (
        r"\\b(?:full|100)\\s+(?:percent\\s+)?(?:capacity|utilization)\\b",
        r"\\bno\\s+(?:spare|unused)\\s+(?:capacity|shift|hours)\\b",
    ),
    "unmet_demand": (
        r"\\bno\\s+(?:waiting|wait)\\s+(?:list|queue)s?\\b",
        r"\\b(?:all|every)\\s+(?:orders?|requests?|patients?|customers?|clients?)\\s+"
        r"(?:are|is)\\s+(?:met|served|filled|completed)\\b",
    ),
    "process_loss": (
        r"\\b(?:zero|no)\\s+(?:scrap|rejections?|spoilage|waste)\\b",
    ),
    "cross_market_replication": (
        r"\\b(?:not|no)\\s+(?:replicate|replicating|transfer|transferring)\\b.{0,30}\\b(?:another|other|abroad|overseas|internationally)\\b",
        r"\\b(?:local|domestic|this market|current market|same market)\\s+only\\b",
        r"\\bno\\s+(?:cross.?market|international|overseas|foreign)\\s+(?:model|plan|expansion|replication)\\b",
        r"\\b(?:proven|successful|established)\\s+(?:model|service|business)\\s+(?:here|locally|domestically)\\b",
    ),
}"""

content = content.replace(old_counter, new_counter)
print("Step 7 done: CONCEPT_COUNTER_PATTERNS updated")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Step 7 applied successfully!")
