with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

# 3. Fix _is_negated in analysis.py to match semantic.py (80-char window, 6-word lookback)
old_is_negated = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 60):start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return bool(
        re.search(
            r"\\b(?:no|not|without|none|absent|lack(?:\\s+of)?)"
            r"(?:\\W+\\w+){0,5}\\W*$",
            prefix,
        )
    )"""

new_is_negated = """def _is_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 80) : start]
    prefix = re.split(r"[.!?;:]", prefix)[-1]
    return any(
        re.search(
            rf"(?<!\\w){re.escape(_normalize(alias))}"
            rf"(?:\\s+\\w+){{0,6}}\\s*$",
            prefix,
        )
        for alias in NEGATION_ALIASES_ANALYSIS
    )"""

content = content.replace(old_is_negated, new_is_negated)
print("Step 3a done: _is_negated updated in analysis.py")

# 4. Fix _is_hypothetical_statement in analysis.py
old_is_hypothetical = """def _is_hypothetical_statement(text: str, start: int) -> bool:
    sentence_start = max(
        text.rfind(".", 0, start),
        text.rfind("!", 0, start),
        text.rfind("?", 0, start),
        text.rfind(";", 0, start),
    ) + 1
    sentence_end_candidates = [
        index
        for index in (
            text.find(".", start),
            text.find("!", start),
            text.find("?", start),
            text.find(";", start),
        )
        if index >= 0
    ]
    sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(text)
    sentence = text[sentence_start:sentence_end]
    if "?" in text[start:sentence_end + 1]:
        return True
    return bool(
        re.search(
            r"\\b(?:if|could|might|would|may|potentially|hypothetical|scenario|assume)\\b",
            sentence,
        )
    )"""

new_is_hypothetical = """def _is_hypothetical_statement(text: str, start: int) -> bool:
    sentence_start = max(
        text.rfind(".", 0, start),
        text.rfind("!", 0, start),
        text.rfind("?", 0, start),
        text.rfind(";", 0, start),
    ) + 1
    sentence_end_candidates = [
        index
        for index in (
            text.find(".", start),
            text.find("!", start),
            text.find("?", start),
            text.find(";", start),
        )
        if index >= 0
    ]
    sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(text)
    sentence = text[sentence_start:sentence_end]
    if "?" in text[start:sentence_end + 1]:
        return True
    marker_pattern = "|".join(re.escape(marker) for marker in HYPOTHETICAL_MARKERS_ANALYSIS)
    return bool(
        re.search(
            rf"(?<!\\w)(?:{marker_pattern})(?!\\w)",
            sentence,
        )
    )"""

content = content.replace(old_is_hypothetical, new_is_hypothetical)
print("Step 3b done: _is_hypothetical_statement updated in analysis.py")

# 5. Add NEGATION_ALIASES_ANALYSIS and HYPOTHETICAL_MARKERS_ANALYSIS constants
# Find a good place to add them - after the HARD_GATES definition
old_hard_gates_end = """),

EVIDENCE_DEFINITIONS = {"""

new_hard_gates_end = """),

NEGATION_ALIASES_ANALYSIS = (
    "no",
    "not",
    "without",
    "none",
    "lack of",
    "absent",
    "devoid of",
    "free from",
    "no sign of",
    "no evidence of",
    "does not have",
    "does not operate",
    "does not exist",
    "is not",
    "are not",
    "was not",
    "were not",
    "has no",
    "have no",
    "had no",
    "without any",
    "sin",
    "no hay",
    "no existe",
    "no hay evidencia",
    "sin evidencia",
    "لا",
    "ليس",
    "بدون",
    "غير",
    "لا يوجد",
    "ليس هناك",
    "لا دليل على",
    "غير متوفر",
    "ما في",
    "ما فيه",
    "ماكو",
    "موجودش",
    "لا يوجد",
    "nicht",
    "kein",
    "keine",
    "keiner",
    "keines",
    "ohne",
    "fehlt",
)

HYPOTHETICAL_MARKERS_ANALYSIS = (
    "if",
    "could",
    "might",
    "would",
    "may",
    "potentially",
    "hypothetical",
    "scenario",
    "assume",
    "projected",
    "forecast",
    "scenario analysis",
    "what if",
    "suppose",
    "supposing",
    "assuming",
    "in theory",
    "theoretically",
    "on paper",
    "envisage",
    "envision",
    "contemplate",
    "consider",
    "explore",
    "investigate",
    "evaluate",
    "assess",
    "دراسة",
    "تحليل",
    "سيناريو",
    "افتراض",
    "مقترح",
    "توقع",
    "مشروط",
    "في حال",
    "لو",
    "في حالة",
    "si",
    "caso",
    "supongamos",
    "hipotéticamente",
    "proyectado",
    "pronóstico",
    "análisis de escenario",
)

EVIDENCE_DEFINITIONS = {"""

content = content.replace(old_hard_gates_end, new_hard_gates_end)
print("Step 4 done: Added NEGATION_ALIASES_ANALYSIS and HYPOTHETICAL_MARKERS_ANALYSIS")

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)

print("All analysis.py patches applied successfully!")
