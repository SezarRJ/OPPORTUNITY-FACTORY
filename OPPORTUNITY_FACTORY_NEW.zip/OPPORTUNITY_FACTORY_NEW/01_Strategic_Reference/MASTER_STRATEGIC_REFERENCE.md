# OPPORTUNITY FACTORY -- MASTER STRATEGIC REFERENCE DOCUMENT
Version: 1.0
Status: DRAFT -- For Review and Approval
Date: 2026-11-08
Project: OPPORTUNITY FACTORY -- Complete Rebuild from Zero
Classification: Strategic Foundation -- Non-Negotiable Identity

---

## 1. PRODUCT IDENTITY -- NON-NEGOTIABLE

### 1.1 What OPPORTUNITY FACTORY Is

OPPORTUNITY FACTORY is a Global Economic Intelligence and Opportunity Creation System.

It understands:
- Economic systems, countries, markets, sectors, value chains
- Companies, activities, assets, resources, needs, problems
- Relationships and economic flows across boundaries

It identifies:
- Existing economic opportunities -- discovered through systematic analysis
- Economic gaps and inefficiencies -- structural failures in value creation
- Underused assets and resources -- capacity, infrastructure, capabilities
- Unmet demand -- needs without adequate supply solutions
- Value leakage and operational failures -- measurable economic losses
- New opportunities created by recombination -- combining existing resources, activities, capabilities, technologies, and market needs in novel ways
- Cross-market adaptation opportunities -- successful models transferable between markets
- Turnaround and asset reconfiguration opportunities -- rescuing value from distressed or suboptimal operations

### 1.2 What OPPORTUNITY FACTORY Is NOT

| Category | Explicitly Excluded |
|----------|---------------------|
| AI Chatbot | Not a conversational interface; AI is an internal intelligence layer only |
| Generic Business Idea Generator | Not a brainstorming tool; outputs are evidence-based, validated hypotheses |
| Business Directory | Not a listing service; entities exist as economic participants with relationships |
| Consulting Platform | Not a marketplace for human experts; the system performs the analysis |
| Marketplace (v1) | No transaction layer, no investor portal, no public opportunity submissions |
| AI Report Generator | AI-generated reports are not the primary value; evidence traceability is |

### 1.3 Two Fundamental Directions (Dual-Mode Operation)

A. MARKET-TO-OPPORTUNITY | B. ASSET-TO-VALUE
Start with: Economy/Country, Market/Sector, Economic Activity, Value Chain
Discover/Create: Market opportunities, Economic gaps, Unmet demand, Recombination opportunities, Cross-market adaptations
Start with: Company/Factory, Asset/Resource, Process/Activity, Business Operation
Discover: Underused capacity, Value leakage, Alternative uses, New revenue streams, Turnaround potential

Both directions operate on the same canonical data model, evidence framework, and validation engine.

### 1.4 Scope Principles

- Global and Cross-Sectoral: No predetermined sector or country restrictions
- Evidence Honesty: Must clearly identify data availability, evidence quality, uncertainty, and coverage limitations
- Economic Universality: Canonical model represents fundamental economic structures, not sector-specific schemas

---

## 2. CORE PRODUCT PRINCIPLE

One Market + One Core Problem + Multiple Integrated Capabilities

Every investigation focuses on:
1. A defined economic context (market, sector, value chain, geography)
2. A clearly identified problem or value-creation mechanism
3. Integrated capabilities introduced only when they materially improve:
   - Economic value
   - Revenue potential
   - Operational feasibility
   - Customer value
   - Evidence quality
   - Risk reduction
   - Decision quality

Anti-Pattern: Features added because they are technically possible, not because they improve economic decision-making.


---
## 3. FIVE DISCIPLINES -- THE INTELLECTUAL FOUNDATION

OPPORTUNITY FACTORY is built on five distinct intellectual disciplines. These are not software modules; they are ways of thinking that the system must embody. Each discipline has its own questions, methods, evidence standards, and outputs.

### 3.1 Discipline 1: Global Economic Intelligence
**Purpose**: Understand what is happening in economic systems at global, national, sectoral, and local levels.

**Core Questions**:
- What economic activities exist in this market/sector/geography?
- Who are the participants, and what are their roles?
- What assets, resources, and capabilities are deployed?
- How do value and resources flow through the system?
- What are the structural trends, constraints, and dynamics?

**Methods**: Systematic market mapping, entity identification, asset cataloging, activity analysis, flow tracing, trend monitoring, regulatory scanning.

**Evidence Standard**: E1-E4 (see Section 8). Primary sources preferred. Coverage gaps explicitly mapped.

**Outputs**: Market profiles, sector maps, entity registries, asset inventories, flow diagrams, intelligence briefings.

**Key Principle**: The system must understand before it proposes. No opportunity hypothesis without economic context.

---

### 3.2 Discipline 2: Systems Failure & Gap Analysis
**Purpose**: Identify where economic systems fail to create, transfer, or capture value efficiently.

**Core Questions**:
- Where is value leaking, wasted, or destroyed?
- Where are bottlenecks, breakdowns, or missing connections?
- Where does demand exist without adequate supply?
- Where are assets, capacity, or resources underutilized?
- Where do regulatory, informational, or structural barriers prevent efficient exchange?

**Methods**: Value leakage quantification, bottleneck detection, unmet demand analysis, capacity utilization assessment, barrier mapping, inefficiency classification.

**Evidence Standard**: E2-E4. Measured gaps preferred over inferred. Contradictory evidence preserved.

**Outputs**: Gap registry, inefficiency catalog, value leakage reports, bottleneck analyses, unmet demand maps.

**Key Principle**: Every gap must be tied to a measurable economic loss or missed opportunity, not just a problem.

---

### 3.3 Discipline 3: Opportunity Engineering
**Purpose**: Create and discover economic opportunities by recombining existing resources, activities, capabilities, and market needs.

**Core Questions**:
- What new economic mechanism can connect underused resources with unmet needs?
- What successful model from another market can be adapted here?
- What combination of existing activities, assets, and technologies creates new value?
- How can a distressed or suboptimal operation be reconfigured for value recovery?
- What novel business model emerges from rethinking the value chain?

**Methods**: Six creation pathways (Section 6), pattern library, cross-market adaptation, business model synthesis, hypothesis generation, mechanism design.

**Evidence Standard**: E0-E3 for hypotheses. Every opportunity must articulate its value-creation mechanism explicitly.

**Outputs**: Opportunity hypotheses, business model candidates, pathway analyses, recombination proposals, adaptation studies.

**Key Principle**: An opportunity is not an idea. It is a feasible economic mechanism connecting specific resources to specific needs under acceptable conditions.

---

### 3.4 Discipline 4: Validation & Decision Science
**Purpose**: Rigorously test opportunity hypotheses against evidence, assumptions, financial reality, and operational constraints.

**Core Questions**:
- What claims are supported by evidence, and what are assumptions?
- What are the critical unknowns that could invalidate the opportunity?
- Does the financial model survive sensitivity analysis?
- What are the regulatory, operational, and capital barriers?
- What is the probability-weighted expected value vs. downside?

**Methods**: Evidence grading (E0-E4), claim registry, contradiction tracking, assumption registration, financial modeling, scenario analysis, sensitivity testing, risk screening, validation gates.

**Evidence Standard**: E3-E4 for critical claims. E0-E2 explicitly flagged. No claim advances without evidence or explicit uncertainty classification.

**Outputs**: Validation reports, assumption registers, financial models with scenarios, risk assessments, decision recommendations (Proceed/Redesign/Hold/Reject).

**Key Principle**: Attractiveness does not equal validity. The system must reject convincing but unsupported opportunities.

---

### 3.5 Discipline 5: Deployment & Learning
**Purpose**: Convert validated opportunities into testable implementations, capture outcomes, and feed learning back into the discovery engine.

**Core Questions**:
- What is the minimum viable test to prove the economic mechanism?
- Who are the partners, what are the resources, what is the timeline?
- What did we predict vs. what actually happened?
- Which discovery rules, evidence weights, or financial assumptions need recalibration?
- What new patterns, sectors, or markets should be prioritized next?

**Methods**: Pilot design, resource mapping, partner criteria, outcome tracking, prediction-vs-actual comparison, rule refinement, model recalibration, knowledge base updates.

**Evidence Standard**: E4 (field-verified outcomes). Learning loop requires measured results, not opinions.

**Outputs**: Deployment plans, pilot results, learning reports, updated discovery rules, recalibrated models, expanded source registry.

**Key Principle**: The system improves only when predictions meet reality. Every deployment is a learning experiment.

---

## 4. NINE FUNCTIONAL MODULES (M1-M9)

The five disciplines are operationalized through nine functional modules. Modules are user-facing functional areas; engines (Section 5) are the internal computational capabilities that power them.

| Module | Name | Primary Discipline | Core Responsibility |
|--------|------|-------------------|---------------------|
| **M1** | Market & Entity Intelligence | Economic Intelligence | Define markets, catalog entities, map relationships, manage sources |
| **M2** | Signal & Change Detection | Economic Intelligence | Monitor sources, detect changes, classify signals, trigger re-analysis |
| **M3** | Gap & Inefficiency Detection | Systems Failure Analysis | Identify gaps, quantify leakage, detect bottlenecks, map unmet demand |
| **M4** | Opportunity Creation Engine | Opportunity Engineering | Execute 6 pathways, generate hypotheses, build business models, compare alternatives |
| **M5** | Evidence & Claim Management | Validation & Decision Science | Source registry, evidence ledger, claim registry, contradiction tracking, review workflow |
| **M6** | Economic Modeling & Validation | Validation & Decision Science | Financial model builder, assumption register, scenario manager, risk assessment |
| **M7** | Scoring & Decision Engine | Validation & Decision Science | Multi-criteria scoring, validation gates, decision workflow, recommendation logic |
| **M8** | Deployment & Pilot Management | Deployment & Learning | Pilot designer, resource mapping, partner criteria, approval workflow, field test tracking |
| **M9** | Learning & Calibration Engine | Deployment & Learning | Outcome tracking, prediction vs. actual, rule improvement, model recalibration, knowledge updates |

### Module Independence Rules
- **No module bypasses M5**: All claims, evidence, and assumptions flow through Evidence & Claim Management.
- **No module writes directly to Opportunity state**: State transitions (Section 7) are governed by M7 validation gates.
- **M1-M3 feed M4**: Discovery modules provide the raw material for creation.
- **M4-M7 form the validation loop**: Creation -> Evidence -> Modeling -> Scoring -> Decision.
- **M8-M9 close the loop**: Deployment outcomes feed back into M1-M4 via M9.

---

## 5. FIVE ECONOMIC ENGINES (E1-E5)

Engines are the internal computational capabilities that power the modules. They are not user-facing; they are the intelligence layer.

### E1: Economic World Scanner
**Powers**: M1, M2
**Function**: Continuous ingestion from global sources -> entity extraction -> economic model building -> refresh cycles.
**Capabilities**: Source connectors (government, trade, corporate, research), scheduled ingestion, entity resolution, relationship inference, coverage mapping, data quality scoring.
**Key Challenge**: Global scope vs. data reality (Conflict C1). Must explicitly map coverage gaps.

### E2: System Failure & Gap Detector
**Powers**: M3
**Function**: Algorithmic detection of value leakage, bottlenecks, unmet demand, capacity gaps, structural inefficiencies.
**Capabilities**: Value flow analysis, utilization benchmarking, demand-supply gap quantification, bottleneck identification, barrier classification, severity scoring.
**Key Challenge**: Evidence rigor vs. discovery speed (Conflict C3). Measured gaps require data; inferred gaps need clear uncertainty flags.

### E3: Opportunity Creation Engine
**Powers**: M4
**Function**: Executes six creation pathways (Section 6) using pattern library, economic recombination logic, cross-market adaptation, business model synthesis.
**Capabilities**: Pathway executor, pattern matcher, hypothesis builder, business model generator, alternative comparator, mechanism designer.
**Key Challenge**: Autonomous discovery vs. human control (Conflict C5). AI generates; human approves.

### E4: Economic Model & Validation Engine
**Powers**: M5, M6, M7
**Function**: Deterministic financial modeling, assumption management, scenario analysis, sensitivity testing, validation gate enforcement.
**Capabilities**: Financial equation library, assumption register, scenario engine, Monte Carlo simulation, risk calculator, gate evaluator, reproducibility guarantee.
**Key Challenge**: Financial modeling -- AI vs. deterministic (Conflict C6). Core equations must be deterministic; AI assists with assumption generation and scenario design.

### E5: Opportunity Deployment Engine
**Powers**: M8, M9
**Function**: Pilot packaging, resource mapping, partner matching, approval workflow, outcome capture, learning extraction.
**Capabilities**: Deployment template library, resource requirement calculator, partner criteria engine, milestone tracker, outcome recorder, prediction comparator, rule updater.

---

## 6. SIX OPPORTUNITY CREATION PATHWAYS

Every opportunity created by OPPORTUNITY FACTORY originates from one of six pathways. These are distinct economic reasoning patterns, not UI wizards.

| Pathway | Name | Trigger | Core Logic | Example |
|---------|------|---------|------------|---------|
| **P1** | Resource -> Value | Underused asset/resource identified | Map asset capabilities -> find alternative uses/markets -> design value capture mechanism | Excess steam from factory -> district heating -> new revenue stream |
| **P2** | Problem -> Business | Unmet demand or structural problem found | Define problem -> identify solvable mechanism -> design business model -> validate payer | Cold chain gap in agriculture -> refrigerated logistics service -> farmers pay per pallet |
| **P3** | Process -> Opportunity | Inefficient process or value leakage detected | Analyze process -> identify waste/bottleneck -> redesign flow -> capture saved value | Manual customs clearance -> digital pre-clearance platform -> time savings monetized |
| **P4** | Market -> Market | Successful model in Market A, absent in Market B | Profile model in A -> map structural conditions -> assess transferability -> adapt for B | Indonesian fintech agent network -> replicate in Philippines with local partners |
| **P5** | Combination -> Value | Two+ separate activities/assets can combine | Identify complementarities -> design integration mechanism -> model combined economics | Solar farm + battery storage + EV charging -> integrated energy hub |
| **P6** | Asset -> Opportunity | Existing company/asset analyzed for turnaround | Baseline current operations -> identify leakage/underuse -> propose reconfiguration -> model recovery | Underutilized food processing plant -> contract manufacturing + private label -> 40% capacity recovery |

**Pathway Execution Rules**:
- Every pathway execution produces a structured opportunity hypothesis (mechanism, participants, revenue, costs, evidence, assumptions).
- Pathways can be combined (e.g., P1 + P4 = adapt underused asset model from another market).
- AI executes pathway logic; human reviews and approves hypotheses before validation investment.

---

## 7. CANONICAL DATA MODEL -- 12 ENTITIES

The canonical data model is the single source of truth for all economic representation. It is global, cross-sectoral, and extensible.

| Entity | Purpose | Key Attributes |
|--------|---------|----------------|
| **Market** | Economic environment boundary | Name, country, region, sectors, size, trends, regulations, data quality, last updated |
| **Sector** | Economic activity classification | Name, classification code, activities, markets, products/services, cross-sector links |
| **Entity** | Economic participant (company, gov, individual) | Name, type, location, activity, size, assets, relationships, sources, verification level |
| **Asset** | Economic resource with current/potential value | Type, owner, location, capacity, utilization, costs, value, constraints, potential |
| **Activity** | Economic process transforming inputs to outputs | Type, participants, inputs, outputs, assets, costs, time, capacity, failure points |
| **Product & Service** | Economic output exchanged | Name, type, market, producers, price, specs, lifecycle, substitutes, regulations |
| **Need & Demand** | Unmet or underserved economic demand | Description, market, segment, urgency, current solutions, willingness to pay, evidence |
| **Problem & Gap** | Structural failure or inefficiency | Type, location, affected participants, quantified impact, root cause, evidence, severity |
| **Relationship** | Economic connection between entities | Type (supplies, distributes, finances, regulates, partners), direction, terms, volume, evidence |
| **Source & Evidence** | Provenance and grading of information | Source metadata, evidence level (E0-E4), content, date, geography, linked entity/claim, verification status |
| **Claim** | Assertion used in analysis | Statement, evidence links, grade, contradiction links, version, status (supported/inferred/refuted) |
| **Opportunity** | Central output -- validated economic hypothesis | Name, market, pathway, mechanism, participants, revenue model, costs, investment, risks, evidence, assumptions, state |

### Entity Design Principles
- **Unique identifiers**: Every entity has a UUID.
- **Temporal validity**: Valid-time and transaction-time for all entities and relationships.
- **Source traceability**: Every attribute value traces to a source or is marked as inferred.
- **Multi-lingual**: Names and descriptions support Arabic, English, and extensible locales.
- **Soft deletes**: No hard deletes; state transitions only.
- **Extensibility**: JSONB/custom fields for sector-specific attributes without schema migration.

---

## 8. EVIDENCE & VALIDATION FRAMEWORK

### 8.1 Five Evidence Levels (E0-E4)

| Level | Label | Definition | Use in Decision |
|-------|-------|------------|-----------------|
| **E0** | Signal / Hypothesis | Unverified lead, AI-generated pattern, user intuition | Starting point only; never basis for decision |
| **E1** | Single Source | One document, database, or interview | Supports exploration; insufficient for validation |
| **E2** | Corroborated | Multiple independent sources agreeing | Supports assumption registration; flagged as unverified |
| **E3** | Independently Verified | Field check, primary data, audited records | Required for critical claims before validation gate |
| **E4** | Field-Tested / Outcome-Verified | Actual results from pilot or deployment | Highest confidence; feeds learning engine |

### 8.2 Core Components
- **Source Registry**: Catalog of all sources with metadata, quality scores, access config, rate limits.
- **Evidence Ledger**: Immutable log of every evidence item with grade, source, linked claim, contradictions, verification status.
- **Claim Registry**: Every assertion with evidence links, grade, contradiction links, versioning, status.
- **Contradiction Tracking**: Explicit recording of conflicting evidence; never hidden.
- **Missing Evidence Registry**: Structured capture of critical unknowns -- what is missing, why it matters, how to get it, cost.

### 8.3 Validation Rules
1. Every material claim must have >=E2 evidence or be explicitly marked as assumption.
2. Critical claims (revenue driver, regulatory gate, technical feasibility) require >=E3.
3. Contradictory evidence must be displayed, not resolved silently.
4. Assumptions must be registered with owner, rationale, and test plan.
5. Financial models must show sensitivity to each assumption.
6. No opportunity advances past Validated state without passing all validation gates.

### 8.4 AI Permissions & Constraints
**AI MAY**: Search sources, extract info, compare evidence, suggest claims, identify contradictions, build hypotheses, propose verification methods, analyze scenarios, recommend decisions.
**AI MUST NOT**: Fabricate sources/evidence, convert hypothesis to fact, hide contradictory evidence, confirm commercial relationships without proof, approve investments, bypass legal/regulatory requirements, present projections as guarantees.

---

## 9. DUAL-MODE OPERATION -- DETAILED SPECIFICATION

### 9.1 Market-to-Opportunity (M2O)
**Entry Point**: User defines market scope (country, sector, value chain, problem type).
**Flow**:
1. M1: Market definition -> entity mapping -> source identification
2. E1: World Scanner ingests data -> builds economic model
3. E2: Gap Detector identifies inefficiencies, unmet demand, leakage
4. M3: Gap registry populated with quantified gaps
5. E3: Creation Engine executes P1, P2, P3, P4, P5 pathways
6. M4: Opportunity hypotheses generated, compared, ranked
7. M5-M7: Validation loop (evidence -> modeling -> scoring -> decision)
8. M8: Validated opportunities -> deployment design

**Output**: Portfolio of validated market opportunities with evidence, models, deployment plans.

### 9.2 Asset-to-Value (A2V)
**Entry Point**: User provides asset/entity data (factory, company, resource, process).
**Flow**:
1. M1: Asset profile created -> baseline established (capacity, utilization, costs, outputs)
2. E1: Scanner enriches with market context, benchmarks, comparable assets
3. E2: Gap Detector analyzes utilization, waste, leakage, bottlenecks
4. M3: Asset-specific gap registry (underused capacity, value leakage, process failures)
5. E3: Creation Engine executes P1, P3, P6 pathways (resource->value, process->opportunity, asset->opportunity)
6. M4: Improvement hypotheses generated (reconfiguration, new revenue, turnaround)
7. M5-M7: Validation loop with asset-specific financial modeling
8. M8: Validated improvements -> implementation plan

**Output**: Asset improvement portfolio with baseline, proposed changes, financial impact, implementation roadmap.

### 9.3 Shared Infrastructure
- Same canonical data model (12 entities)
- Same evidence framework (E0-E4, Source/Evidence/Claim registries)
- Same validation engine (M5-M7)
- Same opportunity state machine
- Same learning engine (M9)

---

## 10. MVP SCOPE & CONSTRAINTS

### 10.1 Users & Permissions (v1)
| Role | Description | Capabilities |
|------|-------------|--------------|
| **Owner / Administrator** | Primary user; single in v1 | Define research objectives, select markets, approve tasks, approve status changes, review assumptions, approve/reject decisions, manage config |
| **Research Operator** | Optional in v1 | Execute assigned tasks, collect/classify info, record evidence, update claims, run analyses (no approval authority) |

**No external users, no investor portal, no public submissions, no marketplace in v1.**

### 10.2 Eight MVP Screens
1. **Dashboard** -- Active investigations, opportunities by status, evidence gaps, pending approvals
2. **Market Investigation** -- Market definition, scope, participants, resources, needs, sources, evidence
3. **Opportunity Factory** -- Existing opportunities, gaps, creation wizard, cross-market adapter, comparison
4. **Asset-to-Value** -- Asset profile, utilization, costs/outputs, leakage, alternatives, hypotheses
5. **Validation Workspace** -- Claims, evidence, assumptions, contradictions, financial model, risk, decisions
6. **Administration** -- Sources, users/permissions, research config, audit logs, system settings
7. **Settings / Configuration** -- System-level config
8. **Audit / History** -- Decision history, evidence trail, state changes

### 10.3 Pilot Selection (Mandatory)
- One defined market OR one defined asset for first end-to-end test
- Market must have: accessible sources, identifiable participants, measurable economic activity
- Asset must have: baseline data available, cooperative owner/operator, measurable utilization
- Success = complete workflow from definition -> discovery -> creation -> validation -> decision

### 10.4 Explicit Non-Goals for MVP
- Global data coverage
- Multi-user collaboration
- Automated investment decisions
- Marketplace/transaction layer
- Mobile applications
- ERP/accounting integration
- Custom AI model training
- Multi-language beyond Arabic/English

---

## 11. ACCEPTANCE TESTS (A-H)

Eight test scenarios must pass for MVP completion. Each tests a distinct capability.

| Test | Name | Description | Pass Criteria |
|------|------|-------------|---------------|
| **A** | Market Intelligence | Define a market -> system produces structured economic map with traceable sources | Market map complete; all entities sourced; gaps identified |
| **B** | Unconventional Opportunity Discovery | System detects resource/gap/relationship -> proposes novel value creation mechanism | Mechanism economically coherent; evidence traceable; not a generic idea |
| **C** | Economic Model Creation | System converts problem/resource/relationships -> analyzable business model | Model has revenue, costs, investment, assumptions, scenarios, break-even |
| **D** | Asset-to-Value Analysis | User provides asset data -> system identifies improvement opportunities | Baseline quantified; leakage/waste identified; alternatives modeled; financial impact estimated |
| **E** | Evidence Verification | System distinguishes confirmed/inferred/assumed -> proposes verification actions | All claims graded; contradictions shown; missing evidence prioritized; verification plan actionable |
| **F** | Financial Feasibility | System builds financial model with assumptions, scenarios, sensitivity | Model deterministic; assumptions visible; scenarios calculated; break-even shown; downside bounded |
| **G** | Decision Gate | User can accept/reject/hold/redesign with recorded reasoning | Decision recorded; reasoning captured; conditions for change documented; audit trail complete |
| **H** | Sector Independence | System handles new economic activity not in predefined classifications without code changes | New sector/activity modeled using existing entities; pathways execute; no schema changes required |

**All 8 tests must PASS in an integrated workflow (not isolated demos) for Gate 2 approval.**

---

## 12. ARCHITECTURE DECISION -- MODULAR MONOLITH

### 12.1 Decision
**Architecture**: Modular Monolith (single deployable unit, internally modular)
**Rationale**: Simpler development, lower operational cost, easier debugging, no distributed system complexity at v1. Modules can be extracted to services later if scale demands.

### 12.2 Technology Stack (Pending -- PD-01..07)
The following are **pending decisions** to be resolved in Stage 1:

| Decision ID | Area | Options Under Consideration |
|-------------|------|----------------------------|
| PD-01 | Backend Language/Framework | Python/FastAPI (preferred), Node.js/Express, Go |
| PD-02 | Database | PostgreSQL (preferred, with JSONB + pgvector), PostgreSQL + TimescaleDB |
| PD-03 | Graph/Relationship Layer | PostgreSQL recursive CTEs (preferred), Neo4j (deferred), Apache Age |
| PD-04 | Frontend Framework | React + TypeScript (preferred), Vue 3, Svelte |
| PD-05 | UI Component Library | shadcn/ui + Tailwind (preferred), MUI, Ant Design |
| PD-06 | AI/ML Integration | OpenAI API + local embeddings (preferred), Anthropic, self-hosted Llama |
| PD-07 | Background Jobs | Celery + Redis (preferred), Dramatiq, Python RQ |
| PD-08 | Entity Resolution | Custom rule-based + ML (preferred), dedicated service |
| PD-09 | File Storage | S3-compatible (MinIO local, AWS S3 prod) |
| PD-10 | Authentication | OIDC (Keycloak/Auth0), custom JWT |
| PD-11 | Deployment Target | Docker Compose (dev), Kubernetes (prod, deferred), VM |
| PD-12 | Observability | Prometheus + Grafana + OpenTelemetry |

**No technology decision is final until Stage 1 approval gates (1A-1E).**

### 12.3 Deferred Architectural Elements (Explicitly NOT in v1)
- Microservices / Kubernetes
- Independent graph database
- Multi-agent AI infrastructure
- Custom LLM training
- Global data warehouse
- Marketplace/transaction layer
- Mobile apps
- ERP/accounting integration

---

## 13. UNRESOLVED CONCEPTUAL CONFLICTS (C1-C8)

These conflicts are **acknowledged, not resolved**. Each must be explicitly decided before the affected specification is designed.

| ID | Conflict | Description | Impact | Resolution Required By |
|----|----------|-------------|--------|------------------------|
| **C1** | Global Scope vs. Data Reality | System claims global coverage but data access is fragmented, expensive, and uneven | M1, E1, SD-010, SD-020 | Stage 1 (SD-010 design) |
| **C2** | AI Internal vs. User Expectation | Users expect chatbot/genAI reports; architecture mandates AI as internal layer only | UX (SD-050..056), AI permissions | Stage 1 (SD-050 design) |
| **C3** | Evidence Rigor vs. Discovery Speed | High evidence standards (E3/E4) slow down discovery; low standards produce noise | M3, M5, E2, SD-011, SD-022, SD-024 | Stage 1 (SD-011, SD-024 design) |
| **C4** | Model Extensibility vs. Stability | Sector independence requires flexible schema; stability requires fixed contracts | Canonical model (SD-001), Entity resolution (SD-002) | Stage 1 (SD-001, SD-002 design) |
| **C5** | Autonomous Discovery vs. Human Control | E1/E3 can run autonomously; but human must approve hypotheses before validation spend | M2, M4, E1, E3, SD-010, SD-012, SD-021, SD-023 | Stage 1 (SD-012, SD-023 design) |
| **C6** | Financial Modeling: AI vs. Deterministic | Core equations must be deterministic/reproducible; AI useful for assumptions/scenarios | E4, M6, SD-013, SD-025 | Stage 1 (SD-013 design) |
| **C7** | Sector Independence vs. Domain Knowledge | True sector-agnostic model vs. need for sector-specific logic/rules/benchmarks | M1, M3, M4, E2, E3, SD-003, SD-011, SD-012 | Stage 1 (SD-003, SD-011, SD-012 design) |
| **C8** | Single-User MVP vs. Multi-User Architecture | v1 is single owner; but architecture must support multi-user without rewrite | Auth (SD-031), Permissions, Audit (SD-032) | Stage 1 (SD-031, SD-032 design) |

**Each conflict resolution will be recorded as a formal Architecture Decision Record (ADR) in 02_Architecture_Decisions/.**

---

## 14. PENDING STRATEGIC DECISIONS (SD1-SD10 / PD-01..26)

### 14.1 Top-Level Strategic Decisions (SD1-SD10)

| ID | Decision | Description | Owner | Target |
|----|----------|-------------|-------|--------|
| **SD1** | Technology Stack | Backend, frontend, database, AI, deployment | Lead Architect | Stage 1A |
| **SD2** | Database Technology | PostgreSQL extensions, TimescaleDB, vector, graph | Data Architect | Stage 1A |
| **SD3** | AI/ML Framework | Provider selection, local vs. cloud, embedding strategy | AI Systems Engineer | Stage 1A |
| **SD4** | Frontend Framework | React/Vue/Svelte, component library, state management | Frontend Lead | Stage 1A |
| **SD5** | Deployment Target | Dev environment, prod target, CI/CD | DevOps | Stage 1A |
| **SD6** | Pilot Market | First market/asset for end-to-end validation | Product Owner + Domain Expert | Stage 1B |
| **SD7** | Evidence Thresholds | E2/E3/E4 criteria per claim type, gate requirements | Domain Expert | Stage 1B |
| **SD8** | Financial Engine Spec | Equation library, scenario types, sensitivity methods | Domain Expert / Quant | Stage 1B |
| **SD9** | Entity Resolution | Matching algorithms, confidence thresholds, merge rules | Data Architect | Stage 1B |
| **SD10** | API/Integration Layer | REST/GraphQL, connector framework, webhook system | Backend Lead | Stage 1B |

### 14.2 Detailed Pending Decisions (PD-01..26) -- from Specifications To Design
(See 04_Specifications_To_Design/SPECIFICATIONS_TO_DESIGN.md for full list of 42 specifications with owners and dependencies.)

---

## 15. REQUIREMENTS TRACEABILITY FRAMEWORK

### 15.1 Traceability Matrix Structure
Four-directional traceability linking:
`
Source Requirements (SR) <-> Functional Requirements (FR) <-> Specifications (SD) <-> Design Documents (SDD) <-> Implementation Tasks <-> Test Cases (AT)
`

### 15.2 Requirement ID Scheme
| Prefix | Source | Example |
|--------|--------|---------|
| **SR** | Strategic Requirements (this document) | SR-01: Global Scope, SR-02: Dual-Mode, SR-03: Evidence Honesty |
| **FR** | Functional Requirements (Module specs) | FR-M1-001: Market CRUD, FR-M4-003: Pathway Execution |
| **KD** | Key Decisions (Architecture, Conflicts) | KD-01: Modular Monolith, KD-02: 12 Entities, KD-03: E0-E4 Evidence |
| **PD** | Pending Decisions | PD-01: Tech Stack, PD-06: Pilot Market |
| **NFR** | Non-Functional Requirements | NFR-PERF-001: Query <2s, NFR-SEC-001: Auth required |
| **AT** | Acceptance Tests | AT-A: Market Intelligence, AT-H: Sector Independence |

### 15.3 Traceability Rules
1. Every FR traces to >=1 SR and >=1 KD.
2. Every SD traces to >=1 FR and resolves >=1 PD.
3. Every SDD traces to exactly 1 SD.
4. Every implementation task traces to >=1 SDD.
5. Every test case traces to >=1 FR and >=1 AT.
6. **No implementation without traceability to approved SD.**

### 15.4 Traceability Artifact
A living document REQUIREMENTS_TRACEABILITY.md in 03_Requirements_Traceability/ maintains the matrix. Updated at each approval gate.

---

## 16. DESIGN WORKFLOW

`
SPECIFICATION (SD-XXX)
    -> DESIGN REVIEW (Architect + Domain Expert + QA)
    -> DESIGN DOCUMENT (SDD-XXX)
    -> IMPLEMENTATION PLAN (Tasks, Estimates, Dependencies)
    -> CODE REVIEW -> TEST -> DEPLOY
`

**Each specification must produce:**
1. **SDD Document** -- Detailed design with diagrams, APIs, data flows, algorithms, error handling
2. **Review Record** -- Approvals, concerns, decisions, conflict resolutions
3. **Traceability Links** -- Back to requirements (RTF), forward to implementation tasks
4. **Testability Criteria** -- How to verify the design works (unit, integration, acceptance)
5. **Risk Assessment** -- Technical, data, AI, operational risks specific to this design

**Design Review Participants by Spec Type:**
- Data specs (SD-001..008): Data Architect + Domain Expert + Backend Lead
- Engine specs (SD-010..014): Engine Owner + Domain Expert + AI Systems Engineer
- Module specs (SD-020..028): Module Owner + Backend Lead + QA Lead
- Cross-cutting specs (SD-030..042): Relevant Lead + DevOps + Security
- UI/UX specs (SD-050..056): Frontend Lead + Domain Expert + Product Owner

---

## 17. APPROVAL GATES

12 named project gates: 8 stage-exit approval gates and 4 design-review gates before production code.

### Gate 0: Strategic Foundation (Current Stage)
> **Required**: Product Owner (final decision) + Codex AI-assisted architectural assessment + AI-assisted Domain & Economic Methodology Assessment under Product Owner oversight; no independent human certification is claimed
**Artifacts**: OF-SR-001 (this), OF-DR-001, OF-RTF-001, OF-STD-001, OF-RM-001, OF-AP-001
**Criteria**: Six primary foundation documents complete; 11 ADRs acknowledged with their individual statuses; conflicts acknowledged; decisions assigned; strategic direction approved.

### Gate 1A: Technology Stack Decisions
**Required**: Lead Architect + Data Architect + AI Systems Engineer + DevOps
**Decisions**: PD-01..05, PD-09..12 (Tech stack, DB, AI, Frontend, Deployment, Auth, Observability)

### Gate 1B: Data & Engine Architecture
**Required**: Data Architect + Economic Intelligence Lead + Opportunity Engineering Lead + Domain Expert
**Decisions**: PD-06, PD-07, PD-08, SD-001..008, SD-010..014 (Pilot, Evidence thresholds, Entity resolution, Core data, Engine specs)

### Gate 1C: Module & Cross-Cutting Specs
**Required**: Backend Lead + Frontend Lead + DevOps + QA Lead + Security
**Decisions**: SD-020..042 (Module specs, Cross-cutting specs)

### Gate 1D: UX/UI Specs
**Required**: Frontend Lead + Domain Expert + Product Owner
**Decisions**: SD-050..056 (Screen specs, Design system)

### Gate 1E: Stage 1 Consolidated Approval
**Required**: Lead Architect + Domain Expert + QA Lead + Product Owner
**Criteria**: All 42 SDD-XXX documents reviewed and approved; implementation plans ready; resource commitments confirmed.

### Gate 2: Phase 1 Implementation (Core Foundation)
**Required**: Lead Architect + QA Lead + Product Owner
**Criteria**: All Stage 2 deliverables complete; Acceptance Tests (Infrastructure) PASS; system runs end-to-end for core data management.

### Gate 3: Phase 2 Implementation (Opportunity Discovery)
**Required**: EI Lead + OE Lead + QA Lead + Product Owner
**Criteria**: Acceptance Tests A, B PASS; market investigation -> gap detection -> opportunity creation workflow works.

### Gate 4: Phase 3 Implementation (Creation & Validation)
**Required**: Domain Expert + Validation Lead + QA Lead + Product Owner
**Criteria**: Acceptance Tests C, E, F, G PASS; full validation workflow works.

### Gate 5: Phase 4 Implementation (Asset-to-Value)
**Required**: Asset Lead + QA Lead + Product Owner
**Criteria**: Acceptance Test D PASS; asset analysis -> improvement workflow works.

### Gate 6: Phase 5 Implementation (Learning & Expansion)
**Required**: Learning Lead + QA Lead + Product Owner
**Criteria**: Acceptance Test H PASS; learning loop operational; sector independence verified.

### Gate 7: Production Hardening
**Required**: Lead Architect + DevOps + Security + QA Lead + Product Owner
**Criteria**: All 8 ATs PASS in prod-like env; all NFR targets met; security audit passed; DR tested; docs complete.

---

## 18. DOCUMENT CONTROL & NEXT STEPS

### 18.1 Document Register

| Doc ID | Title | Location | Status | Version |
|--------|-------|----------|--------|---------|
| OF-SR-001 | Master Strategic Reference | 01_Strategic_Reference/ | **DRAFT — PO-2 FOUNDATION PACKAGE APPROVED; GATE 0 OPEN** | 1.0 |
| OF-DR-001 | Decision Register | 07_Decision_Register/ | **DRAFT — UPDATED; GATE 0 OPEN** | 1.0 |
| OF-RTF-001 | Requirements Traceability Framework | 03_Requirements_Traceability/ | **DRAFT** | 1.0 |
| OF-STD-001 | Specifications To Design | 04_Specifications_To_Design/ | **DRAFT** | 1.0 |
| OF-RM-001 | Roadmap | 05_Roadmap/ | **DRAFT** | 1.0 |
| OF-AP-001 | Approval Process | 06_Approval_Process/ | **DRAFT — GATE 0 OPEN** | 1.0 |
| -- | Architecture Decision Records | 02_Architecture_Decisions/ | **3 ACCEPTED; 8 OPEN** | 1.0 |

### 18.2 Gate 0 Reconciliation and Next Actions

| # | Action | Owner | Target |
|---|--------|-------|--------|
| 1 | Six primary foundation documents and 11 ADR records present | Codex file inspection | **DONE** |
| 2 | PO-1, PO-2, and PO-3 recorded | Product Owner | **DONE** |
| 3 | PO-D1 through PO-D4 and PO-A1 through PO-A2 recorded | Product Owner | **DONE** |
| 4 | Architectural and methodological assessment authority wording reconciled | Codex under Product Owner oversight | **DONE** |
| 5 | ADR statuses preserved: ADR-001..003 ACCEPTED; ADR-101..108 OPEN | Codex file inspection | **DONE** |
| 6 | Final Gate 0 closure decision | Product Owner | **PENDING** |
| 7 | Separate Stage 1 authorization decision | Product Owner | **NOT AUTHORIZED** |

### 18.3 Gate 0 Review Package
The following must be compiled for Gate 0 review:
- [ ] OF-SR-001 Master Strategic Reference (this document, complete)
- [ ] OF-DR-001 Decision Register (Known/Unknown/Pending with owners)
- [ ] OF-RTF-001 Requirements Traceability Framework (Matrix + Process)
- [ ] OF-STD-001 Specifications To Design (42 specs with owners/deps)
- [ ] OF-RM-001 Roadmap (8 Stages, 8 Milestones, Resource estimates)
- [ ] OF-AP-001 Approval Process (12 Named Approval Gates, Checklists, Templates, Authority Matrix)
- [ ] ADR Stubs (Architecture Decision Records for 3 key decisions + 8 conflicts)

### 18.4 Approval Authorities for Gate 0

**Authority Model:**
- **Product Owner** holds final decision authority for Gate 0 closure.
- **Codex (AI-assisted Architectural Review Tool)** provides architectural assessment, risks, and recommendations under Product Owner oversight.
- **AI-assisted Domain & Economic Methodology Assessment** provides the methodological assessment baseline under Product Owner oversight; the Domain Expert remains an advisory role for future or separately assigned review.
- Assessment findings and reservations must be documented and presented to the Product Owner.
- Unanimous approval is not required. The Product Owner makes the final Gate 0 decision.

**Assessment and decision records:**
`
  Product Owner (final Gate 0 closure decision): _________________________  Date: __________

  Codex AI-assisted architectural assessment record: OF-AP-001-G0 / PO-A1

  AI-assisted Domain & Economic Methodology Assessment record: OF-DR-001-DE-001 / PO-A2

  Human reviewer signatures: Not claimed by this Gate 0 record
`

---

**END OF MASTER STRATEGIC REFERENCE DOCUMENT -- VERSION 1.0**

*This document is the strategic foundation for OPPORTUNITY FACTORY. It defines what the system is, what it is not, how it thinks (5 disciplines), how it operates (9 modules, 5 engines, 6 pathways), what data it uses (12 entities), how it validates (E0-E4), and how decisions are made (12 named approval gates + 7 economic hard gates). No implementation begins until Gate 0 is passed.*

