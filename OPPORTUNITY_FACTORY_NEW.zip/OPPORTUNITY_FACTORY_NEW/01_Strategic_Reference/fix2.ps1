$content = Get-Content MASTER_STRATEGIC_REFERENCE.md -Raw
$pattern = "(### 18\.4 Approval Authorities for Gate 0\s*```\s*Product Owner: _________________________  Date: __________\s*Lead Architect: _________________________  Date: __________\s*Domain Expert: _________________________  Date: __________\s*\*\*\* UNANIMOUS APPROVAL REQUIRED \*\*\*\s*```)"
$replacement = "### 18.4 Approval Authorities for Gate 0

**Authority Model:**
- **Product Owner** holds final decision authority for Gate 0 closure.
- **Lead Architect** provides written technical assessment, risks, and recommendations.
- **Domain Expert** provides written economic/methodological assessment, risks, and recommendations.
- Their findings and reservations must be documented and presented to the Product Owner.
- Unanimous approval is not required. The Product Owner makes the final Gate 0 decision.

**Signatures:**
```
Product Owner: _________________________  Date: __________

Lead Architect: _________________________  Date: __________

Domain Expert: _________________________  Date: __________
```"
$content = $content -replace $pattern, $replacement
$content | Out-File -FilePath MASTER_STRATEGIC_REFERENCE.md -Encoding UTF8
Write-Host "Done"
