with open("MASTER_STRATEGIC_REFERENCE.md", "r", encoding="utf-8") as f:
    content = f.read()

old = """### 18.4 Approval Authorities for Gate 0
`
Product Owner: _________________________  Date: __________

Lead Architect: _________________________  Date: __________

Domain Expert: _________________________  Date: __________

*** UNANIMOUS APPROVAL REQUIRED ***
`"""

new = """### 18.4 Approval Authorities for Gate 0

**Authority Model:**
- **Product Owner** holds final decision authority for Gate 0 closure.
- **Lead Architect** provides written technical assessment, risks, and recommendations.
- **Domain Expert** provides written economic/methodological assessment, risks, and recommendations.
- Their findings and reservations must be documented and presented to the Product Owner.
- Unanimous approval is not required. The Product Owner makes the final Gate 0 decision.

**Signatures:**
`
Product Owner: _________________________  Date: __________

Lead Architect: _________________________  Date: __________

Domain Expert: _________________________  Date: __________
`"""

content = content.replace(old, new)

with open("MASTER_STRATEGIC_REFERENCE.md", "w", encoding="utf-8") as f:
    f.write(content)

print("Done")
