# SPECIFICATIONS THAT MUST BE DESIGNED
**Version:** 1.0  
**Status:** DRAFT — For Review  
**Date:** 2026-11-08  
**Project:** OPPORTUNITY FACTORY  
**Document ID:** OF-STD-001

---

## PURPOSE

This document lists all specifications that must be designed before implementation begins. Each specification maps to a functional module, engine, or cross-cutting concern. Design artifacts will be produced as separate documents (SDD-XXX).

---

## 1. CORE DATA SPECIFICATIONS

| Spec ID | Title | Description | Priority | Dependencies | Owner |
|---------|-------|-------------|----------|--------------|-------|
| SD-001 | **Canonical Data Model — Physical Schema** | Detailed table/collection definitions, indexes, constraints, relationships for all 12 entities | **MANDATORY** | KD-04, PD-02, PD-08 | Data Architect |
| SD-002 | **Entity Resolution Specification** | Matching algorithms, confidence thresholds, merge rules, audit trail | **MANDATORY** | KD-04, PD-08, FR-M1-002 | Data Architect |
| SD-003 | **Economic Ontology & Relationship Schema** | Relationship types, cardinality, attributes, temporal validity, inference rules | **MANDATORY** | KD-04, Economic Ontology spec | Domain Expert |
| SD-004 | **Evidence Ledger Schema** | Immutable log structure, grading fields, source links, claim links, hash chains | **MANDATORY** | KD-05, KD-20, PD-10 | Data Architect |
| SD-005 | **Claim Registry Schema** | Assertion structure, evidence links, grade, contradiction links, versioning | **MANDATORY** | KD-05, KD-06, PD-11 | Data Architect |
| SD-006 | **Source Registry Schema** | Source metadata, classification, quality scoring, access config, rate limits | **MANDATORY** | KD-05, Data & Intelligence spec | Data Architect |
| SD-007 | **Opportunity State Machine Schema** | State definitions, transition rules, required evidence, approval roles, audit fields | **MANDATORY** | KD-06, FR-M7, FR-M8 | Domain Expert |
| SD-008 | **Temporal Data Model** | Valid-time, transaction-time for entities, relationships, claims, evidence | **MANDATORY** | PD-12, E2, E5 | Data Architect |

---

## 2. ENGINE SPECIFICATIONS

| Spec ID | Title | Description | Priority | Dependencies | Owner |
|---------|-------|-------------|----------|--------------|-------|
| SD-010 | **E1: Economic World Scanner — Design Spec** | Source connectors, ingestion pipelines, entity extraction, model building, refresh cycles | **MANDATORY** | KD-10, Global Economic Signals spec, PD-16, PD-20 | Economic Intelligence Lead |
| SD-011 | **E2: System Failure & Gap Detector — Design Spec** | Value leakage algorithms, bottleneck detection, unmet demand identification, capacity analysis | **MANDATORY** | KD-10, Systems Failure Analysis spec, PD-17 | Economic Intelligence Lead |
| SD-012 | **E3: Opportunity Creation Engine — Design Spec** | 6 pathway implementations, pattern library, hypothesis builder, business model generator | **MANDATORY** | KD-09, KD-10, PD-18, PD-19, C7 | Opportunity Engineering Lead |
| SD-013 | **E4: Economic Model & Validation Engine — Design Spec** | Financial equations, assumption framework, scenario engine, sensitivity analysis, reproducibility | **MANDATORY** | KD-10, PD-14, PD-15, C6 | Domain Expert / Quant |
| SD-014 | **E5: Opportunity Deployment Engine — Design Spec** | Packaging templates, resource mapping, partner criteria, pilot designer, approval workflow | **MANDATORY** | KD-10, FR-M8, KD-06, PD-22 | Deployment Lead |

---

## 3. MODULE SPECIFICATIONS

| Spec ID | Title | Description | Priority | Dependencies | Owner |
|---------|-------|-------------|----------|--------------|-------|
| SD-020 | **M1: Market & Entity Intelligence — Module Spec** | APIs, data model, entity CRUD, relationship graph, search, import/export | **MANDATORY** | FR-M1-001..011, SD-001..008 | Backend Lead |
| SD-021 | **M2: Signal & Change Detection — Module Spec** | Signal ingestion, classification, change detection algorithms, notification triggers | **MANDATORY** | FR-M2-001..005, SD-010 | Backend Lead |
| SD-022 | **M3: Gap & Inefficiency Detection — Module Spec** | Gap registry, quantification methods, severity scoring, evidence linking | **MANDATORY** | FR-M3-001..006, SD-011 | Backend Lead |
| SD-023 | **M4: Opportunity Creation Engine — Module Spec** | Hypothesis management, pathway execution, pattern library, comparison tools | **MANDATORY** | FR-M4-001..008, SD-012 | Backend Lead |
| SD-024 | **M5: Evidence & Claim Management — Module Spec** | Source registry, evidence ledger, claim registry, contradiction tracking, review workflow | **MANDATORY** | FR-M5-001..008, SD-004..006 | Backend Lead |
| SD-025 | **M6: Economic Modeling & Validation — Module Spec** | Financial model builder, assumption register, scenario manager, risk assessment, validation workflow | **MANDATORY** | FR-M6-001..016, SD-013 | Backend Lead |
| SD-026 | **M7: Scoring & Decision Engine — Module Spec** | 5-dimension scoring, critical failure detection, prioritization, recommendation, audit trail | **MANDATORY** | FR-M7-001..009, SD-014 | Backend Lead |
| SD-027 | **M8: Deployment Preparation — Module Spec** | Dossier generator, resource mapper, partner evaluator, pilot designer, approval workflow | **MANDATORY** | FR-M8-001..009, SD-014 | Backend Lead |
| SD-028 | **M9: Learning & Calibration — Module Spec** | Outcome tracker, prediction comparator, rule updater, model recalibrator, knowledge manager | **MANDATORY** | FR-M9-001..008, Learning Engine spec | Backend Lead |

---

## 4. CROSS-CUTTING SPECIFICATIONS

| Spec ID | Title | Description | Priority | Dependencies | Owner |
|---------|-------|-------------|----------|--------------|-------|
| SD-030 | **API & Integration Layer Spec** | REST/GraphQL APIs, connector framework, auth, rate limiting, webhook system | **MANDATORY** | PD-20, System Arch Sec 3.5, External Integrations | Backend Lead |
| SD-031 | **Authentication & Authorization Spec** | OIDC/SAML integration, RBAC roles, permissions matrix, session management | **MANDATORY** | PD-22, NFR-SEC-001, NFR-SEC-002 | Backend Lead |
| SD-032 | **Audit Logging Spec** | Event types, structured format, tamper evidence, retention, query API | **MANDATORY** | KD-20, NFR-SEC-004, PD-25 | DevOps |
| SD-033 | **Background Job Processing Spec** | Queue system, job types, retry policies, dead letter, scheduling, monitoring | **MANDATORY** | UD-07, E1-E5 async ops, PD-23 | Backend Lead |
| SD-034 | **File & Document Storage Spec** | Object storage, versioning, access control, metadata, search indexing | **MANDATORY** | UD-08, Source docs, asset data | DevOps |
| SD-035 | **Caching Strategy Spec** | Cache layers, invalidation policies, distributed vs local, warming strategies | **MANDATORY** | UD-06, NFR-PERF-001..006 | Backend Lead |
| SD-036 | **Search & Discovery Spec** | Full-text, semantic, graph search; indexing; faceting; relevance tuning | **MANDATORY** | UD-05, M1, M2, M3 query patterns | Backend Lead |
| SD-037 | **Geospatial Capabilities Spec** | Coordinate systems, spatial queries, PostGIS vs service, map visualization | **MANDATORY** | UD-09, Asset locations, logistics | Backend Lead |
| SD-038 | **Internationalization Spec** | i18n framework, RTL support, currency, dates, number formats, translation workflow | **MANDATORY** | UD-01, C1, global scope | Frontend Lead |
| SD-039 | **Testing Strategy Spec** | Unit, integration, contract, e2e, property-based, chaos; test data management | **MANDATORY** | UD-11, Module independence, Engine contracts | QA Lead |
| SD-040 | **Observability Spec** | Metrics, logs, traces, alerting, dashboards, SLO definitions | **MANDATORY** | UD-12, Production readiness | DevOps |
| SD-041 | **Backup & Disaster Recovery Spec** | RPO/RTO targets, backup schedules, restore procedures, failover | **MANDATORY** | PD-26, NFR-OPS-003 | DevOps |
| SD-042 | **Cost Management Spec** | LLM token budgets, API quotas, compute monitoring, alerts | **MANDATORY** | UD-15, PD-03, NFR-AI-002 | AI Systems Engineer |

---

## 5. UI/UX SPECIFICATIONS

| Spec ID | Title | Description | Priority | Dependencies | Owner |
|---------|-------|-------------|----------|--------------|-------|
| SD-050 | **Dashboard — Screen Spec** | Active investigations, opportunities by status, evidence gaps, pending approvals, progress | **MANDATORY** | SR-MVP-004, NFR-UX-001..005, PD-04 | Frontend Lead |
| SD-051 | **Market Investigation — Screen Spec** | Market definition, scope, participants, resources, needs, sources, evidence | **MANDATORY** | SR-MVP-004, FR-M1, FR-M2, FR-M3 | Frontend Lead |
| SD-052 | **Opportunity Factory — Screen Spec** | Existing opportunities, gaps, creation wizard, cross-market adapter, comparison view | **MANDATORY** | SR-MVP-004, FR-M3, FR-M4, FR-M7 | Frontend Lead |
| SD-053 | **Asset-to-Value — Screen Spec** | Asset profile, utilization, costs/outputs, leakage, alternatives, hypotheses | **MANDATORY** | SR-MVP-004, FR-M1, FR-M3, FR-M4, FR-M6 | Frontend Lead |
| SD-054 | **Validation Workspace — Screen Spec** | Claims, evidence, assumptions, contradictions, financial model, risk, decisions | **MANDATORY** | SR-MVP-004, FR-M5, FR-M6, FR-M7 | Frontend Lead |
| SD-055 | **Administration — Screen Spec** | Sources, users/permissions, research config, audit logs, system settings | **MANDATORY** | SR-MVP-004, PD-22, PD-25, NFR-SEC-002 | Frontend Lead |
| SD-056 | **Design System & Component Library** | Colors, typography, components, patterns, accessibility, RTL, dark mode | **MANDATORY** | SD-050..055, NFR-UX-001..005, UD-01 | Frontend Lead |

---

## 6. DESIGN WORKFLOW

`
SPECIFICATION (SD-XXX) 
    -> DESIGN REVIEW (Architect + Domain Expert + QA)
    -> DESIGN DOCUMENT (SDD-XXX)
    -> IMPLEMENTATION PLAN (Tasks, Estimates, Dependencies)
    -> CODE REVIEW -> TEST -> DEPLOY
`

**Each specification must have:**
1. **SDD Document** — Detailed design with diagrams, APIs, data flows, algorithms
2. **Review Record** — Approvals, concerns, decisions
3. **Traceability Links** — Back to requirements (RTF), forward to tasks
4. **Testability Criteria** — How to verify the design works

---



## 8. SPECIFICATION NUMBERING RATIONALE

The specification numbering scheme uses category-based ranges with intentional gaps for future expansion:

| Range | Category | Count | Gaps (Reserved) |
|-------|----------|-------|-----------------|
| SD-001..008 | Core Data Specifications | 8 | SD-009 reserved for future core data spec |
| SD-010..014 | Engine Specifications | 5 | (sequential, no gap) |
| SD-020..028 | Module Specifications | 9 | SD-029 reserved for future module spec |
| SD-030..042 | Cross-Cutting Specifications | 13 | SD-043..049 reserved for future cross-cutting specs |
| SD-050..056 | UI/UX Specifications | 7 | SD-057+ reserved for future UI specs |

**Total: 42 specifications** (not 56). The numbering gaps are intentional to allow future specifications to be inserted in logical categories without renumbering existing specifications.

This explains the discrepancy between the specification count (42) and the highest specification number (SD-056).

## 7. DOCUMENT CONTROL

| Field | Value |
|-------|-------|
| **Document ID** | OF-STD-001 |
| **Version** | 1.0 (Draft) |
| **Status** | Under Review |
| **Owner** | Lead Architect |
| **Reviewers** | Technical Lead, Domain Expert, QA Lead |
| **Approval Required** | **Yes — Before Any Design Work Begins** |

---

**END OF SPECIFICATIONS TO DESIGN**

*This list is the contract for design phase. No specification may be omitted without formal approval. Each SD-XXX produces an SDD-XXX design document.*
