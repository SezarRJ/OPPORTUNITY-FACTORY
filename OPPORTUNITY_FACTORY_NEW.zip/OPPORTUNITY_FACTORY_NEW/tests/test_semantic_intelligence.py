from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


TOKEN_HEADERS = {"Authorization": "Bearer dev-owner"}


@dataclass(frozen=True)
class SemanticBenchmark:
    case_id: str
    name: str
    source_content: str
    expected_pathways: tuple[str, ...]
    expected_concept: str | None
    mode: str = "M2O"
    asset_context: str = ""


SEMANTIC_BENCHMARKS = (
    SemanticBenchmark(
        case_id="SB-01",
        name="Industrial import substitution",
        source_content=(
            "The domestic market relies on imported supply while local production "
            "could replace imported supply."
        ),
        expected_pathways=("P2", "P4"),
        expected_concept="import_substitution",
    ),
    SemanticBenchmark(
        case_id="SB-02",
        name="Agricultural value-chain leakage",
        source_content=(
            "Yield reduction between value chain stages is documented after harvest."
        ),
        expected_pathways=("P3",),
        expected_concept="process_loss",
    ),
    SemanticBenchmark(
        case_id="SB-03",
        name="Industrial by-product utilization",
        source_content="Discarded by-products remain available at the plant.",
        expected_pathways=("P1",),
        expected_concept="underutilized_capacity",
    ),
    SemanticBenchmark(
        case_id="SB-04",
        name="Arabic supply-demand mismatch",
        source_content="الطلب يتجاوز العرض في المنطقة.",
        expected_pathways=("P2",),
        expected_concept="unmet_demand",
    ),
    SemanticBenchmark(
        case_id="SB-05",
        name="Cross-market price difference",
        source_content="The same product commands different prices across regions.",
        expected_pathways=("P4",),
        expected_concept="price_difference",
    ),
    SemanticBenchmark(
        case_id="SB-06",
        name="Underutilized infrastructure",
        source_content="The facility operates below its design limit.",
        expected_pathways=("P1",),
        expected_concept="underutilized_capacity",
    ),
    SemanticBenchmark(
        case_id="SB-07",
        name="Resource-to-industry combination",
        source_content=(
            "Feedstock and transformation capability can be linked into one arrangement."
        ),
        expected_pathways=("P5",),
        expected_concept="combination",
    ),
    SemanticBenchmark(
        case_id="SB-08",
        name="Existing business-model replication",
        source_content=(
            "An established service operates abroad with repeat users and an "
            "operating record."
        ),
        expected_pathways=("P4",),
        expected_concept="cross_market_replication",
    ),
    SemanticBenchmark(
        case_id="SB-09",
        name="Missing economic links",
        source_content="Producers and buyers are disconnected.",
        expected_pathways=("P5",),
        expected_concept="missing_economic_link",
    ),
    SemanticBenchmark(
        case_id="SB-10",
        name="Asset reconfiguration",
        source_content=(
            "The site can be converted for a different operating purpose after "
            "technical validation."
        ),
        expected_pathways=("P6",),
        expected_concept="asset_reconfiguration",
        mode="A2V",
        asset_context="Existing production site",
    ),
    SemanticBenchmark(
        case_id="SB-11",
        name="No valid opportunity signal",
        source_content=(
            "The reference records stable operations and complete reporting for a "
            "descriptive dataset."
        ),
        expected_pathways=(),
        expected_concept=None,
    ),
)


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    return TestClient(create_app(tmp_path / "semantic.sqlite3"))


def _create_case(
    client: TestClient,
    case: SemanticBenchmark,
) -> dict:
    investigation = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": f"Semantic case {case.case_id}",
            "mode": case.mode,
            "country": "Controlled country",
            "geography": "Controlled geography",
            "market": "Controlled market",
            "activity": "Controlled activity",
            "objective": "Assess the registered economic record.",
            "asset_context": case.asset_context,
        },
    )
    assert investigation.status_code == 201
    investigation_id = investigation.json()["id"]

    source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": f"Evidence {case.case_id}",
            "source_type": "semantic-benchmark",
            "data_domain": "controlled economic intelligence",
            "last_updated": "2026-11-01",
            "reliability": 0.9,
            "independence_score": 0.9,
            "source_family": case.case_id,
            "evidence_level": "E2",
            "content": case.source_content,
        },
    )
    assert source.status_code == 201
    source_id = source.json()["id"]

    claim = client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": "The controlled evidence is linked to the investigation.",
            "source_id": source_id,
            "evidence_level": "E2",
            "confidence": 0.8,
        },
    )
    assert claim.status_code == 201

    analysis = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert analysis.status_code == 200
    return analysis.json()["result"]


@pytest.mark.parametrize(
    "case",
    SEMANTIC_BENCHMARKS,
    ids=lambda case: case.case_id,
)
def test_semantic_benchmark_register(
    client: TestClient,
    case: SemanticBenchmark,
) -> None:
    result = _create_case(client, case)
    indicated = {
        evaluation["id"]
        for evaluation in result["pathway_evaluations"]
        if evaluation["indicated"]
    }
    assert indicated == set(case.expected_pathways)
    assert indicated <= {"P1", "P2", "P3", "P4", "P5", "P6"}
    assert "P7" not in str(result)

    concepts = result["semantic_interpretation"]["concepts"]
    if case.expected_concept is None:
        assert concepts == {}
        assert result["opportunities"] == []
        assert result["status"] == "no-supported-pathway"
        return

    assert case.expected_concept in concepts
    concept = concepts[case.expected_concept]
    assert concept["evidence_refs"]
    assert concept["basis"]
    for pathway_id in case.expected_pathways:
        pathway = next(
            evaluation
            for evaluation in result["pathway_evaluations"]
            if evaluation["id"] == pathway_id
        )
        assert pathway["semantic_matches"]
        assert pathway["reasoning"]
        assert pathway["matched_signals"]


@pytest.mark.parametrize(
    ("text", "concept", "pathway", "expected_alias"),
    (
        (
            "La demanda supera la oferta en la región.",
            "unmet_demand",
            "P2",
            "la demanda supera la oferta",
        ),
        (
            "الطلب يتجاوز العرض في المنطقة.",
            "unmet_demand",
            "P2",
            "الطلب يتجاوز العرض",
        ),
    ),
)
def test_multilingual_semantic_provenance(
    client: TestClient,
    text: str,
    concept: str,
    pathway: str,
    expected_alias: str,
) -> None:
    result = _create_case(
        client,
        SemanticBenchmark(
            case_id="SB-MULTI",
            name="Multilingual benchmark",
            source_content=text,
            expected_pathways=(pathway,),
            expected_concept=concept,
        ),
    )
    matched_terms = result["semantic_interpretation"]["concepts"][concept][
        "matched_terms"
    ]
    assert expected_alias in matched_terms
    assert all(
        reference.startswith(("source:", "claim:", "investigation:"))
        for reference in result["semantic_interpretation"]["concepts"][concept][
            "evidence_refs"
        ]
    )


def test_structured_metrics_activate_pathways_without_literal_terms(
    client: TestClient,
) -> None:
    investigation = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": "Structured economic metrics",
            "country": "Controlled country",
            "geography": "Controlled geography",
            "market": "Controlled market",
            "activity": "Controlled activity",
            "objective": "Assess the registered economic record.",
        },
    )
    assert investigation.status_code == 201
    investigation_id = investigation.json()["id"]

    source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Neutral measured records",
            "source_type": "semantic-benchmark",
            "evidence_level": "E2",
            "content": "Measured values are registered for the controlled case.",
        },
    )
    assert source.status_code == 201
    source_id = source.json()["id"]
    claim = client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": "The measured records are linked to the case.",
            "source_id": source_id,
            "evidence_level": "E2",
        },
    )
    assert claim.status_code == 201

    metrics = (
        ("production_capacity", 100),
        ("utilized_capacity", 50),
        ("demand", 120),
        ("supply", 80),
        ("input_quantity", 100),
        ("output_quantity", 70),
    )
    for metric_type, value in metrics:
        response = client.post(
            f"/api/investigations/{investigation_id}/metrics",
            headers=TOKEN_HEADERS,
            json={
                "metric_type": metric_type,
                "name": "Observed value",
                "value": value,
                "unit": "unit",
                "status": "known",
                "economic_activity": "Controlled economic activity",
                "source_id": source_id,
            },
        )
        assert response.status_code == 201

    analysis = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert analysis.status_code == 200
    result = analysis.json()["result"]
    indicated = {
        evaluation["id"]
        for evaluation in result["pathway_evaluations"]
        if evaluation["indicated"]
    }
    assert indicated == {"P1", "P2", "P3"}
    for concept_name in ("underutilized_capacity", "unmet_demand", "process_loss"):
        concept = result["semantic_interpretation"]["concepts"][concept_name]
        assert "deterministic_calculation" in concept["basis"]
        assert any(
            reference.startswith("calculation:")
            for reference in concept["evidence_refs"]
        )
    lexical_matches = {
        evaluation["id"]: evaluation["lexical_matches"]
        for evaluation in result["pathway_evaluations"]
        if evaluation["id"] in {"P1", "P2", "P3"}
    }
    assert lexical_matches["P1"] == []
    assert lexical_matches["P3"] == []
    assert lexical_matches["P2"] in ([], ["demand"])


def test_semantic_signals_cannot_override_conflicting_hard_gates(
    client: TestClient,
) -> None:
    result = _create_case(
        client,
        SemanticBenchmark(
            case_id="SB-CONFLICT",
            name="Conflicting hard gates",
            source_content=(
                "The domestic market relies on imported supply. Illegal and "
                "prohibited. No mechanism, no payer, no access, no evidence, "
                "no capital, and unsafe."
            ),
            expected_pathways=("P2", "P4"),
            expected_concept="import_substitution",
        ),
    )
    assert result["hard_gate_decision"]["status"] == "blocked"
    assert result["controls"]["ai_override_of_hard_gates"] is False
    assert result["opportunities"]
    assert all(
        opportunity["status"] == "blocked"
        for opportunity in result["opportunities"]
    )
