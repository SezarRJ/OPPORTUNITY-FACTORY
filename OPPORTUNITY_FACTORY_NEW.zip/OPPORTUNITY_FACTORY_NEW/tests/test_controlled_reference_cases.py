from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from tests.reference_cases import REFERENCE_CASES, ReferenceCase


TOKEN_HEADERS = {"Authorization": "Bearer dev-owner"}
PATHWAYS = {"P1", "P2", "P3", "P4", "P5", "P6"}


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    return TestClient(create_app(tmp_path / "controlled.sqlite3"))


def _run_case(client: TestClient, case: ReferenceCase) -> dict:
    investigation = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": f"{case.case_id} · {case.name}",
            "mode": case.mode,
            "country": "Controlled reference country",
            "geography": "Controlled geography",
            "market": "Controlled market",
            "activity": case.activity,
            "objective": case.objective,
            "asset_context": case.asset_context,
        },
    ).json()
    investigation_id = investigation["id"]
    source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": f"{case.case_id} source",
            "source_type": "controlled-reference",
            "data_domain": "economic reference",
            "last_updated": "2026-11-01",
            "reliability": 0.9,
            "independence_score": 0.9,
            "source_family": case.case_id,
            "evidence_level": "E2",
            "content": case.source_content,
        },
    ).json()
    client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": case.claim_text,
            "source_id": source["id"],
            "evidence_level": "E2",
            "confidence": 0.8,
        },
    )
    response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert response.status_code == 200
    return response.json()["result"]


@pytest.mark.parametrize("case", REFERENCE_CASES, ids=lambda case: case.case_id)
def test_controlled_reference_case_expected_pathways(
    client: TestClient,
    case: ReferenceCase,
) -> None:
    result = _run_case(client, case)
    indicated = {
        pathway["id"]
        for pathway in result["pathway_evaluations"]
        if pathway["indicated"]
    }
    assert indicated == set(case.expected_pathways)
    assert indicated <= PATHWAYS
    assert all("P7" not in str(pathway) for pathway in result["pathway_evaluations"])
    if case.mode == "A2V":
        assert result["mode"] == "A2V"
        assert result["economic_logic"]["context"]["asset_context"]
    if case.expected_pathways:
        assert result["opportunities"]
        assert {
            opportunity["pathway"] for opportunity in result["opportunities"]
        } == set(case.expected_pathways)
        assert case.expected_origin in {
            opportunity["origin"] for opportunity in result["opportunities"]
        }
    else:
        assert result["opportunities"] == []
        assert result["status"] == "no-supported-pathway"


def test_pass_fail_unknown_and_conflicting_hard_gates(client: TestClient) -> None:
    def run_gate_case(content: str) -> dict:
        investigation = client.post(
            "/api/investigations",
            headers=TOKEN_HEADERS,
            json={
                "title": "Hard Gate controlled case",
                "country": "Controlled country",
                "market": "Controlled market",
                "activity": "Controlled activity",
                "objective": "Assess unmet demand for a controlled service.",
            },
        ).json()
        investigation_id = investigation["id"]
        source = client.post(
            f"/api/investigations/{investigation_id}/sources",
            headers=TOKEN_HEADERS,
            json={
                "title": "Hard Gate evidence",
                "source_type": "controlled-reference",
                "evidence_level": "E2",
                "independence_score": 0.9,
                "content": content,
            },
        ).json()
        client.post(
            f"/api/investigations/{investigation_id}/claims",
            headers=TOKEN_HEADERS,
            json={
                "text": content,
                "source_id": source["id"],
                "evidence_level": "E2",
            },
        )
        return client.post(
            f"/api/investigations/{investigation_id}/analysis",
            headers=TOKEN_HEADERS,
        ).json()["result"]

    pass_result = run_gate_case(
        "Licensed and lawfully permitted. Viable mechanism. Identified payer and "
        "buyer identified. Resource access and critical resource available. "
        "Verified evidence. Capital available and funded. Safe and compliance confirmed."
    )
    assert pass_result["hard_gate_decision"]["status"] == "passed"
    assert all(gate["status"] == "pass" for gate in pass_result["hard_gates"])
    assert pass_result["status"] == "candidate-hypotheses"
    assert all(
        opportunity["status"] == "hypothesis"
        for opportunity in pass_result["opportunities"]
    )

    unknown_result = run_gate_case("Observed unmet demand with no gate conclusion.")
    assert unknown_result["hard_gate_decision"]["status"] == "awaiting"
    assert all(gate["status"] == "unknown" for gate in unknown_result["hard_gates"])
    assert unknown_result["status"] == "awaiting-hard-gates"
    assert all(
        opportunity["status"] == "blocked"
        for opportunity in unknown_result["opportunities"]
    )

    fail_result = run_gate_case(
        "The activity is illegal, has no mechanism, no payer, no access, "
        "no evidence, no capital, and is unsafe."
    )
    assert fail_result["hard_gate_decision"]["status"] == "blocked"
    assert all(gate["status"] == "fail" for gate in fail_result["hard_gates"])
    assert fail_result["status"] == "blocked-by-hard-gate"

    conflict_result = run_gate_case(
        "Licensed but prohibited. Viable mechanism but no mechanism. "
        "Identified payer but no payer. Resource access but no access. "
        "Verified evidence but no evidence. Capital available but no capital. "
        "Safe but unsafe."
    )
    assert conflict_result["hard_gate_decision"]["status"] == "blocked"
    assert all(gate["status"] == "conflicting" for gate in conflict_result["hard_gates"])
    assert conflict_result["status"] == "blocked-by-hard-gate"
    assert conflict_result["controls"]["ai_override_of_hard_gates"] is False


def test_evidence_levels_traceability_independence_freshness_and_replay(
    client: TestClient,
) -> None:
    for level in ("E0", "E1", "E2", "E3", "E4"):
        investigation = client.post(
            "/api/investigations",
            headers=TOKEN_HEADERS,
            json={
                "title": f"Evidence {level}",
                "country": "Controlled country",
                "market": "Controlled market",
                "activity": "Controlled activity",
                "objective": "Assess unmet demand for a controlled service.",
            },
        ).json()
        investigation_id = investigation["id"]
        source = client.post(
            f"/api/investigations/{investigation_id}/sources",
            headers=TOKEN_HEADERS,
            json={
                "title": f"Evidence {level} source",
                "source_type": "controlled-reference",
                "last_updated": "2026-11-01",
                "evidence_level": level,
                "content": "Unmet demand is documented.",
            },
        ).json()
        client.post(
            f"/api/investigations/{investigation_id}/claims",
            headers=TOKEN_HEADERS,
            json={
                "text": "Unmet demand is documented.",
                "source_id": source["id"],
                "evidence_level": level,
            },
        )
        result_response = client.post(
            f"/api/investigations/{investigation_id}/analysis",
            headers=TOKEN_HEADERS,
        )
        result = result_response.json()["result"]
        assert result["evidence"]["evidence_level"] == level
        if level == "E0":
            assert result["status"] == "insufficient-evidence"
        else:
            assert "not a guarantee" in result["evidence_definitions"]["E4"]

    investigation = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": "Independence and replay",
            "country": "Controlled country",
            "market": "Controlled market",
            "activity": "Controlled activity",
            "objective": "Assess unmet demand for a controlled service.",
        },
    ).json()
    investigation_id = investigation["id"]
    first_source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Original report",
            "uri": "https://example.test/original",
            "source_family": "report-family-1",
            "independence_score": 0.9,
            "last_updated": "2020-01-01",
            "evidence_level": "E2",
            "content": "Unmet demand is documented.",
        },
    ).json()
    second_source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Republished report",
            "uri": "https://example.test/republished",
            "source_family": "report-family-1",
            "independence_score": 0.9,
            "last_updated": "2026-11-01",
            "evidence_level": "E2",
            "content": "Unmet demand is documented.",
        },
    ).json()
    third_source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Independent survey",
            "uri": "https://example.test/survey",
            "source_family": "survey-family-2",
            "independence_score": 0.9,
            "last_updated": "2026-11-01",
            "evidence_level": "E2",
            "content": "Unmet demand is documented.",
        },
    ).json()
    for source in (first_source, second_source, third_source):
        client.post(
            f"/api/investigations/{investigation_id}/claims",
            headers=TOKEN_HEADERS,
            json={
                "text": "Unmet demand is documented.",
                "source_id": source["id"],
                "evidence_level": "E2",
            },
        )
    analysis_response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    result = analysis_response.json()["result"]
    assert result["evidence"]["independent_source_count"] == 2
    assert len(result["evidence"]["independence_groups"]["family:report-family-1"]) == 2
    freshness = {
        item["source_id"]: item["freshness"]["status"]
        for item in result["evidence"]["quality_observations"]
    }
    assert freshness[first_source["id"]] == "stale"
    assert freshness[second_source["id"]] == "fresh"
    assert freshness[third_source["id"]] == "fresh"

    run_id = analysis_response.json()["analysis_run"]["id"]
    replay = client.post(
        f"/api/investigations/{investigation_id}/analysis/{run_id}/replay",
        headers=TOKEN_HEADERS,
    )
    assert replay.status_code == 200
    assert replay.json()["reproducible"] is True


def test_unlinked_claim_file_upload_edit_persistence_and_audit(
    client: TestClient,
    tmp_path: Path,
) -> None:
    investigation = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": "Evidence workflow",
            "country": "Controlled country",
            "market": "Controlled market",
            "activity": "Controlled activity",
            "objective": "Assess unmet demand.",
        },
    ).json()
    investigation_id = investigation["id"]
    update = client.patch(
        f"/api/investigations/{investigation_id}",
        headers=TOKEN_HEADERS,
        json={"title": "Evidence workflow edited"},
    )
    assert update.status_code == 200
    assert update.json()["title"] == "Evidence workflow edited"

    upload = client.post(
        f"/api/investigations/{investigation_id}/source-file",
        headers=TOKEN_HEADERS,
        files={"file": ("reference.txt", b"Unmet demand is documented.", "text/plain")},
        data={
            "title": "Uploaded reference",
            "source_family": "uploaded-family",
            "evidence_level": "E2",
        },
    )
    assert upload.status_code == 201
    uploaded_source = upload.json()
    assert uploaded_source["file_name"] == "reference.txt"
    assert uploaded_source["file_path"]
    assert (tmp_path / uploaded_source["file_path"]).exists()

    unlinked_claim = client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={"text": "This claim has no evidence link.", "evidence_level": "E2"},
    )
    assert unlinked_claim.status_code == 201
    analysis = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert analysis.status_code == 200
    result = analysis.json()["result"]
    assert result["status"] == "insufficient-evidence"
    assert any(gap["id"] == "GAP-TRACEABILITY-001" for gap in result["gaps"])

    bundle = client.get(
        f"/api/investigations/{investigation_id}",
        headers=TOKEN_HEADERS,
    ).json()
    event_types = {event["event_type"] for event in bundle["audit_events"]}
    assert {"investigation.created", "investigation.updated", "source.created"} <= event_types

    bad_relationship = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={
            "subject_entity_id": 999,
            "object_entity_id": 1000,
            "relationship_type": "supplies",
        },
    )
    assert bad_relationship.status_code == 400

    assert client.get(
        f"/api/investigations/{investigation_id}",
        headers={"Authorization": "Bearer wrong-token"},
    ).status_code == 401


def test_a2v_requires_explicit_asset_context(client: TestClient) -> None:
    response = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": "Incomplete A2V case",
            "mode": "A2V",
            "country": "Controlled country",
            "market": "Controlled market",
            "activity": "Controlled activity",
            "objective": "Assess an asset.",
        },
    )
    assert response.status_code == 422
