from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


TOKEN_HEADERS = {"Authorization": "Bearer dev-owner"}


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    return TestClient(create_app(tmp_path / "test.sqlite3"))


def create_investigation(client: TestClient) -> int:
    response = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": "Cold-chain capacity investigation",
            "country": "Iraq",
            "geography": "Northern region",
            "market": "Food distribution",
            "activity": "Cold-chain logistics",
            "objective": (
                "Understand underused asset capacity, unmet demand, process waste, "
                "and whether a successful model can be adapted."
            ),
            "asset_context": "Idle cold-storage facility and distribution operation",
        },
    )
    assert response.status_code == 201
    return response.json()["id"]


def test_health_and_api_authentication(client: TestClient) -> None:
    assert client.get("/health").json()["status"] == "ok"
    response = client.get("/api/investigations")
    assert response.status_code == 401
    assert client.get("/api/investigations", headers=TOKEN_HEADERS).json() == []


def test_investigation_evidence_and_analysis_traceability(client: TestClient) -> None:
    investigation_id = create_investigation(client)
    source_response = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Regional cold-chain assessment",
            "uri": "local://reference/cold-chain",
            "source_type": "controlled-reference",
            "data_domain": "capacity and demand",
            "last_updated": "2026-10-01",
            "reliability": 0.9,
            "independence_score": 0.8,
            "evidence_level": "E2",
            "content": (
                "The region has underused capacity, unmet demand, process bottlenecks, "
                "waste, and an existing model suitable for adaptation."
            ),
        },
    )
    assert source_response.status_code == 201
    source_id = source_response.json()["id"]

    claim_response = client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": "Idle capacity and unmet demand create a measurable service gap.",
            "source_id": source_id,
            "evidence_level": "E2",
            "confidence": 0.8,
        },
    )
    assert claim_response.status_code == 201

    first_entity = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "asset", "name": "Cold-storage facility"},
    ).json()
    second_entity = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "company", "name": "Distribution operator"},
    ).json()
    relationship_response = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={
            "subject_entity_id": first_entity["id"],
            "object_entity_id": second_entity["id"],
            "relationship_type": "supplies",
            "verification_status": "potential",
            "source_id": source_id,
        },
    )
    assert relationship_response.status_code == 201

    analysis_response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert analysis_response.status_code == 200
    result = analysis_response.json()["result"]
    assert result["status"] == "awaiting-hard-gates"
    assert result["evidence"]["evidence_level"] == "E2"
    assert result["controls"]["ai_override_of_hard_gates"] is False
    assert {item["id"] for item in result["pathway_evaluations"]} <= {
        "P1",
        "P2",
        "P3",
        "P4",
        "P5",
        "P6",
    }
    assert result["opportunities"]
    assert all(
        opportunity["status"] == "blocked"
        for opportunity in result["opportunities"]
    )
    assert result["hard_gate_decision"]["status"] == "awaiting"
    assert all(gate["status"] == "unknown" for gate in result["hard_gates"])

    latest = client.get(
        f"/api/investigations/{investigation_id}/analysis/latest",
        headers=TOKEN_HEADERS,
    )
    assert latest.status_code == 200
    assert latest.json()["result"]["status"] == "awaiting-hard-gates"


def test_insufficient_evidence_does_not_create_opportunity(client: TestClient) -> None:
    investigation_id = create_investigation(client)
    response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert response.status_code == 200
    result = response.json()["result"]
    assert result["status"] == "insufficient-evidence"
    assert result["opportunities"] == []
    assert any(gap["id"] == "GAP-EVIDENCE-001" for gap in result["gaps"])


def test_failed_hard_gate_blocks_hypothesis_even_when_evidence_exists(
    client: TestClient,
) -> None:
    investigation_id = create_investigation(client)
    source_id = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Regulatory reference",
            "evidence_level": "E2",
            "independence_score": 0.9,
            "content": "The proposed operation is illegal and not permitted.",
        },
    ).json()["id"]
    client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": "The activity has an unmet demand but is illegal.",
            "source_id": source_id,
            "evidence_level": "E2",
        },
    )

    response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    result = response.json()["result"]
    assert result["status"] == "blocked-by-hard-gate"
    legal_gate = next(gate for gate in result["hard_gates"] if gate["id"] == "HG-1")
    assert legal_gate["status"] == "fail"
    assert all(opportunity["status"] == "blocked" for opportunity in result["opportunities"])


def test_html_login_and_workspace(client: TestClient) -> None:
    login_page = client.get("/login")
    assert login_page.status_code == 200
    assert "Enter the owner token" in login_page.text
    denied = client.get("/", follow_redirects=False)
    assert denied.status_code == 303
    assert denied.headers["location"] == "/login"

    login_response = client.post(
        "/login",
        data={"token": "dev-owner"},
        follow_redirects=False,
    )
    assert login_response.status_code == 303
    assert client.get("/").status_code == 200
