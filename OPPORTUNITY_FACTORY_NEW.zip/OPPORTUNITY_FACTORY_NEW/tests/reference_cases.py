from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReferenceCase:
    case_id: str
    name: str
    mode: str
    activity: str
    objective: str
    asset_context: str
    source_content: str
    claim_text: str
    expected_pathways: tuple[str, ...]
    expected_origin: str
    known_facts: tuple[str, ...]
    supplied_evidence: tuple[str, ...]
    assumptions: tuple[str, ...]
    unknowns: tuple[str, ...]


REFERENCE_CASES = (
    ReferenceCase(
        case_id="RC-01",
        name="Existing documented cross-market model",
        mode="M2O",
        activity="Community water service",
        objective="A proven model from another market can be adapted to local demand.",
        asset_context="",
        source_content="A documented service model is operating in another market and serves demand.",
        claim_text="The documented model is proven in its source market and may be adapted.",
        expected_pathways=("P2", "P4"),
        expected_origin="cross_market_model",
        known_facts=("A model is documented in another market.",),
        supplied_evidence=("Controlled reference source and linked claim.",),
        assumptions=("Transfer conditions are not yet established.",),
        unknowns=("Local payer, regulation, and operating economics.",),
    ),
    ReferenceCase(
        case_id="RC-02",
        name="Underexploited irrigation capacity",
        mode="M2O",
        activity="Irrigation service",
        objective="Idle irrigation capacity is available for productive use.",
        asset_context="Existing irrigation capacity",
        source_content="Measured idle capacity is available during the growing season.",
        claim_text="Idle capacity could support additional productive use.",
        expected_pathways=("P1",),
        expected_origin="resource_signal",
        known_facts=("Capacity is currently idle.",),
        supplied_evidence=("Measured capacity observation.",),
        assumptions=("The capacity can be accessed without displacing current users.",),
        unknowns=("Demand, price, and operating cost.",),
    ),
    ReferenceCase(
        case_id="RC-03",
        name="Unmet cold-storage demand",
        mode="M2O",
        activity="Food storage",
        objective="Farmers face unmet demand for affordable cold storage and a shortage of service.",
        asset_context="",
        source_content="A shortage of affordable cold storage leaves unmet demand after harvest.",
        claim_text="Demand exceeds available cold-storage service in the target geography.",
        expected_pathways=("P2",),
        expected_origin="problem_or_demand",
        known_facts=("A service shortage is documented.",),
        supplied_evidence=("Demand and supply gap observation.",),
        assumptions=("The demand is economically addressable.",),
        unknowns=("Payer identity and willingness to pay.",),
    ),
    ReferenceCase(
        case_id="RC-04",
        name="Packaging process leakage",
        mode="M2O",
        activity="Food packaging",
        objective="A packaging process has waste, bottlenecks, and value leakage.",
        asset_context="",
        source_content="The process records waste, delay, and value leakage at a bottleneck.",
        claim_text="Process inefficiency causes measurable material loss.",
        expected_pathways=("P3",),
        expected_origin="process_inefficiency",
        known_facts=("A process bottleneck is observed.",),
        supplied_evidence=("Operational loss observation.",),
        assumptions=("The measured loss is repeatable.",),
        unknowns=("Intervention cost and implementation constraints.",),
    ),
    ReferenceCase(
        case_id="RC-05",
        name="Complementary logistics combination",
        mode="M2O",
        activity="Regional logistics",
        objective="Combine complementary transport and storage capabilities into a joint service.",
        asset_context="",
        source_content="Separate capabilities are complementary and can connect into one service.",
        claim_text="A combination of capabilities could create additional value.",
        expected_pathways=("P5",),
        expected_origin="combination",
        known_facts=("Two complementary capabilities are available.",),
        supplied_evidence=("Capability descriptions and a linked claim.",),
        assumptions=("The participants can coordinate.",),
        unknowns=("Governance, pricing, and transaction costs.",),
    ),
    ReferenceCase(
        case_id="RC-06",
        name="Factory turnaround and alternative use",
        mode="A2V",
        activity="Industrial manufacturing",
        objective="Reconfigure a distressed factory for turnaround and alternative use.",
        asset_context="Distressed factory with existing production floor",
        source_content="The factory is distressed and has an existing production floor.",
        claim_text="Alternative use may recover value from the factory operation.",
        expected_pathways=("P6",),
        expected_origin="asset_operation",
        known_facts=("A physical factory and operation are in scope.",),
        supplied_evidence=("Asset condition and utilization observation.",),
        assumptions=("The asset can be legally and physically reconfigured.",),
        unknowns=("Capital requirement, safety, and market demand.",),
    ),
    ReferenceCase(
        case_id="RC-07",
        name="Multi-pathway cold-chain reconfiguration",
        mode="A2V",
        activity="Cold-chain operations",
        objective="Reconfigure an underused factory capacity, combine resources, and reduce process waste.",
        asset_context="Underused factory and cold-chain capacity",
        source_content="The factory has underused capacity, complementary resources, and process waste.",
        claim_text="Reconfiguration could combine capacity and reduce leakage.",
        expected_pathways=("P1", "P3", "P5", "P6"),
        expected_origin="resource_signal",
        known_facts=("Capacity, resources, and process loss are jointly documented.",),
        supplied_evidence=("Controlled multi-signal evidence package.",),
        assumptions=("The signals refer to the same economic system.",),
        unknowns=("Which pathway produces the strongest validated mechanism.",),
    ),
    ReferenceCase(
        case_id="RC-08",
        name="Neutral market description",
        mode="M2O",
        activity="Market statistics",
        objective="Map price movements and population by month.",
        asset_context="",
        source_content="Monthly price and population data are available.",
        claim_text="The dataset describes market conditions without an identified gap.",
        expected_pathways=(),
        expected_origin="",
        known_facts=("Descriptive data exists.",),
        supplied_evidence=("Controlled descriptive source.",),
        assumptions=("No opportunity signal is implied by the description.",),
        unknowns=("Whether later analysis identifies a signal.",),
    ),
    ReferenceCase(
        case_id="RC-09",
        name="Existing replicable model synonym case",
        mode="M2O",
        activity="Payment service",
        objective="A proven model is replicable in the target market.",
        asset_context="",
        source_content="The proven model has established users and a documented operating record.",
        claim_text="The model is replicable subject to local validation.",
        expected_pathways=("P4",),
        expected_origin="cross_market_model",
        known_facts=("An existing model has an operating record.",),
        supplied_evidence=("Documented reference case and linked claim.",),
        assumptions=("Replication requires local adaptation.",),
        unknowns=("Transferability, local regulation, and payer economics.",),
    ),
)
