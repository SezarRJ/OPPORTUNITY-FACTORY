from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


TOKEN_HEADERS = {"Authorization": "Bearer dev-owner"}


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    return TestClient(create_app(tmp_path / "economic.sqlite3"))


def _create_investigation(
    client: TestClient,
    *,
    mode: str = "M2O",
    objective: str = "Assess underused capacity, supply-demand gaps, process losses, and value recovery.",
    asset_context: str = "",
) -> int:
    response = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": "Structured economic reference case",
            "mode": mode,
            "country": "Controlled country",
            "geography": "Controlled region",
            "market": "Controlled market",
            "activity": "Controlled economic activity",
            "objective": objective,
            "asset_context": asset_context,
        },
    )
    assert response.status_code == 201
    return response.json()["id"]


def _add_evidence(client: TestClient, investigation_id: int) -> int:
    source = client.post(
        f"/api/investigations/{investigation_id}/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Controlled economic evidence",
            "source_type": "controlled-reference",
            "data_domain": "capacity, demand, flows, and costs",
            "last_updated": "2026-11-01",
            "reliability": 0.95,
            "independence_score": 0.95,
            "source_family": "structured-economic-case",
            "evidence_level": "E3",
            "content": (
                "Underused capacity, unmet demand, process waste, and value leakage "
                "are documented. Licensed and lawfully permitted. Viable mechanism. "
                "Identified payer and buyer identified. Resource access and critical "
                "resource available. Verified evidence. Capital available and funded. "
                "Safe and compliance confirmed."
            ),
        },
    )
    assert source.status_code == 201
    source_id = source.json()["id"]
    claim = client.post(
        f"/api/investigations/{investigation_id}/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": (
                "The controlled case has underused capacity, unmet demand, process "
                "waste, and a measurable value recovery mechanism."
            ),
            "source_id": source_id,
            "evidence_level": "E3",
            "confidence": 0.9,
        },
    )
    assert claim.status_code == 201
    return source_id


def _add_metric(
    client: TestClient,
    investigation_id: int,
    *,
    metric_type: str,
    name: str,
    value: float | None,
    unit: str,
    currency: str = "",
    status: str = "known",
    source_id: int | None = None,
) -> dict:
    response = client.post(
        f"/api/investigations/{investigation_id}/metrics",
        headers=TOKEN_HEADERS,
        json={
            "metric_type": metric_type,
            "name": name,
            "value": value,
            "unit": unit,
            "currency": currency,
            "status": status,
            "period_start": "2026-01-01",
            "period_end": "2026-12-31",
            "economic_activity": "Controlled economic activity",
            "source_id": source_id,
        },
    )
    assert response.status_code == 201
    return response.json()


def _calculation(result: dict, calculation_id: str) -> dict:
    return next(
        item
        for item in result["economic_model"]["calculations"]
        if item["id"] == calculation_id
    )


def test_structured_economic_model_calculates_and_replays(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    source_id = _add_evidence(client, investigation_id)

    first_entity = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={
            "entity_type": "producer",
            "name": "Controlled producer",
            "verification_status": "verified",
        },
    ).json()
    second_entity = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={
            "entity_type": "buyer",
            "name": "Controlled buyer",
            "verification_status": "verified",
        },
    ).json()
    relationship = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={
            "subject_entity_id": first_entity["id"],
            "object_entity_id": second_entity["id"],
            "relationship_type": "supplies",
            "direction": "producer-to-buyer",
            "flow_type": "material",
            "economic_activity": "Controlled economic activity",
            "quantity": 800,
            "quantity_unit": "kg",
            "quantity_status": "known",
            "value_amount": 1600,
            "currency": "USD",
            "value_status": "estimated",
            "time_period": "2026",
            "ownership_control": "producer owns; buyer purchases",
            "valid_from": "2026-01-01",
            "valid_to": "2026-12-31",
            "verification_status": "verified",
            "confidence": 0.9,
            "source_id": source_id,
        },
    )
    assert relationship.status_code == 201

    metrics = (
        ("production_capacity", "Production capacity", 100, "kg", ""),
        ("utilized_capacity", "Utilized capacity", 75, "kg", ""),
        ("demand", "Demand", 120, "kg", ""),
        ("supply", "Supply", 80, "kg", ""),
        ("input_quantity", "Input quantity", 1000, "kg", ""),
        ("output_quantity", "Output quantity", 800, "kg", ""),
        ("unit_value", "Value per unit", 2, "USD/kg", "USD"),
        ("revenue", "Revenue", 10000, "USD", "USD"),
        ("operating_cost", "Operating cost", 6000, "USD", "USD"),
        ("resource_available", "Resource available", 200, "hours", ""),
        ("resource_used", "Resource used", 150, "hours", ""),
        ("recoverable_quantity", "Recoverable quantity", 100, "kg", ""),
        ("recovery_value_per_unit", "Recovery value per unit", 1.5, "USD/kg", "USD"),
    )
    for metric_type, name, value, unit, currency in metrics:
        _add_metric(
            client,
            investigation_id,
            metric_type=metric_type,
            name=name,
            value=value,
            unit=unit,
            currency=currency,
            source_id=source_id,
        )

    response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    assert response.status_code == 200
    result = response.json()["result"]

    assert _calculation(result, "EC-001")["result"] == 0.75
    assert _calculation(result, "EC-002")["result"] == 40
    assert _calculation(result, "EC-003")["result"] == 1000
    assert _calculation(result, "EC-004")["result"] == 800
    assert _calculation(result, "EC-005")["result"] == 200
    assert _calculation(result, "EC-006")["result"] == 0.2
    assert _calculation(result, "EC-007")["result"] == 400
    assert _calculation(result, "EC-008")["result"] == 10000
    assert _calculation(result, "EC-009")["result"] == 6000
    assert _calculation(result, "EC-010")["result"] == 4000
    assert _calculation(result, "EC-011")["result"] == 0.4
    assert _calculation(result, "EC-012")["result"] == 0.75
    assert _calculation(result, "EC-013")["result"] == 150
    assert all(
        _calculation(result, calculation_id)["status"] == "calculated"
        for calculation_id in ("EC-001", "EC-002", "EC-005", "EC-007", "EC-010", "EC-013")
    )
    assert all(
        _calculation(result, calculation_id)["methodology_version"]
        for calculation_id in ("EC-001", "EC-007", "EC-010")
    )

    flow_validation = result["economic_model"]["flow_validation"]
    assert flow_validation["status"] == "mapped"
    assert flow_validation["verified_relationship_count"] == 1
    assert flow_validation["provenance_complete_count"] == 1
    assert flow_validation["relationships"][0]["ownership_control"]
    assert flow_validation["relationships"][0]["valid_from"] == "2026-01-01"

    assert result["opportunities"]
    quality = result["opportunities"][0]["quality"]
    assert quality["classification"] == "opportunity_hypothesis"
    assert quality["validation_state"] == "hypothesis"
    assert quality["commercial_feasibility"] == "not_assessed"
    assert quality["hard_gate_status"]["decision"]["status"] == "passed"

    bundle = client.get(
        f"/api/investigations/{investigation_id}",
        headers=TOKEN_HEADERS,
    ).json()
    assert len(bundle["metrics"]) == len(metrics)
    assert bundle["opportunities"][0]["quality"]["classification"] == "opportunity_hypothesis"
    assert {
        "relationship.created",
        "metric.created",
        "analysis.completed",
    } <= {event["event_type"] for event in bundle["audit_events"]}

    analysis_run_id = response.json()["analysis_run"]["id"]
    replay = client.post(
        f"/api/investigations/{investigation_id}/analysis/{analysis_run_id}/replay",
        headers=TOKEN_HEADERS,
    )
    assert replay.status_code == 200
    assert replay.json()["reproducible"] is True


def test_controlled_economic_reference_cases_cover_core_mechanisms(
    client: TestClient,
) -> None:
    reference_cases = (
        {
            "case_id": "RC-E01",
            "metrics": (
                ("production_capacity", "Capacity", 1000, "tons", ""),
                ("utilized_capacity", "Used capacity", 400, "tons", ""),
            ),
            "expected": ("EC-001", 0.4),
        },
        {
            "case_id": "RC-E02",
            "metrics": (
                ("supply", "Supply", 700, "units", ""),
                ("demand", "Demand", 1000, "units", ""),
            ),
            "expected": ("EC-002", 300),
        },
        {
            "case_id": "RC-E03",
            "metrics": (
                ("input_quantity", "Input", 1000, "kg", ""),
                ("output_quantity", "Output", 800, "kg", ""),
                ("unit_value", "Unit value", 2, "USD/kg", "USD"),
            ),
            "expected": ("EC-007", 400),
        },
        {
            "case_id": "RC-E04",
            "metrics": (
                ("resource_available", "Available asset capacity", 100, "hours", ""),
                ("resource_used", "Used asset capacity", 25, "hours", ""),
            ),
            "expected": ("EC-012", 0.25),
        },
        {
            "case_id": "RC-E05",
            "metrics": (
                ("input_quantity", "Process input", 500, "kg", ""),
                ("output_quantity", "Process output", 450, "kg", ""),
            ),
            "expected": ("EC-006", 0.1),
        },
        {
            "case_id": "RC-E06",
            "metrics": (
                ("revenue", "Sales revenue", 9000, "USD", "USD"),
                ("operating_cost", "Operating cost", 6500, "USD", "USD"),
            ),
            "expected": ("EC-010", 2500),
        },
        {
            "case_id": "RC-E07",
            "metrics": (
                ("recoverable_quantity", "Recoverable material", 60, "kg", ""),
                ("recovery_value_per_unit", "Recovery price", 3, "USD/kg", "USD"),
            ),
            "expected": ("EC-013", 180),
        },
    )
    for case in reference_cases:
        investigation_id = _create_investigation(
            client,
            objective=f"{case['case_id']} controlled economic mechanism.",
        )
        source_id = _add_evidence(client, investigation_id)
        for metric_type, name, value, unit, currency in case["metrics"]:
            _add_metric(
                client,
                investigation_id,
                metric_type=metric_type,
                name=name,
                value=value,
                unit=unit,
                currency=currency,
                source_id=source_id,
            )
        result = client.post(
            f"/api/investigations/{investigation_id}/analysis",
            headers=TOKEN_HEADERS,
        ).json()["result"]
        calculation_id, expected_value = case["expected"]
        calculation = _calculation(result, calculation_id)
        assert calculation["status"] == "calculated", case["case_id"]
        assert calculation["result"] == expected_value, case["case_id"]


def test_estimated_and_missing_values_are_explicitly_limited(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    source_id = _add_evidence(client, investigation_id)
    _add_metric(
        client,
        investigation_id,
        metric_type="production_capacity",
        name="Estimated capacity",
        value=100,
        unit="units",
        status="known",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="utilized_capacity",
        name="Estimated utilization",
        value=50,
        unit="units",
        status="estimated",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="revenue",
        name="Revenue not supplied",
        value=None,
        unit="USD",
        currency="USD",
        status="unknown",
        source_id=source_id,
    )
    response = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    )
    result = response.json()["result"]
    utilization = _calculation(result, "EC-001")
    assert utilization["status"] == "calculated"
    assert utilization["value_status"] == "estimated"
    assert utilization["input_status"] == "estimated"
    revenue = _calculation(result, "EC-008")
    assert revenue["status"] == "not_calculable"
    assert revenue["result"] is None
    assert "revenue" in " ".join(revenue["missing_inputs"])
    assert result["economic_model"]["summary"]["no_missing_values_invented"] is True

    rejected = client.post(
        f"/api/investigations/{investigation_id}/metrics",
        headers=TOKEN_HEADERS,
        json={
            "metric_type": "demand",
            "name": "Unknown demand with asserted value",
            "value": 10,
            "unit": "units",
            "status": "unknown",
        },
    )
    assert rejected.status_code == 400
    assert client.post(
        f"/api/investigations/{investigation_id}/metrics",
        json={
            "metric_type": "demand",
            "name": "Unauthorized demand",
            "value": 1,
            "unit": "units",
        },
    ).status_code == 401


def test_investigation_workspace_renders_structured_economic_sections(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    login = client.post("/login", data={"token": "dev-owner"}, follow_redirects=False)
    assert login.status_code == 303
    page = client.get(f"/investigations/{investigation_id}")
    assert page.status_code == 200
    assert "Add economic metric" in page.text
    assert "Quantity status" in page.text
    assert "Run deterministic analysis" in page.text


def test_incompatible_metric_periods_are_not_summed(client: TestClient) -> None:
    investigation_id = _create_investigation(client)
    source_id = _add_evidence(client, investigation_id)
    for period_start, period_end, value in (
        ("2025-01-01", "2025-12-31", 100),
        ("2026-01-01", "2026-12-31", 120),
    ):
        response = client.post(
            f"/api/investigations/{investigation_id}/metrics",
            headers=TOKEN_HEADERS,
            json={
                "metric_type": "production_capacity",
                "name": f"Capacity {period_start[:4]}",
                "value": value,
                "unit": "units",
                "status": "known",
                "period_start": period_start,
                "period_end": period_end,
                "source_id": source_id,
            },
        )
        assert response.status_code == 201
    _add_metric(
        client,
        investigation_id,
        metric_type="utilized_capacity",
        name="Current used capacity",
        value=50,
        unit="units",
        source_id=source_id,
    )
    result = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]
    utilization = _calculation(result, "EC-001")
    assert utilization["status"] == "not_calculable"
    assert "compatible period" in " ".join(utilization["missing_inputs"])


def test_multi_entity_combination_flow_preserves_distinct_relationships(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(
        client,
        objective="Combine underused resources and processing activity into a value-creating service.",
    )
    source_id = _add_evidence(client, investigation_id)
    resource = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "resource", "name": "Underused resource", "verification_status": "verified"},
    ).json()
    processor = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "activity", "name": "Processing activity", "verification_status": "verified"},
    ).json()
    buyer = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "buyer", "name": "Beneficiary buyer", "verification_status": "potential"},
    ).json()
    for relationship_payload in (
        {
            "subject_entity_id": resource["id"],
            "object_entity_id": processor["id"],
            "relationship_type": "supplies",
            "flow_type": "material",
            "economic_activity": "Processing activity",
            "quantity": 50,
            "quantity_unit": "tons",
            "quantity_status": "known",
            "time_period": "2026",
            "ownership_control": "resource access granted to processor",
            "verification_status": "verified",
            "source_id": source_id,
        },
        {
            "subject_entity_id": processor["id"],
            "object_entity_id": buyer["id"],
            "relationship_type": "sells",
            "flow_type": "financial",
            "economic_activity": "Processing activity",
            "value_amount": 12000,
            "currency": "USD",
            "value_status": "estimated",
            "time_period": "2026",
            "ownership_control": "buyer purchases processed output",
            "verification_status": "potential",
            "source_id": source_id,
        },
    ):
        response = client.post(
            f"/api/investigations/{investigation_id}/relationships",
            headers=TOKEN_HEADERS,
            json=relationship_payload,
        )
        assert response.status_code == 201

    result = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]
    flow_validation = result["economic_model"]["flow_validation"]
    assert flow_validation["relationship_count"] == 2
    assert flow_validation["structured_flow_count"] == 2
    assert flow_validation["verified_relationship_count"] == 1
    assert flow_validation["potential_relationship_count"] == 1
    assert flow_validation["provenance_complete_count"] == 2


def test_contribution_margin_and_per_unit_compatibility_are_explicit(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    source_id = _add_evidence(client, investigation_id)
    _add_metric(
        client,
        investigation_id,
        metric_type="revenue",
        name="Revenue",
        value=10000,
        unit="USD",
        currency="USD",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="variable_cost",
        name="Variable cost",
        value=4000,
        unit="USD",
        currency="USD",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="input_quantity",
        name="Input",
        value=100,
        unit="kg",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="output_quantity",
        name="Output",
        value=80,
        unit="kg",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="unit_value",
        name="Value per unit with incompatible denominator",
        value=3,
        unit="USD/ton",
        currency="USD",
        source_id=source_id,
    )

    result = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]

    contribution_margin = _calculation(result, "EC-014")
    assert contribution_margin["status"] == "calculated"
    assert contribution_margin["result"] == 6000
    assert _calculation(result, "EC-015")["result"] == 0.6
    leakage = _calculation(result, "EC-007")
    assert leakage["status"] == "not_calculable"
    assert "compatible quantity and value-per-unit units" in " ".join(
        leakage["missing_inputs"]
    )


def test_metric_patch_html_edit_and_audit_history(client: TestClient) -> None:
    investigation_id = _create_investigation(client)
    metric = _add_metric(
        client,
        investigation_id,
        metric_type="demand",
        name="Demand",
        value=100,
        unit="units",
    )

    patched = client.patch(
        f"/api/investigations/{investigation_id}/metrics/{metric['id']}",
        headers=TOKEN_HEADERS,
        json={"value": 125},
    )
    assert patched.status_code == 200
    assert patched.json()["value"] == 125

    login = client.post("/login", data={"token": "dev-owner"}, follow_redirects=False)
    assert login.status_code == 303
    html_update = client.post(
        f"/investigations/{investigation_id}/metrics/{metric['id']}",
        data={
            "metric_type": "demand",
            "name": "Edited demand",
            "value": "150",
            "unit": "units",
            "currency": "",
            "status": "estimated",
            "period_start": "2026-01-01",
            "period_end": "2026-12-31",
            "economic_activity": "Controlled economic activity",
            "source_id": "",
            "notes": "Edited through workspace",
        },
        follow_redirects=False,
    )
    assert html_update.status_code == 303

    bundle = client.get(
        f"/api/investigations/{investigation_id}",
        headers=TOKEN_HEADERS,
    ).json()
    edited_metric = next(
        item for item in bundle["metrics"] if item["id"] == metric["id"]
    )
    assert edited_metric["name"] == "Edited demand"
    assert edited_metric["value"] == 150
    assert edited_metric["status"] == "estimated"
    assert "metric.updated" in {event["event_type"] for event in bundle["audit_events"]}


def test_verified_metric_requires_source_and_is_distinguished_in_workspace(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    without_source = client.post(
        f"/api/investigations/{investigation_id}/metrics",
        headers=TOKEN_HEADERS,
        json={
            "metric_type": "demand",
            "name": "Unsupported verified demand",
            "value": 100,
            "unit": "units",
            "status": "known",
            "verification_status": "verified",
        },
    )
    assert without_source.status_code == 400

    source_id = _add_evidence(client, investigation_id)
    verified = client.post(
        f"/api/investigations/{investigation_id}/metrics",
        headers=TOKEN_HEADERS,
        json={
            "metric_type": "demand",
            "name": "Verified demand",
            "value": 100,
            "unit": "units",
            "status": "known",
            "verification_status": "verified",
            "source_id": source_id,
        },
    )
    assert verified.status_code == 201
    assert verified.json()["verification_status"] == "verified"

    login = client.post("/login", data={"token": "dev-owner"}, follow_redirects=False)
    assert login.status_code == 303
    page = client.get(f"/investigations/{investigation_id}")
    assert page.status_code == 200
    assert "Verified demand" in page.text
    assert "known · verified" in page.text


def test_invalid_relationship_and_metric_measurements_are_rejected(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    negative_metric = client.post(
        f"/api/investigations/{investigation_id}/metrics",
        headers=TOKEN_HEADERS,
        json={
            "metric_type": "demand",
            "name": "Negative demand",
            "value": -1,
            "unit": "units",
            "status": "known",
        },
    )
    assert negative_metric.status_code == 400

    first_entity = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "producer", "name": "Producer"},
    ).json()
    second_entity = client.post(
        f"/api/investigations/{investigation_id}/entities",
        headers=TOKEN_HEADERS,
        json={"entity_type": "buyer", "name": "Buyer"},
    ).json()
    base_relationship = {
        "subject_entity_id": first_entity["id"],
        "object_entity_id": second_entity["id"],
        "relationship_type": "supplies",
    }
    negative_relationship = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={**base_relationship, "quantity": -1, "quantity_status": "known"},
    )
    assert negative_relationship.status_code == 400
    asserted_unknown = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={**base_relationship, "quantity": 10, "quantity_status": "unknown"},
    )
    assert asserted_unknown.status_code == 400
    missing_known = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={**base_relationship, "quantity_status": "known"},
    )
    assert missing_known.status_code == 400
    unproven_verified = client.post(
        f"/api/investigations/{investigation_id}/relationships",
        headers=TOKEN_HEADERS,
        json={**base_relationship, "verification_status": "verified"},
    )
    assert unproven_verified.status_code == 400


def test_boundary_consistency_duplicate_conflict_currency_and_partial_period(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(client)
    source_id = _add_evidence(client, investigation_id)

    for value in (80, 80):
        _add_metric(
            client,
            investigation_id,
            metric_type="supply",
            name="Supply observation",
            value=value,
            unit="units",
            source_id=source_id,
        )
    _add_metric(
        client,
        investigation_id,
        metric_type="demand",
        name="Demand",
        value=100,
        unit="units",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="production_capacity",
        name="Zero capacity",
        value=0,
        unit="units",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="utilized_capacity",
        name="Used capacity",
        value=10,
        unit="units",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="revenue",
        name="Revenue USD",
        value=100,
        unit="USD",
        currency="USD",
        source_id=source_id,
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="revenue",
        name="Revenue EUR",
        value=100,
        unit="EUR",
        currency="EUR",
        source_id=source_id,
    )
    partial_period = client.post(
        f"/api/investigations/{investigation_id}/metrics",
        headers=TOKEN_HEADERS,
        json={
            "metric_type": "resource_available",
            "name": "Partial period availability",
            "value": 100,
            "unit": "hours",
            "status": "known",
            "period_start": "2026-01-01",
            "source_id": source_id,
        },
    )
    assert partial_period.status_code == 201
    _add_metric(
        client,
        investigation_id,
        metric_type="resource_used",
        name="Partial period usage",
        value=50,
        unit="hours",
        source_id=source_id,
    )

    result = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]
    gap = _calculation(result, "EC-002")
    supply = next(item for item in gap["inputs"] if item["metric_type"] == "supply")
    assert supply["value"] == 80
    assert gap["result"] == 20
    assert gap["observation_metadata"]["duplicate_observation_count"] == 1
    utilization = _calculation(result, "EC-001")
    assert utilization["status"] == "not_calculable"
    assert "non-zero denominator" in " ".join(utilization["missing_inputs"])
    revenue = _calculation(result, "EC-008")
    assert revenue["status"] == "not_calculable"
    assert "compatible currency" in " ".join(revenue["missing_inputs"])
    resource_utilization = _calculation(result, "EC-012")
    assert resource_utilization["status"] == "not_calculable"
    assert "complete period" in " ".join(resource_utilization["missing_inputs"])

    conflict_client = TestClient(create_app(client.app.state.database_path))
    conflict_investigation = _create_investigation(conflict_client)
    conflict_source = _add_evidence(conflict_client, conflict_investigation)
    for value in (80, 90):
        _add_metric(
            conflict_client,
            conflict_investigation,
            metric_type="supply",
            name="Conflicting supply",
            value=value,
            unit="units",
            source_id=conflict_source,
        )
    _add_metric(
        conflict_client,
        conflict_investigation,
        metric_type="demand",
        name="Conflicting demand",
        value=100,
        unit="units",
        source_id=conflict_source,
    )
    conflict_result = conflict_client.post(
        f"/api/investigations/{conflict_investigation}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]
    conflict_calculation = _calculation(conflict_result, "EC-002")
    assert conflict_calculation["status"] == "not_calculable"
    assert "conflicting observations" in " ".join(
        conflict_calculation["missing_inputs"]
    )


def test_historical_replay_uses_original_snapshot_after_edit_and_restart(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "replay-after-edit.sqlite3"
    client = TestClient(create_app(database_path))
    investigation_id = _create_investigation(client)
    _add_metric(
        client,
        investigation_id,
        metric_type="production_capacity",
        name="Capacity",
        value=100,
        unit="units",
    )
    _add_metric(
        client,
        investigation_id,
        metric_type="utilized_capacity",
        name="Utilized",
        value=50,
        unit="units",
    )
    first_run = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()
    first_run_id = first_run["analysis_run"]["id"]
    assert _calculation(first_run["result"], "EC-001")["result"] == 0.5

    metric_id = next(
        item["id"]
        for item in client.get(
            f"/api/investigations/{investigation_id}",
            headers=TOKEN_HEADERS,
        ).json()["metrics"]
        if item["metric_type"] == "utilized_capacity"
    )
    updated = client.patch(
        f"/api/investigations/{investigation_id}/metrics/{metric_id}",
        headers=TOKEN_HEADERS,
        json={"value": 80},
    )
    assert updated.status_code == 200
    second_run = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()
    assert _calculation(second_run["result"], "EC-001")["result"] == 0.8

    restarted = TestClient(create_app(database_path))
    replay = restarted.post(
        f"/api/investigations/{investigation_id}/analysis/{first_run_id}/replay",
        headers=TOKEN_HEADERS,
    )
    assert replay.status_code == 200
    assert replay.json()["reproducible"] is True
    assert _calculation(replay.json()["replayed_result"], "EC-001")["result"] == 0.5


def test_opportunity_lifecycle_states_are_explicit(client: TestClient) -> None:
    investigation_id = _create_investigation(client)
    _add_evidence(client, investigation_id)
    result = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]

    summary = result["opportunity_state_summary"]
    assert set(summary["definitions"]) == {
        "economic_signal",
        "opportunity_hypothesis",
        "opportunity_under_investigation",
        "validated_opportunity",
        "commercial_feasibility_established",
    }
    assert summary["counts"]["economic_signal"] > 0
    assert summary["counts"]["opportunity_hypothesis"] == len(
        result["opportunities"]
    )
    assert summary["counts"]["opportunity_under_investigation"] == 0
    assert summary["counts"]["validated_opportunity"] == 0
    assert summary["counts"]["commercial_feasibility_established"] == 0
    assert all(
        opportunity["quality"]["lifecycle_state"] == "opportunity_hypothesis"
        for opportunity in result["opportunities"]
    )


def test_insufficient_evidence_realistic_case_remains_unvalidated(
    client: TestClient,
) -> None:
    investigation_id = _create_investigation(
        client,
        objective=(
            "Farmers report unmet demand for cold storage, but no source package "
            "or claim evidence is available."
        ),
    )
    result = client.post(
        f"/api/investigations/{investigation_id}/analysis",
        headers=TOKEN_HEADERS,
    ).json()["result"]
    assert result["status"] == "insufficient-evidence"
    assert result["opportunities"] == []
    assert result["opportunity_state_summary"]["counts"]["economic_signal"] > 0
