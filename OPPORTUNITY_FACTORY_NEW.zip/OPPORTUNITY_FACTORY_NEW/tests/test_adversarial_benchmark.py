from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


TOKEN_HEADERS = {"Authorization": "Bearer dev-owner"}

BenchmarkCategory = Literal[
    "unseen_phrasing",
    "multilingual_variation",
    "negation_ambiguity",
    "compositional_understanding",
    "negative_controls",
]


@dataclass(frozen=True)
class AdversarialCase:
    case_id: str
    category: BenchmarkCategory
    name: str
    source_content: str
    expected_pathways: tuple[str, ...]
    expected_concept: str | None
    expected_reasoning_elements: tuple[str, ...] = ()
    mode: str = "M2O"
    asset_context: str = ""
    description: str = ""


# A. UNSEEN PHRASING
UNSEEN_PHRASING_CASES = (
    AdversarialCase(
        case_id="ADV-UP-01",
        category="unseen_phrasing",
        name="Capacity idle - informal phrasing",
        source_content="The plant has been sitting half-empty for months now.",
        expected_pathways=('P1',),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('informal_phrasing', 'capacity_idle', 'P1_resource_signal'),
        description="Informal phrasing half-empty not in current aliases",
    ),
    AdversarialCase(
        case_id="ADV-UP-02",
        category="unseen_phrasing",
        name="Demand exceeding supply - technical description",
        source_content="Quantitative analysis reveals a persistent supply-demand disequilibrium with demand outpacing available supply by approximately 40%.",
        expected_pathways=('P2',),
        expected_concept="unmet_demand",
        expected_reasoning_elements=('technical_terminology', 'supply_demand_disequilibrium', 'P2_problem_demand'),
        description="Technical supply-demand disequilibrium phrasing not in aliases",
    ),
    AdversarialCase(
        case_id="ADV-UP-03",
        category="unseen_phrasing",
        name="Process waste - manufacturing jargon",
        source_content="Our OEE metrics show significant availability losses and quality losses in the finishing line.",
        expected_pathways=('P3',),
        expected_concept="process_loss",
        expected_reasoning_elements=('manufacturing_jargon', 'OEE_metrics', 'availability_losses', 'P3_process_inefficiency'),
        description="OEE/manufacturing terminology not in current aliases",
    ),
    AdversarialCase(
        case_id="ADV-UP-04",
        category="unseen_phrasing",
        name="Cross-market replication - business development speak",
        source_content="We have identified a proven SaaS playbook in LATAM that is ripe for porting to our MENA operations.",
        expected_pathways=('P4',),
        expected_concept="cross_market_replication",
        expected_reasoning_elements=('business_dev_speak', 'playbook', 'porting', 'P4_cross_market_model'),
        description="SaaS/playbook/porting terminology not in aliases",
    ),
    AdversarialCase(
        case_id="ADV-UP-05",
        category="unseen_phrasing",
        name="Combination - partnership language",
        source_content="Strategic alignment between our logistics network and their warehousing footprint creates a compelling JV thesis.",
        expected_pathways=('P5',),
        expected_concept="combination",
        expected_reasoning_elements=('partnership_language', 'JV_thesis', 'strategic_alignment', 'P5_combination'),
        description="JV thesis/strategic alignment language not in aliases",
    ),
    AdversarialCase(
        case_id="ADV-UP-06",
        category="unseen_phrasing",
        name="Asset reconfiguration - real estate terminology",
        source_content="The brownfield site offers adaptive reuse potential for last-mile logistics given its zoning and ceiling height.",
        expected_pathways=('P6',),
        expected_concept="asset_reconfiguration",
        expected_reasoning_elements=('real_estate_terminology', 'brownfield', 'adaptive_reuse', 'P6_asset_operation'),
        description="Brownfield/adaptive reuse/last-mile terminology not in aliases",
    ),
    AdversarialCase(
        case_id="ADV-UP-07",
        category="unseen_phrasing",
        name="Multiple mechanisms in long description",
        source_content="The facility has significant unused production capacity while downstream customers report consistent shortages, and the current process wastes approximately 15% of input material at the conversion stage.",
        expected_pathways=('P1', 'P2', 'P3'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('multiple_mechanisms', 'capacity_unused', 'shortages_reported', 'process_waste_15_percent', 'P1_P2_P3_compositional'),
        description="Long description containing multiple economic mechanisms",
    ),
)


# B. MULTILINGUAL VARIATION
MULTILINGUAL_CASES = (
    AdversarialCase(
        case_id="ADV-ML-01",
        category="multilingual_variation",
        name="Arabic dialect - Levantine capacity idle",
        source_content="المصنع شغال بنص طاقتهو، والباقي معطل",
        expected_pathways=('P1',),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('arabic_dialect_levantine', 'informal_arabic', 'P1_resource_signal'),
        description="Levantine Arabic dialect not in current formal Arabic aliases",
    ),
    AdversarialCase(
        case_id="ADV-ML-02",
        category="multilingual_variation",
        name="Arabic dialect - Gulf unmet demand",
        source_content="الناس طالبة الخدمة وما في حد يوفرها، الطلب قوي والعرض معدوم",
        expected_pathways=('P2',),
        expected_concept="unmet_demand",
        expected_reasoning_elements=('arabic_dialect_gulf', 'strong_demand_no_supply', 'P2_problem_demand'),
        description="Gulf Arabic dialect with colloquial phrasing",
    ),
    AdversarialCase(
        case_id="ADV-ML-03",
        category="multilingual_variation",
        name="Formal Arabic - process loss",
        source_content="تشير التقارير الفنية إلى وجود هدر كبير في مراحل التحويل التصنيعي",
        expected_pathways=('P3',),
        expected_concept="process_loss",
        expected_reasoning_elements=('formal_arabic', 'technical_reports', 'manufacturing_conversion', 'P3_process_inefficiency'),
        description="Formal Arabic technical terminology",
    ),
    AdversarialCase(
        case_id="ADV-ML-04",
        category="multilingual_variation",
        name="English - British business terminology",
        source_content="The plant is running at sub-optimal utilisation with considerable headroom for additional throughput.",
        expected_pathways=('P1',),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('british_english', 'sub_optimal_utilisation', 'headroom', 'throughput', 'P1_resource_signal'),
        description="British English utilisation/headroom/throughput not in US English aliases",
    ),
    AdversarialCase(
        case_id="ADV-ML-05",
        category="multilingual_variation",
        name="English - Technical economic language",
        source_content="A persistent deadweight loss exists due to allocative inefficiency in the regional cold-chain market.",
        expected_pathways=('P2', 'P3'),
        expected_concept="unmet_demand",
        expected_reasoning_elements=('technical_economic', 'deadweight_loss', 'allocative_inefficiency', 'P2_P3'),
        description="Academic economic terminology",
    ),
    AdversarialCase(
        case_id="ADV-ML-06",
        category="multilingual_variation",
        name="Spanish - Latin American business",
        source_content="La planta opera con capacidad ociosa significativa y hay demanda insatisfecha en el mercado local.",
        expected_pathways=('P1', 'P2'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('spanish_latam', 'capacidad_ociosa', 'demanda_insatisfecha', 'P1_P2'),
        description="Latin American Spanish business terminology",
    ),
    AdversarialCase(
        case_id="ADV-ML-07",
        category="multilingual_variation",
        name="Spanish - European technical",
        source_content="Existe una fuga de valor en la cadena de transformacion con perdidas de rendimiento del 18%.",
        expected_pathways=('P3',),
        expected_concept="process_loss",
        expected_reasoning_elements=('spanish_european', 'fuga_valor', 'perdidas_rendimiento', 'P3_process_inefficiency'),
        description="European Spanish technical terminology",
    ),
    AdversarialCase(
        case_id="ADV-ML-08",
        category="multilingual_variation",
        name="Mixed language - Arabic/English code-switching",
        source_content="The مصنع has قدرة غير مستغلة and we can replicate the نموذج الناجح from Saudi.",
        expected_pathways=('P1', 'P4'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('mixed_language', 'code_switching', 'arabic_english', 'P1_P4'),
        description="Arabic/English code-switching common in MENA business contexts",
    ),
    AdversarialCase(
        case_id="ADV-ML-09",
        category="multilingual_variation",
        name="Mixed language - Spanish/English Spanglish",
        source_content="Tenemos capacity ociosa en la planta y un proven model we can replicate.",
        expected_pathways=('P1', 'P4'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('spanglish', 'mixed_language', 'capacity_ociosa', 'proven_model', 'P1_P4'),
        description="Spanish/English code-switching",
    ),
    AdversarialCase(
        case_id="ADV-ML-10",
        category="multilingual_variation",
        name="Different expression - same concept (capacity)",
        source_content="The asset base is significantly underleveraged with substantial latent capacity.",
        expected_pathways=('P1',),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('different_expression', 'underleveraged', 'latent_capacity', 'P1_resource_signal'),
        description="Financial/strategic terminology underleveraged/latent not in aliases",
    ),
)


# C. NEGATION AND AMBIGUITY
NEGATION_AMBIGUITY_CASES = (
    AdversarialCase(
        case_id="ADV-NA-01",
        category="negation_ambiguity",
        name="Explicit negation of capacity availability",
        source_content="The facility has NO idle capacity; all production lines are running at maximum.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('explicit_negation', 'no_idle_capacity', 'max_utilization', 'correctly_rejected'),
        description="Should NOT trigger P1 - explicit negation",
    ),
    AdversarialCase(
        case_id="ADV-NA-02",
        category="negation_ambiguity",
        name="Explicit negation of unmet demand",
        source_content="There is no unmet demand in this market; supply fully meets all customer requirements.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('explicit_negation', 'no_unmet_demand', 'supply_meets_demand', 'correctly_rejected'),
        description="Should NOT trigger P2 - explicit negation",
    ),
    AdversarialCase(
        case_id="ADV-NA-03",
        category="negation_ambiguity",
        name="Hypothetical versus actual",
        source_content="If the plant were operating below capacity, we could utilize the excess for new products.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('hypothetical', 'conditional_if', 'not_actual_state', 'correctly_rejected'),
        description="Hypothetical/conditional - should not trigger pathway",
    ),
    AdversarialCase(
        case_id="ADV-NA-04",
        category="negation_ambiguity",
        name="Question versus established fact",
        source_content="Is there unmet demand for cold storage in this region? We need to investigate.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('question_format', 'investigation_needed', 'not_established_fact', 'correctly_rejected'),
        description="Question format - should not trigger pathway",
    ),
    AdversarialCase(
        case_id="ADV-NA-05",
        category="negation_ambiguity",
        name="Ambiguous relationship - similar words different mechanism",
        source_content="The company has excess inventory that is not moving, but this is not due to production capacity issues.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('ambiguous', 'excess_inventory_not_capacity', 'different_mechanism', 'correctly_rejected'),
        description="Excess inventory != underutilized capacity - different economic mechanism",
    ),
    AdversarialCase(
        case_id="ADV-NA-06",
        category="negation_ambiguity",
        name="Negation with complex sentence structure",
        source_content="Despite initial reports, our analysis confirms the facility does not operate below its design capacity.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('complex_negation', 'despite_initial_reports', 'confirms_not', 'correctly_rejected'),
        description="Complex negation with despite/confirms not structure",
    ),
    AdversarialCase(
        case_id="ADV-NA-07",
        category="negation_ambiguity",
        name="Partial negation - some capacity but not relevant",
        source_content="The plant has some unused space, but it cannot be used for production due to contamination.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('partial_negation', 'unused_space_not_production', 'contamination_constraint', 'correctly_rejected'),
        description="Unused space but not usable for production - economically invalid",
    ),
    AdversarialCase(
        case_id="ADV-NA-08",
        category="negation_ambiguity",
        name="Double negative confusion",
        source_content="It is not true that there is no unmet demand; customers are actively seeking alternatives.",
        expected_pathways=('P2',),
        expected_concept="unmet_demand",
        expected_reasoning_elements=('double_negative', 'not_true_no_unmet_demand', 'customers_seeking', 'P2_problem_demand'),
        description="Double negative resolving to positive unmet demand",
    ),
)


# D. COMPOSITIONAL UNDERSTANDING
COMPOSITIONAL_CASES = (
    AdversarialCase(
        case_id="ADV-CO-01",
        category="compositional_understanding",
        name="Multi-stage value chain - byproduct to input",
        source_content="The food processing plant generates organic waste that a nearby biofuel facility could use as feedstock, while the biofuel facility CO2 output could serve the plant greenhouse operations.",
        expected_pathways=('P1', 'P3', 'P5'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('multi_stage_value_chain', 'byproduct_to_input', 'circular_economy', 'food_processing_to_biofuel_to_greenhouse', 'P1_P3_P5_compositional'),
        description="By-products connected to another industry inputs - circular economy",
    ),
    AdversarialCase(
        case_id="ADV-CO-02",
        category="compositional_understanding",
        name="Multiple actors - supplier, processor, distributor",
        source_content="Local farmers have surplus produce but no cold storage. A logistics company has trucks but empty return trips. A retailer needs consistent supply. Connecting all three creates a viable cold chain.",
        expected_pathways=('P1', 'P2', 'P5'),
        expected_concept="missing_economic_link",
        expected_reasoning_elements=('multiple_actors', 'farmers_surplus', 'logistics_empty_returns', 'retailer_consistent_supply', 'three_way_combination', 'P1_P2_P5_compositional'),
        description="Multiple actors and activities requiring combination",
    ),
    AdversarialCase(
        case_id="ADV-CO-03",
        category="compositional_understanding",
        name="Input becomes output of another activity",
        source_content="The steel mill slag output serves as the cement plant primary supplementary cementitious material, reducing the cement plant clinker factor and the mill disposal costs.",
        expected_pathways=('P1', 'P3', 'P5'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('input_output_chain', 'steel_slag_to_cement', 'clinker_factor_reduction', 'disposal_cost_reduction', 'industrial_symbiosis', 'P1_P3_P5_compositional'),
        description="Industrial symbiosis - output of one becomes input of another",
    ),
    AdversarialCase(
        case_id="ADV-CO-04",
        category="compositional_understanding",
        name="Economic mechanism requiring multiple relationships",
        source_content="The port has unused berth capacity. Shippers face delays at the competing port. A rail connection exists but is underused. A single operator could integrate berth, rail, and logistics to capture the delay cost savings.",
        expected_pathways=('P1', 'P2', 'P3', 'P5'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('multiple_relationships_required', 'port_berth_unused', 'shipper_delays_competing_port', 'rail_underused', 'integrated_operator', 'delay_cost_savings', 'P1_P2_P3_P5_compositional'),
        description="Requires identifying berth capacity + shipper delays + rail + integration",
    ),
    AdversarialCase(
        case_id="ADV-CO-05",
        category="compositional_understanding",
        name="Multi-actor with competing interests",
        source_content="Two adjacent factories: one vents waste heat, the other burns gas for process heat. A heat exchange agreement would benefit both but requires capital investment and long-term contract alignment.",
        expected_pathways=('P1', 'P3', 'P5'),
        expected_concept="underutilized_capacity",
        expected_reasoning_elements=('competing_interests', 'waste_heat_venting', 'gas_burning_for_heat', 'heat_exchange_agreement', 'capital_and_contract_requirements', 'P1_P3_P5_compositional'),
        description="Mutually beneficial but requires contract/capital alignment",
    ),
)


# E. NEGATIVE CONTROLS
NEGATIVE_CONTROL_CASES = (
    AdversarialCase(
        case_id="ADV-NC-01",
        category="negative_controls",
        name="Opportunity vocabulary but no economic mechanism",
        source_content="The team identified significant capacity, demand, and opportunity in the market. Stakeholders are excited about the potential. We see huge potential for growth and value creation.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('vocabulary_only', 'no_specific_mechanism', 'generic_excitement', 'no_concrete_evidence', 'correctly_rejected'),
        description="Uses opportunity words but no specific economic mechanism",
    ),
    AdversarialCase(
        case_id="ADV-NC-02",
        category="negative_controls",
        name="Missing critical information - no payer",
        source_content="There is massive unmet demand for specialized medical services in the region. The capacity exists at the hospital. The need is urgent.",
        expected_pathways=('P2',),
        expected_concept="unmet_demand",
        expected_reasoning_elements=('missing_critical_info', 'unmet_demand_identified', 'no_payer_identified', 'hard_gate_HG3_at_risk', 'P2_but_incomplete'),
        description="Demand signal present but no payer - HG-3 at risk",
    ),
    AdversarialCase(
        case_id="ADV-NC-03",
        category="negative_controls",
        name="Contradictory claims within same text",
        source_content="The plant has significant idle capacity and is running at full utilization. Demand exceeds supply but there are no customers.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('contradictory_claims', 'idle_capacity_vs_full_utilization', 'demand_exceeds_supply_vs_no_customers', 'internally_inconsistent', 'correctly_rejected'),
        description="Direct contradictions within same description",
    ),
    AdversarialCase(
        case_id="ADV-NC-04",
        category="negative_controls",
        name="Attractive but economically invalid - no value creation",
        source_content="We can buy the distressed factory cheaply and sell the land for a profit. The equipment has no buyers but the real estate is valuable.",
        expected_pathways=('P6',),
        expected_concept="asset_reconfiguration",
        expected_reasoning_elements=('economically_invalid_as_value_creation', 'land_flip_not_operational_value', 'equipment_no_buyers', 'real_estate_arbitrage', 'P6_but_not_value_creating'),
        description="Real estate arbitrage, not operational value creation",
    ),
    AdversarialCase(
        case_id="ADV-NC-05",
        category="negative_controls",
        name="Descriptive statistics only - no gap",
        source_content="Monthly production data shows 10,000 units average with standard deviation of 500. Capacity is 12,000 units. Utilization averages 83%.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('descriptive_only', 'no_economic_gap_identified', 'utilization_83_percent_normal', 'statistics_without_interpretation', 'correctly_rejected'),
        description="Pure descriptive statistics without identified economic gap",
    ),
    AdversarialCase(
        case_id="ADV-NC-06",
        category="negative_controls",
        name="Future projection without current evidence",
        source_content="Next year we expect demand to exceed supply significantly. The new regulations will create opportunities. Market growth projections are very positive.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('future_projection_only', 'no_current_evidence', 'regulatory_speculation', 'growth_projections_not_evidence', 'correctly_rejected'),
        description="Future projections without current registered evidence",
    ),
    AdversarialCase(
        case_id="ADV-NC-07",
        category="negative_controls",
        name="Vague opportunity language with no specifics",
        source_content="There are opportunities in the market. We should explore partnerships and look for synergies. The potential is enormous.",
        expected_pathways=(),
        expected_concept=None,
        expected_reasoning_elements=('vague_language_only', 'no_specifics', 'generic_synergy_partnership', 'enormous_potential_unsubstantiated', 'correctly_rejected'),
        description="Completely vague with no actionable economic mechanism",
    ),
)


ALL_ADVERSARIAL_CASES = (
    UNSEEN_PHRASING_CASES +
    MULTILINGUAL_CASES +
    NEGATION_AMBIGUITY_CASES +
    COMPOSITIONAL_CASES +
    NEGATIVE_CONTROL_CASES
)


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    return TestClient(create_app(tmp_path / "adversarial.sqlite3"))


def _run_adversarial_case(client: TestClient, case: AdversarialCase) -> dict:
    investigation = client.post(
        "/api/investigations",
        headers=TOKEN_HEADERS,
        json={
            "title": case.case_id + " " + case.name,
            "mode": case.mode,
            "country": "Adversarial Benchmark Country",
            "geography": "Adversarial Geography",
            "market": "Adversarial Market",
            "activity": "Adversarial Activity",
            "objective": case.description or "Adversarial benchmark evaluation",
            "asset_context": case.asset_context,
        },
    )
    investigation_id = investigation.json()["id"]

    source = client.post(
        "/api/investigations/" + str(investigation_id) + "/sources",
        headers=TOKEN_HEADERS,
        json={
            "title": "Adversarial Source " + case.case_id,
            "source_type": "adversarial-benchmark",
            "evidence_level": "E2",
            "content": case.source_content,
        },
    )
    source_id = source.json()["id"]

    client.post(
        "/api/investigations/" + str(investigation_id) + "/claims",
        headers=TOKEN_HEADERS,
        json={
            "text": case.source_content,
            "source_id": source_id,
            "evidence_level": "E2",
        },
    )

    analysis = client.post(
        "/api/investigations/" + str(investigation_id) + "/analysis",
        headers=TOKEN_HEADERS,
    )
    return analysis.json()["result"]


# -----------------------------------------------------------------------------
# Generalization Measurement
# -----------------------------------------------------------------------------

class GeneralizationMetrics:
    def __init__(self):
        self.total = 0
        self.correct_pathway_identification = 0
        self.missed_opportunities = 0
        self.false_pathway_activations = 0
        self.incorrect_semantic_equivalence = 0
        self.incorrect_multilingual_normalization = 0
        self.negation_errors = 0
        self.unsupported_economic_conclusions = 0
        self.correctly_insufficient_info = 0
        self.by_category = {}

    def record_result(self, case: AdversarialCase, result: dict):
        self.total += 1
        cat = case.category
        if cat not in self.by_category:
            self.by_category[cat] = {
                "total": 0, "correct": 0, "missed": 0, "false_positive": 0
            }
        self.by_category[cat]["total"] += 1

        indicated = {
            p["id"] for p in result["pathway_evaluations"] if p["indicated"]
        }
        expected = set(case.expected_pathways)

        if indicated == expected:
            self.correct_pathway_identification += 1
            self.by_category[cat]["correct"] += 1
        else:
            missed = expected - indicated
            if missed:
                self.missed_opportunities += len(missed)
                self.by_category[cat]["missed"] += len(missed)
            false_pos = indicated - expected
            if false_pos:
                self.false_pathway_activations += len(false_pos)
                self.by_category[cat]["false_positive"] += len(false_pos)

        if not case.expected_pathways and indicated:
            self.negation_errors += len(indicated)
        opportunities = result.get("opportunities", [])
        if opportunities and not case.expected_pathways:
            self.unsupported_economic_conclusions += len(opportunities)
        if not case.expected_pathways and result.get("status") in (
            "no-supported-pathway", "insufficient-evidence", "blocked-by-hard-gates"
        ):
            self.correctly_insufficient_info += 1

    def report(self) -> dict:
        return {
            "total_cases": self.total,
            "correct_pathway_identification": self.correct_pathway_identification,
            "missed_opportunities": self.missed_opportunities,
            "false_pathway_activations": self.false_pathway_activations,
            "incorrect_semantic_equivalence": self.incorrect_semantic_equivalence,
            "incorrect_multilingual_normalization": self.incorrect_multilingual_normalization,
            "negation_errors": self.negation_errors,
            "unsupported_economic_conclusions": self.unsupported_economic_conclusions,
            "correctly_insufficient_information": self.correctly_insufficient_info,
            "by_category": self.by_category,
            "accuracy": (
                self.correct_pathway_identification / self.total 
                if self.total > 0 else 0
            ),
        }

metrics = GeneralizationMetrics()


# -----------------------------------------------------------------------------
# Parameterized Tests by Category
# -----------------------------------------------------------------------------

@pytest.mark.parametrize("case", UNSEEN_PHRASING_CASES, ids=lambda c: c.case_id)
def test_unseen_phrasing(client: TestClient, case: AdversarialCase) -> None:
    result = _run_adversarial_case(client, case)
    metrics.record_result(case, result)

    indicated = {
        p["id"] for p in result["pathway_evaluations"] if p["indicated"]
    }
    expected = set(case.expected_pathways)

    assert indicated == expected, (
        f"{case.case_id}: Expected {expected}, got {indicated}. "
        f"Source: {case.source_content[:100]}..."
    )

    if case.expected_pathways:
        assert result.get("opportunities"), (
            f"{case.case_id}: Expected opportunities for {case.expected_pathways}"
        )
        for opp in result["opportunities"]:
            assert "discovery_reasoning" in opp
            assert "semantic_concepts" in opp
            assert "economic_mechanism" in opp


@pytest.mark.parametrize("case", MULTILINGUAL_CASES, ids=lambda c: c.case_id)
def test_multilingual_variation(client: TestClient, case: AdversarialCase) -> None:
    result = _run_adversarial_case(client, case)
    metrics.record_result(case, result)

    indicated = {
        p["id"] for p in result["pathway_evaluations"] if p["indicated"]
    }
    expected = set(case.expected_pathways)

    assert indicated == expected, (
        f"{case.case_id}: Expected {expected}, got {indicated}. "
        f"Source: {case.source_content[:100]}..."
    )


@pytest.mark.parametrize("case", NEGATION_AMBIGUITY_CASES, ids=lambda c: c.case_id)
def test_negation_ambiguity(client: TestClient, case: AdversarialCase) -> None:
    result = _run_adversarial_case(client, case)
    metrics.record_result(case, result)

    indicated = {
        p["id"] for p in result["pathway_evaluations"] if p["indicated"]
    }
    expected = set(case.expected_pathways)

    assert indicated == expected, (
        f"{case.case_id}: Expected {expected}, got {indicated}. "
        f"Source: {case.source_content[:100]}... "
        f"Reason: {case.description}"
    )

    if not case.expected_pathways:
        assert result.get("status") in (
            "no-supported-pathway", "insufficient-evidence", "blocked-by-hard-gates"
        ), f"{case.case_id}: Should be rejected but got {result.get("status")}"


@pytest.mark.parametrize("case", COMPOSITIONAL_CASES, ids=lambda c: c.case_id)
def test_compositional_understanding(client: TestClient, case: AdversarialCase) -> None:
    result = _run_adversarial_case(client, case)
    metrics.record_result(case, result)

    indicated = {
        p["id"] for p in result["pathway_evaluations"] if p["indicated"]
    }
    expected = set(case.expected_pathways)

    primary_expected = {case.expected_pathways[0]} if case.expected_pathways else set()
    assert indicated >= primary_expected, (
        f"{case.case_id}: Missing primary pathway {primary_expected}. "
        f"Got {indicated}, expected at least {primary_expected}. "
        f"Source: {case.source_content[:100]}..."
    )

    if len(case.expected_pathways) > 1:
        assert len(indicated) >= 2, (
            f"{case.case_id}: Expected multi-pathway detection, got {indicated}"
        )


@pytest.mark.parametrize("case", NEGATIVE_CONTROL_CASES, ids=lambda c: c.case_id)
def test_negative_controls(client: TestClient, case: AdversarialCase) -> None:
    result = _run_adversarial_case(client, case)
    metrics.record_result(case, result)

    indicated = {
        p["id"] for p in result["pathway_evaluations"] if p["indicated"]
    }
    expected = set(case.expected_pathways)

    assert indicated == expected, (
        f"{case.case_id}: Expected {expected}, got {indicated}. "
        f"Source: {case.source_content[:100]}... "
        f"Reason: {case.description}"
    )

    if not case.expected_pathways:
        assert result.get("opportunities") == [], (
            f"{case.case_id}: Negative control created opportunities: "
            f"{result.get("opportunities")}"
        )


# -----------------------------------------------------------------------------
# Summary Report Test
# -----------------------------------------------------------------------------

def test_adversarial_benchmark_summary(client: TestClient) -> None:
    report = metrics.report()

    print("\n" + "=" * 80)
    print("ADVERSARIAL BENCHMARK - GENERALIZATION REPORT")
    print("=" * 80)
    print(f"Total Cases: {report["total_cases"]}")
    print(f"Correct Pathway Identification: {report["correct_pathway_identification"]}")
    print(f"Missed Opportunities: {report["missed_opportunities"]}")
    print(f"False Pathway Activations: {report["false_pathway_activations"]}")
    print(f"Negation Errors: {report["negation_errors"]}")
    print(f"Unsupported Economic Conclusions: {report["unsupported_economic_conclusions"]}")
    print(f"Correctly Insufficient Information: {report["correctly_insufficient_information"]}")
    print(f"Overall Accuracy: {report["accuracy"]:.2%}")
    print("\nBy Category:")
    for cat, data in report["by_category"].items():
        print(f"  {cat}:")
        print(f"    Total: {data["total"]}, Correct: {data["correct"]}, "
              f"Missed: {data["missed"]}, False Positive: {data["false_positive"]}")
    print("=" * 80)

    assert report["accuracy"] >= 0.70, (
        f"Generalization accuracy {report["accuracy"]:.2%} below 70%"
    )
    assert report["negation_errors"] == 0, (
        f"Negation errors detected: {report["negation_errors"]}"
    )
    assert report["unsupported_economic_conclusions"] == 0, (
        f"Unsupported conclusions: {report["unsupported_economic_conclusions"]}"
    )

    import json
    report_path = Path("adversarial_benchmark_report.json")
    report_path.write_text(json.dumps(report, indent=2))
    print(f"\nDetailed report saved to {report_path}")
