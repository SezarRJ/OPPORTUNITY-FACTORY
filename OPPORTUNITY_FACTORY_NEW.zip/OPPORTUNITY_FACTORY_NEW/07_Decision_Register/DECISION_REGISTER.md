# DECISION REGISTER
**Document ID**: OF-DR-001
**Version**: 1.0
**Status**: DRAFT -- For Review
**Date**: 2026-11-08
**Project**: OPPORTUNITY FACTORY
**Classification**: Strategic Decision Log

---

## PURPOSE

This register captures all known decisions, pending decisions, unresolved conflicts, and their current status. Every entry must have an owner, target resolution date, and traceability to affected specifications.

---

## 1. KEY ARCHITECTURAL DECISIONS (KD) -- CONFIRMED

| ID | Decision | Description | Status | Owner | Date | Affected Specs |
|----|----------|-------------|--------|-------|------|----------------|
| KD-01 | Modular Monolith Architecture | Single deployable unit, internally modular; no microservices v1 | CONFIRMED | Lead Architect | 2026-11-08 | All SD-030..042, SD-050..056 |
| KD-02 | 12 Canonical Entities | Market, Sector, Entity, Asset, Activity, Product&Service, Need&Demand, Problem&Gap, Relationship, Source&Evidence, Claim, Opportunity | CONFIRMED | Data Architect | 2026-11-08 | SD-001..008, SD-020..028 |
| KD-03 | Evidence Levels E0-E4 | Five-tier evidence grading; no claim without evidence or explicit assumption flag | CONFIRMED | Domain Expert | 2026-11-08 | SD-004..006, SD-024, SD-025, SD-026 |
| KD-04 | Five Disciplines | Economic Intelligence, Systems Failure Analysis, Opportunity Engineering, Validation & Decision Science, Deployment & Learning | CONFIRMED | Lead Architect | 2026-11-08 | SD-010..014, SD-020..028 |
| KD-05 | Nine Functional Modules | M1-M9 as defined in Master Strategic Reference | CONFIRMED | Lead Architect | 2026-11-08 | SD-020..028 |
| KD-06 | Five Economic Engines | E1-E5 as internal intelligence layer | CONFIRMED | Lead Architect | 2026-11-08 | SD-010..014 |
| KD-07 | Six Creation Pathways | P1-P6: Resource->Value, Problem->Business, Process->Opportunity, Market->Market, Combination->Value, Asset->Opportunity | CONFIRMED | Opportunity Engineering Lead | 2026-11-08 | SD-012, SD-023 |
| KD-08 | Dual-Mode Operation | Market-to-Opportunity (M2O) + Asset-to-Value (A2V) on shared infrastructure | CONFIRMED | Lead Architect | 2026-11-08 | SD-020..028, All engines |
| KD-09 | MVP Single Owner + Optional Research Operator | No external users, no marketplace, no multi-user collaboration v1 | CONFIRMED | Product Owner | 2026-11-08 | SD-031, SD-050..056 |
| KD-10 | Eight MVP Screens | Dashboard, Market Investigation, Opportunity Factory, Asset-to-Value, Validation Workspace, Administration, Settings, Audit/History | CONFIRMED | Frontend Lead | 2026-11-08 | SD-050..056 |
| KD-11 | Eight Acceptance Tests | AT-A through AT-H as defined in Master Strategic Reference | CONFIRMED | QA Lead | 2026-11-08 | All SD-XXX, All gates |
| KD-12 | Twelve Named Approval Gates (Gate 0, 1A-1E, 2-7) + 7 Economic Hard Gates (HG-1..HG-7) | Gate 0 through Gate 7 as defined; 7 Economic Hard Gates are separate validation gates | CONFIRMED | Lead Architect | 2026-11-08 | OF-AP-001 |
| KD-13 | AI Internal Layer Only | No chatbot, no AI report generator as primary value; AI is internal productivity layer | CONFIRMED | Lead Architect | 2026-11-08 | SD-010..014, SD-050..056 |
| KD-14 | Global Cross-Sectoral Scope | No predetermined sector/country restrictions; evidence honesty required | CONFIRMED | Domain Expert | 2026-11-08 | SD-010, SD-020, SD-003 |
| KD-15 | Modular Monolith Extensibility | Architecture supports future service extraction without v1 rewrite | CONFIRMED | Lead Architect | 2026-11-08 | SD-030..042 |

---

## 2. UNRESOLVED CONCEPTUAL CONFLICTS (C1-C8) -- MUST BE EXPLICITLY DECIDED

| ID | Conflict | Description | Impact | Resolution Required By | Status | Owner |
|----|----------|-------------|--------|------------------------|--------|-------|
| C1 | Global Scope vs. Data Reality | System claims global coverage but data access is fragmented, expensive, uneven | M1, E1, SD-010, SD-020 | Stage 1 (SD-010 design) | OPEN | Economic Intelligence Lead |
| C2 | AI Internal vs. User Expectation | Users expect chatbot/genAI reports; architecture mandates AI as internal layer only | UX (SD-050..056), AI permissions | Stage 1 (SD-050 design) | OPEN | Frontend Lead + AI Systems Engineer |
| C3 | Evidence Rigor vs. Discovery Speed | High evidence standards (E3/E4) slow down discovery; low standards produce noise | M3, M5, E2, SD-011, SD-022, SD-024 | Stage 1 (SD-011, SD-024 design) | OPEN | Domain Expert + Economic Intelligence Lead |
| C4 | Model Extensibility vs. Stability | Sector independence requires flexible schema; stability requires fixed contracts | Canonical model (SD-001), Entity resolution (SD-002) | Stage 1 (SD-001, SD-002 design) | OPEN | Data Architect |
| C5 | Autonomous Discovery vs. Human Control | E1/E3 can run autonomously; but human must approve hypotheses before validation spend | M2, M4, E1, E3, SD-010, SD-012, SD-021, SD-023 | Stage 1 (SD-012, SD-023 design) | OPEN | Opportunity Engineering Lead |
| C6 | Financial Modeling: AI vs. Deterministic | Core equations must be deterministic/reproducible; AI useful for assumptions/scenarios | E4, M6, SD-013, SD-025 | Stage 1 (SD-013 design) | OPEN | Domain Expert / Quant |
| C7 | Sector Independence vs. Domain Knowledge | True sector-agnostic model vs. need for sector-specific logic/rules/benchmarks | M1, M3, M4, E2, E3, SD-003, SD-011, SD-012 | Stage 1 (SD-003, SD-011, SD-012 design) | OPEN | Domain Expert + Data Architect |
| C8 | Single-User MVP vs. Multi-User Architecture | v1 is single owner; but architecture must support multi-user without rewrite | Auth (SD-031), Permissions, Audit (SD-032) | Stage 1 (SD-031, SD-032 design) | OPEN | Backend Lead + Security |

Each conflict resolution will be recorded as a formal Architecture Decision Record (ADR) in 02_Architecture_Decisions/.

---

## 3. TOP-LEVEL STRATEGIC DECISIONS (SD1-SD10) -- PENDING

| ID | Decision | Description | Owner | Target | Status | Dependencies |
|----|----------|-------------|-------|--------|--------|--------------|
| SD1 | Technology Stack | Backend, frontend, database, AI, deployment | Lead Architect | Stage 1A | PENDING | None |
| SD2 | Database Technology | PostgreSQL extensions, TimescaleDB, vector, graph | Data Architect | Stage 1A | PENDING | SD1 |
| SD3 | AI/ML Framework | Provider selection, local vs. cloud, embedding strategy | AI Systems Engineer | Stage 1A | PENDING | SD1 |
| SD4 | Frontend Framework | React/Vue/Svelte, component library, state management | Frontend Lead | Stage 1A | PENDING | SD1 |
| SD5 | Deployment Target | Dev environment, prod target, CI/CD | DevOps | Stage 1A | PENDING | SD1 |
| SD6 | Pilot Market | First market/asset for end-to-end validation | Product Owner + Domain Expert | Stage 1B | PENDING | SD1, SD2 |
| SD7 | Evidence Thresholds | E2/E3/E4 criteria per claim type, gate requirements | Domain Expert | Stage 1B | PENDING | KD-03 |
| SD8 | Financial Engine Spec | Equation library, scenario types, sensitivity methods | Domain Expert / Quant | Stage 1B | PENDING | KD-03, KD-06 |
| SD9 | Entity Resolution | Matching algorithms, confidence thresholds, merge rules | Data Architect | Stage 1B | PENDING | KD-02 |
| SD10 | API/Integration Layer | REST/GraphQL, connector framework, webhook system | Backend Lead | Stage 1B | PENDING | SD1, SD4 |

---

## 4. DETAILED PENDING DECISIONS (PD-01..26) -- FROM SPECIFICATIONS TO DESIGN

| ID | Decision | Description | Owner | Target | Status | Related Spec |
|----|----------|-------------|-------|--------|--------|--------------|
| PD-01 | Backend Language/Framework | Python/FastAPI (preferred), Node.js/Express, Go | Lead Architect | Stage 1A | PENDING | SD1 |
| PD-02 | Database | PostgreSQL (preferred, with JSONB + pgvector), PostgreSQL + TimescaleDB | Data Architect | Stage 1A | PENDING | SD2 |
| PD-03 | Graph/Relationship Layer | PostgreSQL recursive CTEs (preferred), Neo4j (deferred), Apache Age | Data Architect | Stage 1A | PENDING | SD2 |
| PD-04 | Frontend Framework | React + TypeScript (preferred), Vue 3, Svelte | Frontend Lead | Stage 1A | PENDING | SD4 |
| PD-05 | UI Component Library | shadcn/ui + Tailwind (preferred), MUI, Ant Design | Frontend Lead | Stage 1A | PENDING | SD4 |
| PD-06 | AI/ML Integration | OpenAI API + local embeddings (preferred), Anthropic, self-hosted Llama | AI Systems Engineer | Stage 1A | PENDING | SD3 |
| PD-07 | Background Jobs | Celery + Redis (preferred), Dramatiq, Python RQ | Backend Lead | Stage 1A | PENDING | SD1 |
| PD-08 | Entity Resolution | Custom rule-based + ML (preferred), dedicated service | Data Architect | Stage 1B | PENDING | SD9 |
| PD-09 | File Storage | S3-compatible (MinIO local, AWS S3 prod) | DevOps | Stage 1A | PENDING | SD5 |
| PD-10 | Authentication | OIDC (Keycloak/Auth0), custom JWT | Backend Lead | Stage 1A | PENDING | SD10 |
| PD-11 | Deployment Target | Docker Compose (dev), Kubernetes (prod, deferred), VM | DevOps | Stage 1A | PENDING | SD5 |
| PD-12 | Observability | Prometheus + Grafana + OpenTelemetry | DevOps | Stage 1A | PENDING | SD5 |
| PD-13 | Canonical Data Model Physical Schema | Table/collection definitions, indexes, constraints, relationships | Data Architect | Stage 1B | PENDING | SD-001 |
| PD-14 | Entity Resolution Specification | Matching algorithms, confidence thresholds, merge rules, audit trail | Data Architect | Stage 1B | PENDING | SD-002 |
| PD-15 | Economic Ontology & Relationship Schema | Relationship types, cardinality, attributes, temporal validity, inference rules | Domain Expert | Stage 1B | PENDING | SD-003 |
| PD-16 | Evidence Ledger Schema | Immutable log structure, grading fields, source links, claim links, hash chains | Data Architect | Stage 1B | PENDING | SD-004 |
| PD-17 | Claim Registry Schema | Assertion structure, evidence links, grade, contradiction links, versioning | Data Architect | Stage 1B | PENDING | SD-005 |
| PD-18 | Source Registry Schema | Source metadata, classification, quality scoring, access config, rate limits | Data Architect | Stage 1B | PENDING | SD-006 |
| PD-19 | Opportunity State Machine Schema | State definitions, transition rules, required evidence, approval roles, audit fields | Domain Expert | Stage 1B | PENDING | SD-007 |
| PD-20 | Temporal Data Model | Valid-time, transaction-time for entities, relationships, claims, evidence | Data Architect | Stage 1B | PENDING | SD-008 |
| PD-21 | E1: Economic World Scanner Design Spec | Source connectors, ingestion pipelines, entity extraction, model building, refresh cycles | Economic Intelligence Lead | Stage 1B | PENDING | SD-010 |
| PD-22 | E2: System Failure & Gap Detector Design Spec | Value leakage algorithms, bottleneck detection, unmet demand identification, capacity analysis | Economic Intelligence Lead | Stage 1B | PENDING | SD-011 |
| PD-23 | E3: Opportunity Creation Engine Design Spec | 6 pathway implementations, pattern library, hypothesis builder, business model generator | Opportunity Engineering Lead | Stage 1B | PENDING | SD-012 |
| PD-24 | E4: Economic Model & Validation Engine Design Spec | Financial equations, assumption framework, scenario engine, sensitivity analysis, reproducibility | Domain Expert / Quant | Stage 1B | PENDING | SD-013 |
| PD-25 | E5: Opportunity Deployment Engine Design Spec | Packaging templates, resource mapping, partner criteria, pilot designer, approval workflow | Deployment Lead | Stage 1B | PENDING | SD-014 |
| PD-26 | M1: Market & Entity Intelligence Module Spec | APIs, data model, entity CRUD, relationship graph, search, import/export | Backend Lead | Stage 1C | PENDING | SD-020 |

---

## 5. NON-FUNCTIONAL REQUIREMENTS DECISIONS (NFR) -- PENDING

| ID | Requirement | Target | Status | Owner |
|----|-------------|--------|--------|-------|
| NFR-PERF-001 | Query response < 2s (p95) | Stage 1C | PENDING | Backend Lead |
| NFR-PERF-002 | Background job throughput > 100/min | Stage 1C | PENDING | Backend Lead |
| NFR-PERF-003 | Concurrent users: 1 (v1), 50 (v2) | Stage 1C | PENDING | DevOps |
| NFR-SEC-001 | Authentication required for all access | Stage 1A | PENDING | Backend Lead |
| NFR-SEC-002 | Role-based access control (Owner, Research Operator) | Stage 1C | PENDING | Backend Lead |
| NFR-SEC-003 | Audit logging for all state changes | Stage 1C | PENDING | Backend Lead |
| NFR-SEC-004 | Tamper-evident evidence ledger | Stage 1B | PENDING | Data Architect |
| NFR-AI-001 | LLM token budget per investigation | Stage 1B | PENDING | AI Systems Engineer |
| NFR-AI-002 | Cost monitoring and alerts | Stage 1C | PENDING | AI Systems Engineer |
| NFR-OPS-001 | RPO < 1 hour, RTO < 4 hours | Stage 1E | PENDING | DevOps |
| NFR-OPS-002 | Automated backup and restore tested | Stage 1E | PENDING | DevOps |
| NFR-UX-001 | RTL support (Arabic) | Stage 1D | PENDING | Frontend Lead |
| NFR-UX-002 | Accessibility WCAG 2.1 AA | Stage 1D | PENDING | Frontend Lead |
| NFR-UX-003 | Responsive design (desktop primary) | Stage 1D | PENDING | Frontend Lead |

---

## 6. DECISION LOG FORMAT

For each decision made, record:
- **Decision ID**: KD-XX, SD-XX, PD-XX, C-XX, NFR-XX
- **Title**: Brief descriptive title
- **Context**: Why this decision was needed
- **Options Considered**: List of alternatives with pros/cons
- **Decision**: What was chosen
- **Rationale**: Why this option was selected
- **Consequences**: Known trade-offs, risks, follow-up work
- **Owner**: Person responsible
- **Date**: Decision date
- **Status**: PROPOSED / APPROVED / REJECTED / SUPERSEDED
- **Traceability**: Links to affected specs (SD-XXX), ADRs, test cases

---

## 7. CHANGE CONTROL

| Date | Decision ID | Change | Author | Approved By |
|------|-------------|--------|--------|-------------|
| 2026-11-08 | KD-01..KD-15 | Initial confirmed decisions | Lead Architect | -- |
| 2026-11-08 | C1-C8 | Conflicts identified | Lead Architect | -- |
| 2026-11-08 | SD1-SD10 | Strategic decisions registered | Lead Architect | -- |
| 2026-11-08 | PD-01..26 | Detailed pending decisions registered | Lead Architect | -- |
| 2026-11-08 | PO-1 | Product Identity confirmed: Global Economic Intelligence & Opportunity Creation System; AI internal only | Product Owner | Product Owner |
| 2026-11-08 | PO-2 | Gate 0 Foundation Package approved (6 primary docs + 11 ADRs acknowledged) | Product Owner | Product Owner |
| 2026-11-08 | PO-3 | Codex adopted as AI-assisted Architectural Review Tool under Product Owner oversight | Product Owner | Product Owner |
| 2026-11-09 | PO-D1 | Existing Opportunity Discovery requires acceptance testing of P1-P6 first; no P7 is approved | Product Owner | Product Owner |
| 2026-11-09 | PO-D2 | Economic-flow modeling deferred pending Economic Ontology and Relationship Schema assessment; no 13th canonical entity approved | Product Owner | Product Owner |
| 2026-11-09 | PO-D3 | Seven V2 Economic Hard Gate principles approved; implementation deferred; failed Hard Gates cannot be bypassed by scores or AI recommendations | Product Owner | Product Owner |
| 2026-11-09 | PO-D4 | Historical reproducibility requirement approved; methodology versioning implementation model deferred | Product Owner | Product Owner |
| 2026-11-09 | PO-A1 | Codex AI-assisted Architectural Assessment accepted as the architectural review baseline; no human Lead Architect certification claimed | Product Owner | Product Owner |
| 2026-11-09 | PO-A2 | OF-DR-001-DE-001 AI-assisted Domain & Economic Methodology Assessment accepted as the methodological review baseline; no human Domain Expert certification claimed | Product Owner | Product Owner |

---

## 8. PRODUCT OWNER DECISION RECORDS

These records capture Product Owner decisions received after the initial foundation register. They do not close Gate 0 or authorize Stage 1.

### PO-D1 — Existing Opportunity Discovery

- **Status**: APPROVED — acceptance testing first
- **Date**: 2026-11-09
- **Authority**: Product Owner
- **Decision**: Test whether P1-P6 cover existing market opportunities, unmet demand, underexploited activities, replicable business models, and underused assets/capacities before considering any taxonomy change.
- **Constraint**: No P7 is approved. A new pathway may be considered only after documented test evidence and a separate Product Owner decision.
- **Traceability**: KD-07; SD-012; SD-023; Stage 1 acceptance-test design.

### PO-D2 — Economic Flows Modeling

- **Status**: DEFERRED
- **Date**: 2026-11-09
- **Authority**: Product Owner
- **Decision**: Defer selection between a thirteenth canonical entity and relationship-based modeling.
- **Required assessment**: Complete the Economic Ontology and Relationship Schema assessment, including temporal validity, multiple flows, direction, quantities, value, ownership, control, evidence traceability, and indirect relationship discovery.
- **Constraint**: No thirteenth canonical entity is approved.
- **Traceability**: KD-02; PD-15; SD-003.

### PO-D3 — Economic Hard Gate Principle

- **Status**: PRINCIPLE APPROVED; IMPLEMENTATION DEFERRED
- **Date**: 2026-11-09
- **Authority**: Product Owner
- **Decision**: The seven V2 Economic Hard Gates are mandatory, non-overridable opportunity-validation constraints:
  - HG-1: Legal Permission
  - HG-2: Economic Mechanism
  - HG-3: Identifiable Payer
  - HG-4: Critical Resource Access
  - HG-5: Critical Evidence
  - HG-6: Capital Exposure
  - HG-7: Safety & Compliance
- **Constraint**: A failed Hard Gate must not be bypassed by an overall numerical score or AI recommendation. The enforcement mechanism remains a Stage 1 design decision.
- **Traceability**: KD-12; SD-013; SD-025; SD-026; OF-SR-001 §7.

### PO-D4 — Methodology Version Governance

- **Status**: REQUIREMENT APPROVED; IMPLEMENTATION MODEL DEFERRED
- **Date**: 2026-11-09
- **Authority**: Product Owner
- **Decision**: Historical assessments must remain reproducible using their original methodology versions, assumptions, evidence references, and calculation rules.
- **Required design comparison**: Evaluate whole-methodology snapshots, per-dimension versioning, and any appropriate hybrid model, including version pinning, human approval, change history, and rollback.
- **Constraint**: No final implementation model is selected by this record.
- **Traceability**: KD-04; SD-028; SD-026; SD-013; OF-SR-001 §5.

### PO-A1 — Codex AI-Assisted Architectural Assessment

- **Status**: ACCEPTED
- **Date**: 2026-11-09
- **Authority**: Product Owner
- **Decision**: Accept the Codex AI-assisted Architectural Assessment and findings LA-01 through LA-14 as the architectural review baseline.
- **Scope**: Acceptance does not mean that recommendations are implemented, tested, or independently verified. Unresolved findings remain subject to their assigned Stage 1 design activities.
- **Authority limitation**: This is acceptance of an AI-assisted assessment under Product Owner oversight, not independent human Lead Architect certification.
- **Traceability**: `02_Architecture_Decisions/LEAD_ARCHITECT_GATE0_ASSESSMENT.md`; Gate 0 approval record.

### PO-A2 — AI-Assisted Domain & Economic Methodology Assessment

- **Status**: ACCEPTED
- **Date**: 2026-11-09
- **Authority**: Product Owner
- **Decision**: Accept `OF-DR-001-DE-001` as the official AI-assisted Domain & Economic Methodology review baseline.
- **Scope**: Findings, methodological observations, and V1-to-V2 comparison are accepted for tracking, design, testing, or resolution in their assigned stages. PO-D1 through PO-D4 remain unchanged.
- **Authority limitation**: This is acceptance of an AI-assisted assessment prepared by Codex under Product Owner oversight, not independent human Domain Expert certification. The assessment was delivered in conversation; this record does not assert that a separate project-file copy exists.
- **Traceability**: Gate 0 approval record; Stage 1 design and acceptance-test work.

---

**END OF DECISION REGISTER**

*This register must be updated at every approval gate. No decision is final until recorded here with traceability.*
