with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# Update cross_market_replication aliases to be broader but still require cross-market context
old_cross_market = """    "cross_market_replication": {
        "aliases": (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "successful model in another market",
            "successful model abroad",
            "established service in another market",
            "established service abroad",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "business model operating elsewhere",
            "service model from another market",
            "service model from abroad",
            "service model from overseas",
            "existing business model in another market",
            "existing business model abroad",
            "modelo probado en otro mercado",
            "modelo exitoso en otro mercado",
            "modelo de negocio en otro mercado",
            "replicar en otro mercado",
            "replicar en el extranjero",
            "replicar internacionalmente",
            "نموذج أعمال مثبت في سوق آخر",
            "نموذج ناجح في سوق آخر",
            "نموذج قائم في سوق آخر",
            "تكرار نموذج في سوق آخر",
            "نقل نموذج إلى سوق آخر",
        ),
        "reason": (
            "The context describes an existing model, product, or service that "
            "may be adapted or replicated across markets. Requires explicit "
            "cross-market context (another market, abroad, overseas, internationally)."
        ),
    },"""

new_cross_market = """    "cross_market_replication": {
        "aliases": (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "replicate the",
            "replicate a",
            "replicate an",
            "replicate from",
            "port to",
            "porting to",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "proven model from",
            "proven model we can replicate",
            "proven playbook",
            "proven format",
            "proven scheme",
            "proven approach",
            "successful model in another market",
            "successful model abroad",
            "successful model from",
            "established service in another market",
            "established service abroad",
            "established service from",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "transferable model from",
            "business model operating elsewhere",
            "service model from another market",
            "service model from abroad",
            "service model from overseas",
            "existing business model in another market",
            "existing business model abroad",
            "modelo probado en otro mercado",
            "modelo exitoso en otro mercado",
            "modelo de negocio en otro mercado",
            "replicar en otro mercado",
            "replicar en el extranjero",
            "replicar internacionalmente",
            "نموذج أعمال مثبت في سوق آخر",
            "نموذج ناجح في سوق آخر",
            "نموذج قائم في سوق آخر",
            "تكرار نموذج في سوق آخر",
            "نقل نموذج إلى سوق آخر",
            "model from",
            "model in",
            "operates in",
        ),
        "reason": (
            "The context describes an existing model, product, or service that "
            "may be adapted or replicated across markets. Requires explicit "
            "cross-market context (another market, abroad, overseas, internationally, from another)."
        ),
    },"""

content = content.replace(old_cross_market, new_cross_market)
print("cross_market_replication updated in semantic.py")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)
