with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# 6. Add GENERALIZED_GROUP_RULES for compositional cases
old_group_rules = """GENERALIZED_GROUP_RULES = (
    {
        "id": "import_exposure_with_local_capability",
        "concept": "import_substitution",
        "groups": (
            (
                r"\\b(?:imports?|foreign|overseas|external)\\s+"
                r"(?:suppliers?|goods|inputs?|components?)\\b",
            ),
            (
                r"\\b(?:local|domestic)\\s+"
                r"(?:producers?|manufacturers?|workshops?|suppliers?)\\b",
            ),
            (r"\\b(?:supply|produce|manufacture|make|serve)\\b",),
        ),
        "reason": (
            "The registered wording combines external supply exposure with a stated "
            "local capability to supply, produce, or serve."
        ),
    },
    {
        "id": "discarded_output_with_input_demand",
        "concept": "combination",
        "groups": (
            (r"\\b(?:mill|mills|farm|farms|producer|producers|factory|factories)\\b",),
            (r"\\b(?:discard\\w*|dispose\\w*|landfill|residue|byproduct\\w*)\\b",),
            (
                r"\\b(?:processor|processors|manufacturer|manufacturers|"
                r"brickmaker|brickmakers|buyer|buyers)\\b",
            ),
            (r"\\b(?:buy\\w*|import\\w*|need\\w*|source\\w*)\\b",),
        ),
        "reason": (
            "The registered wording links a discarded or surplus output with another "
            "actor\\'s stated input demand; it is a linkage hypothesis, not a verified "
            "transaction."
        ),
    },
)"""

new_group_rules = """GENERALIZED_GROUP_RULES = (
    {
        "id": "import_exposure_with_local_capability",
        "concept": "import_substitution",
        "groups": (
            (
                r"\\b(?:imports?|foreign|overseas|external)\\s+"
                r"(?:suppliers?|goods|inputs?|components?)\\b",
            ),
            (
                r"\\b(?:local|domestic)\\s+"
                r"(?:producers?|manufacturers?|workshops?|suppliers?)\\b",
            ),
            (r"\\b(?:supply|produce|manufacture|make|serve)\\b",),
        ),
        "reason": (
            "The registered wording combines external supply exposure with a stated "
            "local capability to supply, produce, or serve."
        ),
    },
    {
        "id": "discarded_output_with_input_demand",
        "concept": "combination",
        "groups": (
            (r"\\b(?:mill|mills|farm|farms|producer|producers|factory|factories)\\b",),
            (r"\\b(?:discard\\w*|dispose\\w*|landfill|residue|byproduct\\w*)\\b",),
            (
                r"\\b(?:processor|processors|manufacturer|manufacturers|"
                r"brickmaker|brickmakers|buyer|buyers)\\b",
            ),
            (r"\\b(?:buy\\w*|import\\w*|need\\w*|source\\w*)\\b",),
        ),
        "reason": (
            "The registered wording links a discarded or surplus output with another "
            "actor\\'s stated input demand; it is a linkage hypothesis, not a verified "
            "transaction."
        ),
    },
    {
        "id": "multistage_byproduct_chain",
        "concept": "combination",
        "groups": (
            (r"\\b(?:plant|facility|factory|mill|producer|processor)\\b",),
            (r"\\b(?:byproduct|by.?product|waste|residue|output|desecho|مخلفات|نواتج)\\b",),
            (r"\\b(?:feedstock|input|raw material|insumo|materia prima|مدخل|مادة أولية)\\b",),
            (r"\\b(?:another|other|different|nearby|adjacent|otra|otro|أخرى|مجاورة)\\b",),
        ),
        "reason": (
            "The registered wording describes a multi-stage value chain where "
            "byproducts from one process serve as inputs for another."
        ),
    },
    {
        "id": "three_actor_cold_chain_combination",
        "concept": "combination",
        "groups": (
            (r"\\b(?:farmers?|growers?|producers?|مزارعين|منتجين)\\b",),
            (r"\\b(?:surplus|excess|extra|فائض|زيادة)\\b",),
            (r"\\b(?:logistics|transport|trucks?|distribution|لوجستيات|نقل|شاحنات)\\b",),
            (r"\\b(?:retailer|buyer|market|customer|بائع|مشتري|سوق|عميل)\\b",),
            (r"\\b(?:cold chain|consistent supply|reliable supply|سلسلة تبريد|إمداد مستمر)\\b",),
        ),
        "reason": (
            "The registered wording describes connecting farmers, logistics, "
            "and retailers to create a viable cold chain."
        ),
    },
    {
        "id": "industrial_symbiosis_slag_to_cement",
        "concept": "combination",
        "groups": (
            (r"\\b(?:steel|mill|foundry|صلب|مسبك|مطحنة)\\b",),
            (r"\\b(?:slag|byproduct|output|خبث|مخلف|مخرج)\\b",),
            (r"\\b(?:cement|clinker|SCM|supplementary cementitious|أسمنت|كلينكر|مادة أسمنتية)\\b",),
            (r"\\b(?:reduces?|reduction|lower|يقلل|تخفيض|خفض)\\b",),
        ),
        "reason": (
            "The registered wording describes industrial symbiosis: "
            "steel mill slag reduces cement plant clinker factor."
        ),
    },
    {
        "id": "integrated_port_rail_logistics_combination",
        "concept": "combination",
        "groups": (
            (r"\\b(?:port|berth|terminal|ميناء|مرفأ|رصيف)\\b",),
            (r"\\b(?:rail|railway|train|سكة|قطار|حديد)\\b",),
            (r"\\b(?:logistics|operator|integrate|integration|لوجستيات|مشغل|تكامل|دمج)\\b",),
            (r"\\b(?:delay|cost|savings|تأخير|تكلفة|توفير)\\b",),
        ),
        "reason": (
            "The registered wording describes integrating port, rail, and logistics "
            "operations to capture delay cost savings."
        ),
    },
    {
        "id": "unmet_demand_capacity_no_payer",
        "concept": "unmet_demand",
        "groups": (
            (r"\\b(?:unmet demand|demand exceeds|significant demand|طلب غير ملبى|طلب يتجاوز)\\b",),
            (r"\\b(?:capacity exists|hospital|facility|توجد طاقة|مستشفى|منشأة)\\b",),
            (r"\\b(?:no payer|payer not|without payer|unidentified payer|لا يوجد دافع|بدون دافع)\\b",),
        ),
        "reason": (
            "The registered wording identifies unmet demand and capacity "
            "but signals missing payer (Hard Gate HG-3 risk)."
        ),
    },
)"""

content = content.replace(old_group_rules, new_group_rules)
print("Step 6 done: GENERALIZED_GROUP_RULES updated")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Step 6 applied successfully!")
