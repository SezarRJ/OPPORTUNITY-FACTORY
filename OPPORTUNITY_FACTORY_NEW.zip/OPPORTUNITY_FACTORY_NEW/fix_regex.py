with open("app/services/analysis.py", "r", encoding="utf-8") as f:
    content = f.read()

import re

# Pattern to match the opportunity creation - add discovery_reasoning after quality
pattern = r"(\"quality\": quality,\n\s+\"status\": \()"
replacement = r"\"quality\": quality,\n                      \"discovery_reasoning\": evaluation.get(\"reasoning\", []),\n                      \"status\": ("

content = re.sub(pattern, replacement, content)

with open("app/services/analysis.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Fix applied with regex")
