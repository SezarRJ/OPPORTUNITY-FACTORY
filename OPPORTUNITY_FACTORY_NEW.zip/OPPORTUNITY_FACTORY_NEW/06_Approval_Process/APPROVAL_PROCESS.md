# APPROVAL PROCESS
**Document ID**: OF-AP-001
**Version**: 1.0
**Status**: DRAFT -- For Review
**Date**: 2026-11-08
**Project**: OPPORTUNITY FACTORY
**Classification**: Governance & Approval

---

## PURPOSE

This document defines the mandatory approval process for OPPORTUNITY FACTORY. 12 named project gates: 8 stage-exit approval gates and 4 design-review gates must be passed before production code is deployed. Each gate has defined artifacts, criteria, required authorities, and checklists.

---

## GATE SUMMARY

| Gate | Name | Stage | Required Authorities | Key Artifacts |
|------|------|-------|---------------------|---------------|
| **Gate 0** | Strategic Foundation | 0 | Product Owner (final decision) + Codex (AI-assisted architectural assessment) + AI-assisted Domain & Economic Methodology Assessment (PO oversight; no human certification claimed) | OF-SR-001, OF-DR-001, OF-RTF-001, OF-STD-001, OF-RM-001, OF-AP-001 |
| **Gate 1A** | Technology Stack Decisions | 1A | Lead Architect + Data Architect + AI Systems Engineer + DevOps | PD-01..05, PD-09..12 resolutions |
| **Gate 1B** | Data & Engine Architecture | 1B | Data Architect + EI Lead + OE Lead + Domain Expert | PD-06, PD-07, PD-08, SD-001..008, SD-010..014 |
| **Gate 1C** | Module & Cross-Cutting Specs | 1C | Backend Lead + Frontend Lead + DevOps + QA Lead + Security | SD-020..042 |
| **Gate 1D** | UX/UI Specs | 1D | Frontend Lead + Domain Expert + Product Owner | SD-050..056 |
| **Gate 1E** | Stage 1 Consolidated | 1E | Lead Architect + Domain Expert + QA Lead + Product Owner | All 42 SDD-XXX approved |
| **Gate 2** | Phase 1 Implementation | 2 | Lead Architect + QA Lead + Product Owner | Stage 2 deliverables, AT-Infrastructure |
| **Gate 3** | Phase 2 Implementation | 3 | EI Lead + OE Lead + QA Lead + Product Owner | AT-A, AT-B PASS |
| **Gate 4** | Phase 3 Implementation | 4 | Domain Expert + Validation Lead + QA Lead + Product Owner | AT-C, AT-E, AT-F, AT-G PASS |
| **Gate 5** | Phase 4 Implementation | 5 | Asset Lead + QA Lead + Product Owner | AT-D PASS |
| **Gate 6** | Phase 5 Implementation | 6 | Learning Lead + QA Lead + Product Owner | AT-H PASS |
| **Gate 7** | Production Hardening | 7 | Lead Architect + DevOps + Security + QA Lead + Product Owner | All 8 ATs PASS in prod-like |

---

## GATE 0: STRATEGIC FOUNDATION (CURRENT STAGE)

### Objective
Establish project foundation, strategic alignment, and decision register before any design work begins.

### Required Authorities
- Product Owner (final Gate 0 closure decision): _________________________ Date: __________
- Codex AI-assisted architectural assessment (assessment input under Product Owner oversight; no approval authority): completed record
- AI-assisted Domain & Economic Methodology Assessment (assessment input under Product Owner oversight; no independent human certification claimed): completed record

### Required Artifacts
1. OF-SR-001 Master Strategic Reference (complete, Sections 1-18)
2. OF-DR-001 Decision Register (all KD, PD, SD, C, NFR items with owners)
3. OF-RTF-001 Requirements Traceability Framework (matrix + process)
4. OF-STD-001 Specifications To Design (42 specs with owners/deps)
5. OF-RM-001 Roadmap (8 stages, 8 milestones, resource estimates)
6. OF-AP-001 Approval Process (this document, all gates defined)
7. ADR Stubs in 02_Architecture_Decisions/ for KD-01, KD-02, KD-03, C1-C8

### Gate 0 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 6 primary foundation documents exist and are complete | [x] | Verified by file inspection |
| 2 | Master Strategic Reference covers all 18 sections | [x] | Verified |
| 3 | All 15 KD decisions recorded with rationale | [x] | Verified |
| 4 | All 8 C conflicts identified, assigned, with resolution target | [x] | Verified |
| 5 | All 10 SD strategic decisions registered with owners | [x] | Verified |
| 6 | All 26 PD detailed decisions registered with owners | [x] | Verified |
| 7 | All 14 NFR requirements registered with owners | [x] | Verified |
| 8 | Traceability matrix links SR to FR to SD to KD | [x] | Verified |
| 9 | Roadmap has 8 stages, 8 milestones, resource estimates | [x] | Verified (8 stages: 0-7) |
| 10 | Approval process defines 12 named project gates: 8 stage-exit approval gates and 4 design-review gates with authorities | [x] | Verified (corrected) |
| 11 | ADR stubs created for 3 key decisions + 8 conflicts | [x] | Verified (3 ACCEPTED, 8 OPEN) |
| 12 | Product Owner decisions PO-1, PO-2, PO-3, PO-D1..PO-D4, PO-A1, and PO-A2 recorded | [x] | Decision Register and Gate 0 approval record |
| 13 | Codex AI-assisted architectural assessment completed and accepted | [x] | PO-A1; assessment baseline recorded |
| 14 | AI-assisted Domain & Economic Methodology Assessment completed and accepted | [x] | PO-A2; `OF-DR-001-DE-001`; no human certification claimed |
| 15 | Product Owner final closure decision | [ ] | Pending |

### Exit Criteria
- [ ] All checklist items PASS
- [ ] Product Owner approvals recorded (PO-1, PO-2)
- [x] Codex AI-assisted architectural assessment submitted and accepted under PO-A1
- [x] AI-assisted Domain & Economic Methodology Assessment submitted and accepted under PO-A2; no independent human certification claimed
- [ ] Product Owner final closure decision recorded
- [ ] No open blockers

---

## GATE 1A: TECHNOLOGY STACK DECISIONS

### Objective
Resolve all foundational technology decisions before any design work begins.

### Required Authorities
- Lead Architect (chair)
- Data Architect
- AI Systems Engineer
- DevOps

### Decisions to Resolve
| Decision ID | Area | Options | Resolution |
|-------------|------|---------|------------|
| PD-01 | Backend Language/Framework | Python/FastAPI, Node.js/Express, Go | |
| PD-02 | Database | PostgreSQL, PostgreSQL+TimescaleDB | |
| PD-03 | Graph/Relationship Layer | PostgreSQL CTEs, Neo4j, Apache Age | |
| PD-04 | Frontend Framework | React+TS, Vue 3, Svelte | |
| PD-05 | UI Component Library | shadcn/ui+Tailwind, MUI, Ant Design | |
| PD-06 | AI/ML Integration | OpenAI+local, Anthropic, self-hosted Llama | |
| PD-07 | Background Jobs | Celery+Redis, Dramatiq, Python RQ | |
| PD-09 | File Storage | S3-compatible (MinIO, AWS S3) | |
| PD-10 | Authentication | OIDC (Keycloak/Auth0), custom JWT | |
| PD-11 | Deployment Target | Docker Compose, K8s (deferred), VM | |
| PD-12 | Observability | Prometheus+Grafana+OpenTelemetry | |

### Gate 1A Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 12 PD decisions resolved with rationale | [ ] |
| 2 | SD1-SD5 (Technology Stack, Database, AI/ML, Frontend, Deployment) resolved | [ ] |
| 3 | NFR-SEC-001, NFR-PERF-001..003 baselines defined | [ ] |
| 4 | Technology choices documented in ADRs | [ ] |
| 5 | Proof-of-concept or spike completed for risky choices | [ ] |
| 6 | Cost estimates for technology stack documented | [ ] |
| 7 | Team skills assessment for chosen stack completed | [ ] |
| 8 | All 4 authorities approve | [ ] |

---

## GATE 1B: DATA & ENGINE ARCHITECTURE

### Objective
Resolve data model, entity resolution, and engine architecture specifications.

### Required Authorities
- Data Architect (chair)
- Economic Intelligence Lead
- Opportunity Engineering Lead
- Domain Expert

### Decisions to Resolve
| Decision ID | Area | Resolution |
|-------------|------|------------|
| PD-06 | Pilot Market | |
| PD-07 | Evidence Thresholds | |
| PD-08 | Entity Resolution | |
| SD-001 | Canonical Data Model Physical Schema | |
| SD-002 | Entity Resolution Specification | |
| SD-003 | Economic Ontology & Relationship Schema | |
| SD-004 | Evidence Ledger Schema | |
| SD-005 | Claim Registry Schema | |
| SD-006 | Source Registry Schema | |
| SD-007 | Opportunity State Machine Schema | |
| SD-008 | Temporal Data Model | |
| SD-010 | E1: Economic World Scanner Design Spec | |
| SD-011 | E2: System Failure & Gap Detector Design Spec | |
| SD-012 | E3: Opportunity Creation Engine Design Spec | |
| SD-013 | E4: Economic Model & Validation Engine Design Spec | |
| SD-014 | E5: Opportunity Deployment Engine Design Spec | |

### Gate 1B Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 17 PD/SD decisions resolved with rationale | [ ] |
| 2 | SD6-SD10 (Pilot, Evidence thresholds, Entity resolution, Core data, Engine specs) resolved | [ ] |
| 3 | All data specs traceable to KD-02, KD-03 | [ ] |
| 4 | Engine specs traceable to KD-04, KD-05, KD-06 | [ ] |
| 5 | C1, C3, C4, C6, C7 conflicts addressed in designs | [ ] |
| 6 | All 4 authorities approve | [ ] |

---

## GATE 1C: MODULE & CROSS-CUTTING SPECS

### Objective
Approve all 9 module specifications and 13 cross-cutting specifications.

### Required Authorities
- Backend Lead (chair)
- Frontend Lead
- DevOps
- QA Lead
- Security

### Specifications to Approve
| Spec ID | Title | Status |
|---------|-------|--------|
| SD-020 | M1: Market & Entity Intelligence Module Spec | |
| SD-021 | M2: Signal & Change Detection Module Spec | |
| SD-022 | M3: Gap & Inefficiency Detection Module Spec | |
| SD-023 | M4: Opportunity Creation Engine Module Spec | |
| SD-024 | M5: Evidence & Claim Management Module Spec | |
| SD-025 | M6: Economic Modeling & Validation Module Spec | |
| SD-026 | M7: Scoring & Decision Engine Module Spec | |
| SD-027 | M8: Deployment & Pilot Management Module Spec | |
| SD-028 | M9: Learning & Calibration Engine Module Spec | |
| SD-030 | API/Integration Layer Spec | |
| SD-031 | Authentication & Authorization Spec | |
| SD-032 | Audit Logging Spec | |
| SD-033 | Background Job Processing Spec | |
| SD-034 | File & Document Storage Spec | |
| SD-035 | Caching Strategy Spec | |
| SD-036 | Search & Discovery Spec | |
| SD-037 | Geospatial Capabilities Spec | |
| SD-038 | Internationalization Spec | |
| SD-039 | Testing Strategy Spec | |
| SD-040 | Observability Spec | |
| SD-041 | Backup & Disaster Recovery Spec | |
| SD-042 | Cost Management Spec | |

### Gate 1C Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 23 module + cross-cutting specs approved with traceability | [ ] |
| 2 | All specs traceable to FRs and KDs | [ ] |
| 3 | Cross-cutting specs have NFR traceability | [ ] |
| 4 | C5, C8 conflicts addressed in module designs | [ ] |
| 5 | Implementation plans with estimates for each spec | [ ] |
| 6 | All 5 authorities approve | [ ] |

---

## GATE 1D: UX/UI SPECS

### Objective
Approve all 7 screen specifications and design system.

### Required Authorities
- Frontend Lead (chair)
- Domain Expert
- Product Owner

### Specifications to Approve
| Spec ID | Title | Status |
|---------|-------|--------|
| SD-050 | Dashboard Screen Spec | |
| SD-051 | Market Investigation Screen Spec | |
| SD-052 | Opportunity Factory Screen Spec | |
| SD-053 | Asset-to-Value Screen Spec | |
| SD-054 | Validation Workspace Screen Spec | |
| SD-055 | Administration Screen Spec | |
| SD-056 | Design System & Component Library | |

### Gate 1D Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 7 UX specs approved with traceability | [ ] |
| 2 | Specs traceable to SR-28, SR-29, NFR-UX-001..003 | [ ] |
| 3 | C2 (AI Internal vs User Expectation) resolution reflected in UX | [ ] |
| 4 | RTL (Arabic) support designed in all screens | [ ] |
| 5 | Accessibility WCAG 2.1 AA designed | [ ] |
| 6 | Design system components defined for all UI patterns | [ ] |
| 7 | All 3 authorities approve | [ ] |

---

## GATE 1E: STAGE 1 CONSOLIDATED APPROVAL

### Objective
Final consolidated approval of all Stage 1 design work before implementation begins.

### Required Authorities
- Lead Architect (chair)
- Domain Expert
- QA Lead
- Product Owner

### Gate 1E Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 42 SDD-XXX documents reviewed and approved | [ ] |
| 2 | 100% SR coverage by at least one SD | [ ] |
| 3 | 100% FR coverage by at least one SD | [ ] |
| 4 | 100% PD resolved by SD | [ ] |
| 5 | All C conflicts have resolution documented in ADRs | [ ] |
| 6 | Implementation plans ready with tasks, estimates, dependencies | [ ] |
| 7 | Resource commitments confirmed for Stage 2 | [ ] |
| 8 | Traceability completeness report generated | [ ] |
| 9 | Risk register updated with design-phase risks | [ ] |
| 10 | All 4 authorities approve | [ ] |

---

## GATE 2: PHASE 1 IMPLEMENTATION (CORE FOUNDATION)

### Objective
Core infrastructure, authentication, data model, and basic CRUD operational.

### Required Authorities
- Lead Architect (chair)
- QA Lead
- Product Owner

### Gate 2 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | User authentication and RBAC (Owner, Research Operator) working | [ ] |
| 2 | Dashboard (SD-050) functional with real data | [ ] |
| 3 | Canonical data model (SD-001) deployed and tested | [ ] |
| 4 | Market/Entity/Asset CRUD (SD-020) functional | [ ] |
| 5 | Source/Evidence management (SD-024) functional | [ ] |
| 6 | Task management system operational | [ ] |
| 7 | Background jobs (SD-033) processing test workloads | [ ] |
| 8 | Audit logging (SD-032) capturing all state changes | [ ] |
| 9 | Acceptance Tests (Infrastructure) PASS | [ ] |
| 10 | System runs end-to-end for core data management | [ ] |
| 11 | All 3 authorities approve | [ ] |

---

## GATE 3: PHASE 2 IMPLEMENTATION (OPPORTUNITY DISCOVERY)

### Objective
Market investigation, gap detection, and initial opportunity creation workflow operational.

### Required Authorities
- Economic Intelligence Lead (chair)
- Opportunity Engineering Lead
- QA Lead
- Product Owner

### Gate 3 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | Guided search and market analysis (SD-020, SD-021) functional | [ ] |
| 2 | Gap detection (SD-022) identifying real gaps with evidence | [ ] |
| 3 | Relationship discovery (SD-020) mapping economic connections | [ ] |
| 4 | Initial opportunity creation (SD-023) via P1-P5 pathways | [ ] |
| 5 | Opportunity management (create, compare, save) working | [ ] |
| 6 | Acceptance Test A (Market Intelligence) PASS | [ ] |
| 7 | Acceptance Test B (Unconventional Discovery) PASS | [ ] |
| 8 | Market investigation -> gap detection -> opportunity creation workflow works | [ ] |
| 9 | All 4 authorities approve | [ ] |

---

## GATE 4: PHASE 3 IMPLEMENTATION (CREATION & VALIDATION)

### Objective
Full validation workflow: economic modeling, evidence verification, scoring, decision.

### Required Authorities
- Domain Expert (chair)
- Validation Lead
- QA Lead
- Product Owner

### Gate 4 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | Economic model builder (SD-025) with deterministic equations | [ ] |
| 2 | Claim verification (SD-024) with E0-E4 grading | [ ] |
| 3 | Assumption management with test plans | [ ] |
| 4 | Cost/revenue analysis with scenarios | [ ] |
| 5 | Risk assessment (SD-026) with sensitivity | [ ] |
| 6 | Opportunity comparison and ranking | [ ] |
| 7 | Validation gates enforcing state transitions | [ ] |
| 8 | Acceptance Test C (Economic Model Creation) PASS | [ ] |
| 9 | Acceptance Test E (Evidence Verification) PASS | [ ] |
| 10 | Acceptance Test F (Financial Feasibility) PASS | [ ] |
| 11 | Acceptance Test G (Decision Gate) PASS | [ ] |
| 12 | Full validation workflow works end-to-end | [ ] |
| 13 | All 4 authorities approve | [ ] |

---

## GATE 5: PHASE 4 IMPLEMENTATION (ASSET-TO-VALUE)

### Objective
Asset analysis, utilization assessment, and improvement opportunity workflow operational.

### Required Authorities
- Asset Lead (chair)
- QA Lead
- Product Owner

### Gate 5 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | Asset data ingestion (SD-020, SD-027) functional | [ ] |
| 2 | Process analysis with utilization metrics | [ ] |
| 3 | Unused capacity detection with evidence | [ ] |
| 4 | Waste identification and value leakage quantification | [ ] |
| 5 | Activity reconfiguration hypotheses via P1, P3, P6 | [ ] |
| 6 | Improvement opportunity creation and validation | [ ] |
| 7 | Acceptance Test D (Asset-to-Value Analysis) PASS | [ ] |
| 8 | Asset analysis -> improvement workflow works end-to-end | [ ] |
| 9 | All 3 authorities approve | [ ] |

---

## GATE 6: PHASE 5 IMPLEMENTATION (LEARNING & EXPANSION)

### Objective
Learning loop operational: outcome tracking, prediction vs actual, rule improvement.

### Required Authorities
- Learning Lead (chair)
- QA Lead
- Product Owner

### Gate 6 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | Outcome tracking (SD-028) recording pilot results | [ ] |
| 2 | Prediction vs actual comparison automated | [ ] |
| 3 | Discovery rule improvement from outcomes | [ ] |
| 4 | Model recalibration (financial params, evidence weights) | [ ] |
| 5 | Data source expansion workflow | [ ] |
| 6 | Market/language expansion templates (SD-038) | [ ] |
| 7 | Automation assessment with human-in-the-loop boundaries | [ ] |
| 8 | Acceptance Test H (Sector Independence) PASS | [ ] |
| 9 | Learning loop operational (predictions -> outcomes -> improvements) | [ ] |
| 10 | Sector independence verified (new sector onboarded without code changes) | [ ] |
| 11 | Automation boundaries documented and enforced | [ ] |
| 12 | All 3 authorities approve | [ ] |

---

## GATE 7: PRODUCTION HARDENING

### Objective
Production readiness: performance, security, observability, backup/DR, documentation.

### Required Authorities
- Lead Architect (chair)
- DevOps
- Security
- QA Lead
- Product Owner

### Gate 7 Checklist
| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | All 8 Acceptance Tests (A-H) PASS in production-like environment | [ ] |
| 2 | All NFR targets met (PERF, SEC, AI, OPS, UX) | [ ] |
| 3 | Security audit passed (penetration test, audit logs tamper-proof) | [ ] |
| 4 | DR test successful (RPO <1hr, RTO <4hr) | [ ] |
| 5 | Observability complete (dashboards, alerts, SLOs defined and monitored) | [ ] |
| 6 | Documentation complete (architecture, API, user guide, runbooks) | [ ] |
| 7 | Cost management operational (LLM budgets, API quotas monitored, alerting) | [ ] |
| 8 | Performance optimization under load completed | [ ] |
| 9 | All 5 authorities approve | [ ] |

---

## APPROVAL TEMPLATES

### Template 1: Gate Approval Record

`
GATE APPROVAL RECORD
====================
Gate: [Gate Number/Name]
Date: [Date]
Project: OPPORTUNITY FACTORY

ARTIFACTS REVIEWED:
- [Artifact 1]
- [Artifact 2]
...

CHECKLIST RESULTS:
| # | Criterion | PASS/FAIL | Notes |
|---|-----------|-----------|-------|
| 1 | ... | | |
...

DECISION: [APPROVED / CONDITIONAL / REJECTED]

CONDITIONS (if conditional):
- [Condition 1]
- [Condition 2]
...

APPROVAL AUTHORITIES:
| Role | Name | Signature | Date |
|------|------|-----------|------|
| [Role 1] | | | |
| [Role 2] | | | |
| [Role 3] | | | |
...

NEXT GATE TARGET DATE: [Date]
`

### Template 2: Conflict Resolution Record (ADR)

`
ARCHITECTURE DECISION RECORD
============================
ADR ID: [ADR-XXX]
Date: [Date]
Status: [PROPOSED / ACCEPTED / SUPERSEDED]

CONFLICT: [C1-C8 or other]

CONTEXT:
[Why this decision is needed. What is the conflict?]

OPTIONS CONSIDERED:
| Option | Description | Pros | Cons |
|--------|-------------|------|------|
| 1 | | | |
| 2 | | | |
| 3 | | | |

DECISION:
[What was chosen]

RATIONALE:
[Why this option was selected]

CONSEQUENCES:
- Positive: [Benefits]
- Negative: [Trade-offs, risks]
- Follow-up: [Required actions]

AFFECTED SPECIFICATIONS:
- [SD-XXX]
- [SD-XXX]

APPROVAL:
| Role | Name | Signature | Date |
|------|------|-----------|------|
| Lead Architect | | | |
| Domain Expert | | | |
| [Other] | | | |
`

### Template 3: Specification Approval Record

`
SPECIFICATION APPROVAL RECORD
=============================
Spec ID: [SD-XXX]
Title: [Specification Title]
Version: [Version]
Date: [Date]

TRACEABILITY:
- Source Requirements: [SR-XX, FR-XX]
- Key Decisions: [KD-XX]
- Resolves Pending Decisions: [PD-XX]

DESIGN REVIEW:
| Reviewer | Role | Status | Comments |
|----------|------|--------|----------|
| | | | |

DECISION: [APPROVED / REVISE / REJECTED]

APPROVAL:
| Role | Name | Signature | Date |
|------|------|-----------|------|
| [Reviewer 1] | | | |
| [Reviewer 2] | | | |
| [Reviewer 3] | | | |
`

---

## AUTHORITY MATRIX

| Gate | Product Owner | Lead Architect | Domain Expert | Data Architect | EI Lead | OE Lead | Backend Lead | Frontend Lead | DevOps | QA Lead | Security | AI Systems Eng | Validation Lead | Asset Lead | Learning Lead |
|------|---------------|----------------|---------------|----------------|---------|---------|--------------|---------------|--------|---------|----------|----------------|-----------------|------------|---------------|
| Gate 0 | **R/A** | | **A** | | | | | | | | | | | | |
| Gate 1A | | **R/A** | | **A** | | | | | **A** | | | **A** | | | |
| Gate 1B | | | **A** | **R/A** | **A** | **A** | | | | | | | | | |
| Gate 1C | | | | | | | **R/A** | **A** | **A** | **A** | **A** | | | | |
| Gate 1D | **R/A** | | **R/A** | | | | | **R/A** | | | | | | | |
| Gate 1E | **R/A** | **R/A** | **A** | | | | | | | **R/A** | | | | | |
| Gate 2 | **R/A** | **R/A** | | | | | | | | **R/A** | | | | | |
| Gate 3 | **A** | | | | **R/A** | **R/A** | | | | **R/A** | | | | | |
| Gate 4 | **R/A** | | **R/A** | | | | | | | **R/A** | | **R/A** | | |
| Gate 5 | **R/A** | | | | | | | | | **R/A** | | | **R/A** | |
| Gate 6 | **R/A** | | | | | | | | | **R/A** | | | | **R/A** |
| Gate 7 | **R/A** | **R/A** | | | | | | | **R/A** | **R/A** | **R/A** | | | |

Legend: **R** = Required (must approve), **A** = Advisory (consulted), **R/A** = Required and Approves

---

## PROCESS RULES

1. **No gate may be skipped**. Gates must be passed in sequence.
2. **Product Owner final decision** for Gate 0 and Gate 1E after reviewing the Codex AI-assisted architectural assessment and the AI-assisted Domain & Economic Methodology Assessment.
3. **Conditional approval** allowed only with documented conditions and target resolution date.
4. **Rejection** requires written rationale and corrective action plan before re-review.
5. **Artifacts must be complete** before gate review is scheduled.
6. **Traceability completeness** is a gate criterion for all gates Gate 1E and beyond.
7. **All conflicts (C1-C8) must have ADR resolution** before affected specifications are approved.
8. **No implementation without approved design** (SDD) traceable to approved specification (SD).
9. **Gate reviews are time-boxed**: 2 business days for review, 5 business days for conditional resolution.
10. **Records are immutable**: Approval records, ADRs, and checklists are append-only.

---

## DOCUMENT CONTROL

| Field | Value |
|-------|-------|
| **Document ID** | OF-AP-001 |
| **Version** | 1.0 |
| **Status** | DRAFT -- For Review |
| **Date** | 2026-11-08 |
| **Owner** | Product Owner |
| **Reviewers** | Codex AI-assisted assessment input, Domain Expert advisory role, technical reviewers as assigned, QA Lead |
| **Approval Required** | **Yes -- Before Stage 1 Begins** |

---

**END OF APPROVAL PROCESS**

*This document defines the mandatory governance process for OPPORTUNITY FACTORY. 12 named project gates: 8 stage-exit approval gates and 4 design-review gates must be passed before production deployment. Each gate has defined artifacts, criteria, authorities, and templates.*
