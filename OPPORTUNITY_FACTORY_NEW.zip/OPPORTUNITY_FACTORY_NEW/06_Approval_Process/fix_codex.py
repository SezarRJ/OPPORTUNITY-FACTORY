with open("GATE_0_APPROVAL_RECORD.md", "r", encoding="utf-8") as f:
    content = f.read()

old = """## 5. LEAD ARCHITECT ASSESSMENT -- PENDING

| Field | Value |
|-------|-------|
| **Name** | [To be completed by Lead Architect] |
| **Signature** | [Required] |
| **Date** | [Required] |
| **Assessment** | [Required: Written assessment of technical foundation completeness and risks] |
| **Reservations** | [Required: Any outstanding risks or reservations] |

---"""

new = """## 5. LEAD ARCHITECT ASSESSMENT -- PENDING

| Field | Value |
|-------|-------|
| **Name** | [To be completed by Lead Architect] |
| **Signature** | [Required] |
| **Date** | [Required] |
| **Assessment** | [Required: Written assessment of technical foundation completeness and risks] |
| **Reservations** | [Required: Any outstanding risks or reservations] |

---

## 5.1 CODEX ARCHITECTURAL ASSESSMENT AUTHORITY -- PRODUCT OWNER DECISION

**Decision Date:** 2026-11-08
**Authority:** Product Owner

**Decision:**
Codex is adopted as the project
'
s AI-assisted Architectural Review Tool under Product Owner oversight.

This means:
* Codex may prepare architectural assessments, analyze consistency, identify risks, and evaluate documented design decisions.
* Codex assessments must be accurately described as AI-assisted assessments prepared by Codex.
* Codex must not be represented as an independent human Lead Architect or as providing professional human certification.
* The Product Owner retains full authority and responsibility for reviewing, accepting, rejecting, or escalating assessment findings.
* Codex has no authority to approve Gate 0, close Gate 0, or authorize Stage 1.

Record this decision in the appropriate Gate 0 governance and assessment records.

Do not create a new approval gate or modify the existing gate hierarchy.

---

## 6. DOMAIN EXPERT ASSESSMENT -- PENDING

| Field | Value |
|-------|-------|
| **Name** | [To be completed by Domain Expert] |
| **Signature** | [Required] |
| **Date** | [Required] |
| **Assessment** | [Required: Written assessment of economic methodology completeness and risks] |
| **Reservations** | [Required: Any outstanding risks or reservations] |

---"""

content = content.replace(old, new)

with open("GATE_0_APPROVAL_RECORD.md", "w", encoding="utf-8") as f:
    f.write(content)

print("Done")
