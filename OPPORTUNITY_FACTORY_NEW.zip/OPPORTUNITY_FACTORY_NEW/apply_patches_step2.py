with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# 4. Update cross_market_replication aliases
old_cross_market = """    "cross_market_replication": {
        "aliases": (
            "business model operating elsewhere",
            "service model from another market",
            "transferable operating model",
            "replicate an existing service",
            "existing business model",
            "successful model in another market",
            "established service in another market",
            "operating record in another market",
            "repeat users in another market",
            "same model has users elsewhere",
            "established service operates abroad",
            "operating record abroad",
            "modelo de negocio existente",
            "modelo probado en otro mercado",
            "نموذج أعمال قائم في سوق آخر",
            "نموذج ناجح في سوق آخر",
            "تكرار نموذج ناجح",
        ),
        "reason": (
            "The context describes an existing model, product, or service that "
            "may be adapted or replicated across markets."
        ),
    },"""

new_cross_market = """    "cross_market_replication": {
        "aliases": (
            "replicate in another market",
            "replicate abroad",
            "replicate overseas",
            "replicate internationally",
            "replicate to another market",
            "replicate to another country",
            "replicate across markets",
            "proven model in another market",
            "proven model abroad",
            "proven model overseas",
            "successful model in another market",
            "successful model abroad",
            "established service in another market",
            "established service abroad",
            "operating model from another market",
            "operating model from abroad",
            "operating model from overseas",
            "transferable model to another market",
            "transferable model abroad",
            "business model operating elsewhere",
            "service model from another market",
            "service model from abroad",
            "service model from overseas",
            "existing business model in another market",
            "existing business model abroad",
            "modelo probado en otro mercado",
            "modelo exitoso en otro mercado",
            "modelo de negocio en otro mercado",
            "replicar en otro mercado",
            "replicar en el extranjero",
            "replicar internacionalmente",
            "نموذج أعمال مثبت في سوق آخر",
            "نموذج ناجح في سوق آخر",
            "نموذج قائم في سوق آخر",
            "تكرار نموذج في سوق آخر",
            "نقل نموذج إلى سوق آخر",
        ),
        "reason": (
            "The context describes an existing model, product, or service that "
            "may be adapted or replicated across markets. Requires explicit "
            "cross-market context (another market, abroad, overseas, internationally)."
        ),
    },"""

content = content.replace(old_cross_market, new_cross_market)
print("Step 4 done: cross_market_replication updated")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Step 4 applied successfully!")
