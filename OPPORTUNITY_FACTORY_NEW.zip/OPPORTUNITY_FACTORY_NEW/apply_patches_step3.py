with open("app/services/semantic.py", "r", encoding="utf-8") as f:
    content = f.read()

# 5. Add GENERALIZED_REGEX_RULES for compositional cases
old_regex_rules = """GENERALIZED_REGEX_RULES = (
    {
        "id": "capacity_ratio_below_nominal",
        "concept": "underutilized_capacity",
        "patterns": (
            r"\\b\\d+(?:\\s+percent)?\\s+of\\s+(?:its\\s+)?"
            r"(?:rated|nameplate|nominal|design)\\s+"
            r"(?:output|throughput|production|capacity)\\b",
            r"\\b(?:plant|line|facility|site|mill|warehouse)\\s+"
            r"(?:runs?|operates?)\\s+(?:at\\s+)?"
            r"(?:half|one\\s+third|two\\s+thirds)\\b",
            r"\\b(?:بنصف|بنص|نصف|ربع|ثلث)\\s+طاق\\w*"
            r"(?:\\s+(?:التصميمية|الاسمية))?\\b",
        ),
        "reason": (
            "The registered wording describes output or operation below a stated "
            "nominal capacity boundary."
        ),
    },
    {
        "id": "unserved_queue_or_pending_requests",
        "concept": "unmet_demand",
        "patterns": (
            r"\\b(?:waiting|wait)\\s+(?:list|lists|queue|queues)\\b",
            r"\\b(?:orders?|requests?|appointments?|cases?|pedidos|solicitudes)\\s+"
            r"(?:remain|are|were|quedan|siguen)\\s+"
            r"(?:unfilled|unserved|pending|unmet|pendientes)\\b",
            r"\\b(?:customers?|patients?|clients?|users?)\\s+(?:are\\s+)?"
            r"(?:turned\\s+away|left\\s+without|unable\\s+to\\s+obtain)\\b",
            r"\\b(?:clinicas?|pacientes?|clientes?)\\b.{0,30}\\b"
            r"(?:sin\\s+(?:cita|atencion|servicio)|fuera)\\b",
            r"\\b(?:المرضى|الزبائن|الناس)\\s+ينتظرون\\s+(?:دورهم|دور)\\b",
        ),
        "reason": (
            "The registered wording describes requests, customers, or users that "
            "cannot currently be served."
        ),
    },
    {
        "id": "material_rejection_or_disposal",
        "concept": "process_loss",
        "patterns": (
            r"\\b(?:rejected?|rejects?|scrapped?|scrap|spoiled?|spoilage|"
            r"shrinkage|rework)\\b",
            r"\\b(?:material|product|output|batches?)\\b.{0,30}\\b"
            r"(?:landfill|disposal)\\b",
            r"\\b(?:merma|rechazos?|desperdicio)\\b",
            r"\\b(?:هالك|تلف|مرفوضات)\\b",
        ),
        "reason": (
            "The registered wording describes rejected, spoiled, scrapped, or "
            "disposed output within an economic process."
        ),
    },
    {
        "id": "established_operation_outside_market",
        "concept": "cross_market_replication",
        "patterns": (
            r"\\b(?:service|business|format|scheme|franchise|approach)\\b.{0,30}\\b"
            r"(?:operates?|operated|worked|succeeded|scaled)\\b.{0,40}\\b"
            r"(?:overseas|internationally|foreign|abroad)\\b",
            r"\\b(?:servicio|negocio|modelo)\\b.{0,30}\\b"
            r"(?:opera|funciona|crece)\\b.{0,40}\\b"
            r"(?:exterior|internacional)\\b",
            r"\\b(?:خدمة|نموذج|شركة)\\b.{0,30}\\b"
            r"(?:تعمل|نجحت)\\b.{0,40}\\b"
            r"(?:خارج|دول\\s+اخرى|اسواق\\s+خارجية)\\b",
        ),
        "reason": (
            "The registered wording describes an established operating model outside "
            "the current market context."
        ),
    },
    {
        "id": "cross_market_price_spread",
        "concept": "price_difference",
        "patterns": (
            r"\\b(?:premium|discount|margin|price)\\b.{0,30}\\b"
            r"(?:higher|lower|wider|narrower|different)\\b.{0,40}\\b"
            r"(?:region|market|city|country)\\b",
            r"\\b(?:buyers?|traders?)\\b.{0,30}\\bpay\\b.{0,30}\\b"
            r"(?:more|less)\\b.{0,40}\\b(?:region|market|city|country)\\b",
        ),
        "reason": (
            "The registered wording describes a geographic or market price spread "
            "that may warrant cross-market investigation."
        ),
    },
    {
        "id": "asset_conversion_action",
        "concept": "asset_reconfiguration",
        "patterns": (
            r"\\b(?:retrofit\\w*|convert\\w*|refit\\w*|redeploy\\w*|"
            r"repurpos\\w*|adapt\\w*)\\s+(?:an?\\s+|the\\s+)?"
            r"(?:warehouse|plant|factory|facility|mill|site|line|equipment)\\b",
        ),
        "reason": (
            "The registered wording describes a concrete change to the use or "
            "configuration of an existing asset."
        ),
    },
)"""

new_regex_rules = """GENERALIZED_REGEX_RULES = (
    {
        "id": "capacity_ratio_below_nominal",
        "concept": "underutilized_capacity",
        "patterns": (
            r"\\b\\d+(?:\\s+percent)?\\s+of\\s+(?:its\\s+)?"
            r"(?:rated|nameplate|nominal|design)\\s+"
            r"(?:output|throughput|production|capacity)\\b",
            r"\\b(?:plant|line|facility|site|mill|warehouse)\\s+"
            r"(?:runs?|operates?)\\s+(?:at\\s+)?"
            r"(?:half|one\\s+third|two\\s+thirds)\\b",
            r"\\b(?:بنصف|بنص|نصف|ربع|ثلث)\\s+طاق\\w*"
            r"(?:\\s+(?:التصميمية|الاسمية))?\\b",
        ),
        "reason": (
            "The registered wording describes output or operation below a stated "
            "nominal capacity boundary."
        ),
    },
    {
        "id": "unserved_queue_or_pending_requests",
        "concept": "unmet_demand",
        "patterns": (
            r"\\b(?:waiting|wait)\\s+(?:list|lists|queue|queues)\\b",
            r"\\b(?:orders?|requests?|appointments?|cases?|pedidos|solicitudes)\\s+"
            r"(?:remain|are|were|quedan|siguen)\\s+"
            r"(?:unfilled|unserved|pending|unmet|pendientes)\\b",
            r"\\b(?:customers?|patients?|clients?|users?)\\s+(?:are\\s+)?"
            r"(?:turned\\s+away|left\\s+without|unable\\s+to\\s+obtain)\\b",
            r"\\b(?:clinicas?|pacientes?|clientes?)\\b.{0,30}\\b"
            r"(?:sin\\s+(?:cita|atencion|servicio)|fuera)\\b",
            r"\\b(?:المرضى|الزبائن|الناس)\\s+ينتظرون\\s+(?:دورهم|دور)\\b",
        ),
        "reason": (
            "The registered wording describes requests, customers, or users that "
            "cannot currently be served."
        ),
    },
    {
        "id": "material_rejection_or_disposal",
        "concept": "process_loss",
        "patterns": (
            r"\\b(?:rejected?|rejects?|scrapped?|scrap|spoiled?|spoilage|"
            r"shrinkage|rework)\\b",
            r"\\b(?:material|product|output|batches?)\\b.{0,30}\\b"
            r"(?:landfill|disposal)\\b",
            r"\\b(?:merma|rechazos?|desperdicio)\\b",
            r"\\b(?:هالك|تلف|مرفوضات)\\b",
        ),
        "reason": (
            "The registered wording describes rejected, spoiled, scrapped, or "
            "disposed output within an economic process."
        ),
    },
    {
        "id": "established_operation_outside_market",
        "concept": "cross_market_replication",
        "patterns": (
            r"\\b(?:service|business|format|scheme|franchise|approach)\\b.{0,30}\\b"
            r"(?:operates?|operated|worked|succeeded|scaled)\\b.{0,40}\\b"
            r"(?:overseas|internationally|foreign|abroad)\\b",
            r"\\b(?:servicio|negocio|modelo)\\b.{0,30}\\b"
            r"(?:opera|funciona|crece)\\b.{0,40}\\b"
            r"(?:exterior|internacional)\\b",
            r"\\b(?:خدمة|نموذج|شركة)\\b.{0,30}\\b"
            r"(?:تعمل|نجحت)\\b.{0,40}\\b"
            r"(?:خارج|دول\\s+اخرى|اسواق\\s+خارجية)\\b",
        ),
        "reason": (
            "The registered wording describes an established operating model outside "
            "the current market context."
        ),
    },
    {
        "id": "cross_market_price_spread",
        "concept": "price_difference",
        "patterns": (
            r"\\b(?:premium|discount|margin|price)\\b.{0,30}\\b"
            r"(?:higher|lower|wider|narrower|different)\\b.{0,40}\\b"
            r"(?:region|market|city|country)\\b",
            r"\\b(?:buyers?|traders?)\\b.{0,30}\\bpay\\b.{0,30}\\b"
            r"(?:more|less)\\b.{0,40}\\b(?:region|market|city|country)\\b",
        ),
        "reason": (
            "The registered wording describes a geographic or market price spread "
            "that may warrant cross-market investigation."
        ),
    },
    {
        "id": "asset_conversion_action",
        "concept": "asset_reconfiguration",
        "patterns": (
            r"\\b(?:retrofit\\w*|convert\\w*|refit\\w*|redeploy\\w*|"
            r"repurpos\\w*|adapt\\w*)\\s+(?:an?\\s+|the\\s+)?"
            r"(?:warehouse|plant|factory|facility|mill|site|line|equipment)\\b",
        ),
        "reason": (
            "The registered wording describes a concrete change to the use or "
            "configuration of an existing asset."
        ),
    },
    {
        "id": "oee_availability_losses",
        "concept": "process_loss",
        "patterns": (
            r"\\bOEE\\b.{0,30}\\b(?:availability|quality|performance)\\s+(?:loss|losses|losses?)\\b",
            r"\\b(?:availability|quality)\\s+loss(?:es)?\\b.{0,30}\\b(?:line|plant|facility|process)\\b",
            r"\\b(?:المعدات|الخط|المصنع)\\b.{0,30}\\b(?:خسارة|هدر|فقد)\\b.{0,30}\\b(?:التوفر|الجودة|الأداء)\\b",
        ),
        "reason": (
            "The registered wording describes OEE availability or quality losses "
            "in a production line or process."
        ),
    },
    {
        "id": "playbook_porting_replication",
        "concept": "cross_market_replication",
        "patterns": (
            r"\\b(?:playbook|model|format|scheme|approach)\\b.{0,30}\\b"
            r"(?:port|porting|replicate|replicating|transfer|transferring)\\b.{0,40}\\b"
            r"(?:to|into|in|for)\\b.{0,30}\\b(?:market|region|country|operations|operations?)\\b",
            r"\\b(?:playbook|modelo|نموذج|نهج)\\b.{0,30}\\b"
            r"(?:replicar|transferir|نقل|تكرار)\\b.{0,40}\\b"
            r"(?:a|en|para|في|إلى)\\b.{0,30}\\b(?:mercado|región|operaciones|سوق|عمليات)\\b",
        ),
        "reason": (
            "The registered wording describes porting or replicating a proven "
            "playbook, model, or format to another market or region."
        ),
    },
    {
        "id": "jv_strategic_alignment_combination",
        "concept": "combination",
        "patterns": (
            r"\\b(?:strategic|strategical)\\s+alignment\\b.{0,30}\\b"
            r"(?:JV|joint.venture|partnership|collaboration|alliance)\\b",
            r"\\b(?:JV|joint\\s+venture)\\s+(?:thesis|thesis|proposal|opportunity)\\b",
            r"\\b(?:استراتيجية|استراتيجي)\\s+محاذاة\\b.{0,30}\\b"
            r"(?:شراكة|تحالف|مشروع\\s+مشترك|JV)\\b",
        ),
        "reason": (
            "The registered wording describes strategic alignment creating "
            "a joint venture or partnership thesis."
        ),
    },
    {
        "id": "brownfield_adaptive_reuse_asset_reconfig",
        "concept": "asset_reconfiguration",
        "patterns": (
            r"\\b(?:brownfield|greenfield)\\b.{0,30}\\b(?:adaptive\\s+reuse|repurpose|redevelop|convert)\\b",
            r"\\b(?:last.?mile|last\\s+mile)\\b.{0,30}\\b(?:logistics|distribution|warehouse|facility)\\b",
            r"\\b(?:بنية\\s+تحتية|موقع)\\s+(?:بنية)\\b.{0,30}\\b(?:إعادة\\s+استخدام|تحويل|تطوير)\\b",
        ),
        "reason": (
            "The registered wording describes brownfield adaptive reuse for "
            "logistics or industrial repurposing."
        ),
    },
    {
        "id": "supply_demand_disequilibrium",
        "concept": "unmet_demand",
        "patterns": (
            r"\\b(?:supply.?demand|demand.?supply)\\s+(?:disequilibrium|imbalance|gap|disequilibrium)\\b",
            r"\\b(?:demand\\s+(?:outpaces|exceeds|outstrips)\\s+supply)\\b",
            r"\\b(?:العرض\\s+والطلب|الطلب\\s+والعرض)\\b.{0,30}\\b(?:اختلال|فجوة|عدم\\s+توازن)\\b",
        ),
        "reason": (
            "The registered wording describes a supply-demand disequilibrium "
            "with demand exceeding supply."
        ),
    },
    {
        "id": "underleveraged_latent_capacity",
        "concept": "underutilized_capacity",
        "patterns": (
            r"\\b(?:underleveraged|under.leveraged)\\b.{0,30}\\b(?:capacity|asset|resource|base)\\b",
            r"\\b(?:latent|hidden|untapped)\\s+(?:capacity|potential|capability)\\b",
            r"\\b(?:أصل|مورد|قاعدة)\\s+(?:غير\\s+مستغل|كامنة|خفية)\\b",
        ),
        "reason": (
            "The registered wording describes underleveraged assets with "
            "latent or untapped capacity."
        ),
    },
    {
        "id": "deadweight_allocative_inefficiency",
        "concept": "process_loss",
        "patterns": (
            r"\\bdeadweight\\s+loss\\b",
            r"\\ballocative\\s+inefficiency\\b",
            r"\\b(?:خسارة\\s+عاجزة|عدم\\s+كفاءة\\s+توزيعية)\\b",
        ),
        "reason": (
            "The registered wording describes deadweight loss or allocative "
            "inefficiency in the market or process."
        ),
    },
    {
        "id": "value_leakage_transformacion",
        "concept": "process_loss",
        "patterns": (
            r"\\bfuga\\s+de\\s+valor\\b.{0,30}\\b(?:cadena|transformación|transformacion)\\b",
            r"\\bperdidas?\\s+de\\s+rendimiento\\b",
            r"\\b(?:تسرب\\s+القيمة|فقدان\\s+القيمة)\\b.{0,30}\\b(?:سلسلة|تحويل)\\b",
        ),
        "reason": (
            "The registered wording describes value leakage in the transformation "
            "chain with yield losses."
        ),
    },
    {
        "id": "multistage_byproduct_to_input",
        "concept": "combination",
        "patterns": (
            r"\\b(?:by.?product|byproduct|waste|output|residue)\\b.{0,50}\\b"
            r"(?:feedstock|input|raw\\s+material|serves?\\s+as)\\b.{0,50}\\b"
            r"(?:another|other|different|nearby|adjacent)\\b",
            r"\\b(?:subproducto|desecho|residuo|salida)\\b.{0,50}\\b"
            r"(?:materia\\s+prima|insumo|alimento|sirve\\s+como)\\b.{0,50}\\b"
            r"(?:otra|otro|diferente|cercana|adyacente)\\b",
            r"\\b(?:منتج\\s+ثانوي|نفايات|مخلفات|مخرجات)\\b.{0,50}\\b"
            r"(?:مادة\\s+اولية|مدخل|تستخدم\\s+كـ)\\b.{0,50}\\b"
            r"(?:أخرى|مختلفة|قريبة|مجاورة)\\b",
        ),
        "reason": (
            "The registered wording describes byproducts or waste from one process "
            "serving as feedstock or input for another actor/process."
        ),
    },
    {
        "id": "three_actor_cold_chain",
        "concept": "combination",
        "patterns": (
            r"\\b(?:farmers?|growers?|producers?)\\b.{0,50}\\b(?:surplus|excess|extra)\\b.{0,50}\\b"
            r"(?:logistics|transport|distribution|trucks?)\\b.{0,50}\\b"
            r"(?:retailer|buyer|market|customer)\\b.{0,30}\\b"
            r"(?:cold\\s+chain|consistent\\s+supply|reliable\\s+supply)\\b",
            r"\\b(?:مزارعين|منتجين)\\b.{0,50}\\b(?:فائض|زيادة)\\b.{0,50}\\b"
            r"(?:لوجستيات|نقل|توزيع)\\b.{0,50}\\b(?:بائع|مشتري|سوق|عميل)\\b",
        ),
        "reason": (
            "The registered wording describes connecting multiple actors "
            "(farmers, logistics, retailers) to create a cold chain."
        ),
    },
    {
        "id": "industrial_symbiosis_slag_cement",
        "concept": "combination",
        "patterns": (
            r"\\b(?:steel|mill|foundry)\\s+(?:slag|by.?product|output)\\b.{0,50}\\b"
            r"(?:cement|clinker|SCM|supplementary\\s+cementitious)\\b",
            r"\\b(?:صلب|مسبك|مطحنة)\\s+(?:خبث|مخلف|مخرج)\\b.{0,50}\\b"
            r"(?:أسمنت|كلينكر|مادة\\s+أسمنتية\\tإضافية)\\b",
        ),
        "reason": (
            "The registered wording describes industrial symbiosis where "
            "steel mill slag serves as supplementary cementitious material."
        ),
    },
    {
        "id": "integrated_port_rail_logistics",
        "concept": "combination",
        "patterns": (
            r"\\b(?:port|berth|terminal)\\b.{0,50}\\b(?:rail|railway|train)\\b.{0,50}\\b"
            r"(?:logistics|operator|integrate|integration)\\b",
            r"\\b(?:ميناء|مرفأ|رصيف)\\b.{0,50}\\b(?:سكة|قطار|حديد)\\b.{0,50}\\b"
            r"(?:لوجستيات|مشغل|تكامل|دمج)\\b",
        ),
        "reason": (
            "The registered wording describes integrating port, rail, and logistics "
            "operations to capture delay cost savings."
        ),
    },
    {
        "id": "unmet_demand_no_payer_hard_gate",
        "concept": "unmet_demand",
        "patterns": (
            r"\\b(?:unmet\\s+demand|demand\\s+exceeds|significant\\s+demand)\\b.{0,50}\\b"
            r"(?:capacity\\s+exists|hospital|facility)\\b.{0,50}\\b"
            r"(?:no\\s+payer|payer\\s+not|without\\s+payer|unidentified\\s+payer)\\b",
        ),
        "reason": (
            "The registered wording identifies unmet demand but signals "
            "missing payer (Hard Gate HG-3 risk)."
        ),
    },
)"""

content = content.replace(old_regex_rules, new_regex_rules)
print("Step 5 done: GENERALIZED_REGEX_RULES updated")

with open("app/services/semantic.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Step 5 applied successfully!")
