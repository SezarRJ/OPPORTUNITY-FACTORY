# OPPORTUNITY FACTORY V2 — Independent Adversarial Benchmark Freeze

**Status:** Frozen v1.0, awaiting Product Owner review. **Not executed against the application.**

## 1. Scenario distribution

- Unseen phrasing: 20 cases
- Arabic and multilingual: 20 cases
- Negation and ambiguity: 15 cases
- Compositional reasoning: 20 cases
- Negative controls: 20 cases

## 2. Outcome distribution
- Positive, unambiguous: 58
- Negative/no pathway: 32
- Ambiguous/unscored: 5 (UA-01, UA-02, UA-03, UA-04, UA-05)
- Scored denominator: 90
- Single-pathway positives: 21
- Multi-pathway positives: 37
- No-pathway negatives: 32

## 3. P1–P6 coverage

**Expected pathway-set coverage** (multi-pathway cases count once for each expected pathway):
- P1: 31 cases
- P2: 33 cases
- P3: 20 cases
- P4: 18 cases
- P5: 30 cases
- P6: 14 cases

**Pathways challenged by the benchmark** (includes positive cases, explicit false-positive controls, and candidate pathways in ambiguous cases):
- P1: 37 cases
- P2: 40 cases
- P3: 27 cases
- P4: 24 cases
- P5: 35 cases
- P6: 24 cases

The pathway counts are not forced to be identical: compositional cases legitimately exercise multiple pathways, while P5 specifically requires complementary activities/assets and P6 requires an existing asset/operation being reconfigured. The matrix below shows pathway challenges by family; all six pathways are covered by the benchmark, with false-positive controls included.

| Family | P1 | P2 | P3 | P4 | P5 | P6 |
|---|---:|---:|---:|---:|---:|---:|
| Unseen phrasing | 9 | 8 | 4 | 4 | 5 | 3 |
| Arabic/multilingual | 7 | 9 | 5 | 4 | 6 | 2 |
| Negation/ambiguity | 3 | 5 | 4 | 2 | 1 | 4 |
| Compositional | 16 | 16 | 11 | 11 | 19 | 9 |
| Negative controls | 2 | 2 | 3 | 3 | 4 | 6 |
## 4. Scenario IDs by family

**Unseen phrasing (20):** OF-UF-01, OF-UF-02, OF-UF-03, OF-UF-04, OF-UF-05, OF-UF-06, OF-UF-07, OF-UF-08, OF-UF-09, OF-UF-10, OF-UF-11, OF-UF-12, OF-UF-13, OF-UF-14, OF-UF-15, OF-UF-16, OF-UF-17, OF-UF-18, OF-UF-19, UA-01
**Arabic and multilingual (20):** OF-ML-01, OF-ML-02, OF-ML-03, OF-ML-04, OF-ML-05, OF-ML-06, OF-ML-07, OF-ML-08, OF-ML-09, OF-ML-10, OF-ML-11, OF-ML-12, OF-ML-13, OF-ML-14, OF-ML-15, OF-ML-16, OF-ML-17, OF-ML-18, OF-ML-19, UA-02
**Negation and ambiguity (15):** OF-NA-01, OF-NA-02, OF-NA-03, OF-NA-04, OF-NA-05, OF-NA-06, OF-NA-07, OF-NA-08, OF-NA-09, OF-NA-10, OF-NA-11, OF-NA-12, OF-NA-13, OF-NA-14, UA-03
**Compositional reasoning (20):** OF-CR-01, OF-CR-02, OF-CR-03, OF-CR-04, OF-CR-05, OF-CR-06, OF-CR-07, OF-CR-08, OF-CR-09, OF-CR-10, OF-CR-11, OF-CR-12, OF-CR-13, OF-CR-14, OF-CR-15, OF-CR-16, OF-CR-17, OF-CR-18, OF-CR-19, UA-04
**Negative controls (20):** OF-NC-01, OF-NC-02, OF-NC-03, OF-NC-04, OF-NC-05, OF-NC-06, OF-NC-07, OF-NC-08, OF-NC-09, OF-NC-10, OF-NC-11, OF-NC-12, OF-NC-13, OF-NC-14, OF-NC-15, OF-NC-16, OF-NC-17, OF-NC-18, OF-NC-19, UA-05

## 5. Expected outcomes and rationale

Every case in `independent_benchmark_95.json` includes unique ID; original input; language; explicit economic facts; expected normalized concepts; actors; activities; relationships; expected pathway set; pathways under test; positive/negative/ambiguous outcome; supporting rationale; missing information and uncertainty; and unambiguous/scoring status.

Expected pathway sets are frozen independently of application output. An empty expected pathway list means no pathway is justified. Ambiguous cases carry candidate pathways separately and are not forced into a label.

## 6. Ambiguous cases and scoring

- **UA-01** (candidate P1): A manufacturer reports 72% utilization over the year, but the record does not say whether the remaining time is avoidable idle capacity, planned maintenance, or seasonal demand alignment. Unknowns: Maintenance schedule, demand seasonality, asset constraints, product mix.
- **UA-02** (candidate P2): التطبيق الجديد لديه downloads كثيرة وwaitlist طويلة، لكن لا توجد بيانات توضح هل المستخدمون لا يجدون بديلاً حالياً أم أنهم يسجلون فقط للحصول على تجربة مجانية. Unknowns: Current alternatives, active usage, conversion, payer, service capacity.
- **UA-03** (candidate P3): A process loses 4% of material at a transfer point, but the supplied industry specification does not establish whether this is normal or excessive. Unknowns: Industry norm, product specification, measurement reliability, recovery cost.
- **UA-04** (candidate P4): A firm wants to replicate a foreign service whose press coverage is positive, but independent operating results and target-market availability are unknown. Unknowns: Operating metrics, source/target market evidence, transferability.
- **UA-05** (candidate P5): Two firms propose sharing a facility; both have compatible schedules, but no evidence establishes whether shared operations reduce total cost or create new costs. Unknowns: Incremental costs, utilization, governance, liability, savings.

Scoring policy:
- 90 unambiguous cases form the primary denominator.
- Exact expected pathway-set match is required; no-pathway cases require an empty returned pathway set.
- False positive pathways are returned labels absent from the frozen expected set; false negatives are expected labels not returned.
- Five ambiguous cases are excluded from ordinary accuracy and reported separately; no forced pathway label.
- Single-pathway, multi-pathway and no-pathway outcomes are reported separately.
- A correct pathway label does not excuse unsupported inference, missing evidence, or fabricated economic relationships; those are separately flagged.

## 7. Distinctness and separation

- New IDs use `OF-UF-*`, `OF-ML-*`, `OF-NA-*`, `OF-CR-*`, `OF-NC-*`; ambiguous IDs are `UA-01`–`UA-05`.
- Existing semantic scenarios use `SB-*`; adversarial scenarios use `ADV-*`; controlled references use `RC-*`.
- The lexical distinctness audit found no exact text duplicates. Highest token Jaccard similarity and highest sequence similarity are documented in `distinctness_audit.json`.
- Inputs use different industries, actors, facts, process structures and economic relationships; shared pathway concepts are intentional.
- The benchmark is a standalone JSON/CSV artifact, not imported by pytest or added to the existing suite.
- Existing test inventory and fixture content are preserved separately in `existing_test_inventory.json`.

## 8. Frozen development baseline

- Exact collection: 85 tests; exact pytest node IDs: `baseline_exact_nodeids.txt` (85 lines).
- Result: **60 passed, 25 failed**. Full traceback output: `baseline_pytest_full_tracebacks.txt`.
- Failure node IDs and exact pytest summary messages: `baseline_failures.json`.
- Existing semantic scenarios: 11 (`SB-01`–`SB-11`). Existing adversarial scenarios: 37, plus `test_adversarial_benchmark_summary`.
- Environment and exact commands are recorded in `baseline_failures.json`.

## 9. Change-control confirmation

- No application source, existing test source, or project configuration was modified.
- No aliases, semantic rules, pathway logic, or architecture were changed.
- The new benchmark has not been executed against the application.
- No implementation change or held-out evaluation has been performed.

## 10. Architecture invariants

P1–P6 only; 12 canonical entities only; five disciplines and nine modules preserved; PO-D2 remains deferred and unresolved. No P7 or thirteenth entity is introduced.

## 11. Exact 25 baseline failures

1. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-01]`
   - `AssertionError: assert 'discovery_reasoning' in {'assumptions': ['The investigation scope supplied by the owner is the intended analytical boundary.', 'Registered sou...omparable basis.'], 'currency': '', 'formula': 'material_loss / input_quantity', 'id': 'EC-006', ...}, ...], ...}, ...}`
2. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-02]`
   - `AssertionError: assert 'discovery_reasoning' in {'assumptions': ['The investigation scope supplied by the owner is the intended analytical boundary.', 'Registered sou...omparable basis.'], 'currency': '', 'formula': 'material_loss / input_quantity', 'id': 'EC-006', ...}, ...], ...}, ...}`
3. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-03]`
   - `AssertionError: assert 'discovery_reasoning' in {'assumptions': ['The investigation scope supplied by the owner is the intended analytical boundary.', 'Registered sou...omparable basis.'], 'currency': '', 'formula': 'material_loss / input_quantity', 'id': 'EC-006', ...}, ...], ...}, ...}`
4. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-04]`
   - `AssertionError: assert 'discovery_reasoning' in {'assumptions': ['The investigation scope supplied by the owner is the intended analytical boundary.', 'Registered sou...omparable basis.'], 'currency': '', 'formula': 'material_loss / input_quantity', 'id': 'EC-006', ...}, ...], ...}, ...}`
5. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-05]`
   - `AssertionError: assert 'discovery_reasoning' in {'assumptions': ['The investigation scope supplied by the owner is the intended analytical boundary.', 'Registered sou...omparable basis.'], 'currency': '', 'formula': 'material_loss / input_quantity', 'id': 'EC-006', ...}, ...], ...}, ...}`
6. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-06]`
   - `AssertionError: assert 'discovery_reasoning' in {'assumptions': ['The investigation scope supplied by the owner is the intended analytical boundary.', 'Registered sou...omparable basis.'], 'currency': '', 'formula': 'material_loss / input_quantity', 'id': 'EC-006', ...}, ...], ...}, ...}`
7. `tests/test_adversarial_benchmark.py::test_unseen_phrasing[ADV-UP-07]`
   - `AssertionError: ADV-UP-07: Expected {'P3', 'P2', 'P1'}, got {'P1'}. Source: The facility has significant unused production capacity while downstream customers report consistent...`
8. `tests/test_adversarial_benchmark.py::test_multilingual_variation[ADV-ML-05]`
   - `AssertionError: ADV-ML-05: Expected {'P3', 'P2'}, got {'P3', 'P5'}. Source: A persistent deadweight loss exists due to allocative inefficiency in the regional cold-chain market...`
9. `tests/test_adversarial_benchmark.py::test_multilingual_variation[ADV-ML-08]`
   - `AssertionError: ADV-ML-08: Expected {'P4', 'P1'}, got {'P1'}. Source: The مصنع has قدرة غير مستغلة and we can replicate the نموذج الناجح from Saudi....`
10. `tests/test_adversarial_benchmark.py::test_multilingual_variation[ADV-ML-09]`
   - `AssertionError: ADV-ML-09: Expected {'P4', 'P1'}, got {'P4'}. Source: Tenemos capacity ociosa en la planta y un proven model we can replicate....`
11. `tests/test_adversarial_benchmark.py::test_negation_ambiguity[ADV-NA-02]`
   - `AssertionError: ADV-NA-02: Expected set(), got {'P2'}. Source: There is no unmet demand in this market; supply fully meets all customer requirements.... Reason: Should NOT trigger P2 - explicit negation`
12. `tests/test_adversarial_benchmark.py::test_negation_ambiguity[ADV-NA-05]`
   - `AssertionError: ADV-NA-05: Expected set(), got {'P1'}. Source: The company has excess inventory that is not moving, but this is not due to production capacity issu... Reason: Excess inventory != underutilized capacity - different economic mechanism`
13. `tests/test_adversarial_benchmark.py::test_compositional_understanding[ADV-CO-01]`
   - `AssertionError: ADV-CO-01: Missing primary pathway {'P1'}. Got {'P5'}, expected at least {'P1'}. Source: The food processing plant generates organic waste that a nearby biofuel facility could use as feedst...`
14. `tests/test_adversarial_benchmark.py::test_compositional_understanding[ADV-CO-02]`
   - `AssertionError: ADV-CO-02: Missing primary pathway {'P1'}. Got {'P5'}, expected at least {'P1'}. Source: Local farmers have surplus produce but no cold storage. A logistics company has trucks but empty ret...`
15. `tests/test_adversarial_benchmark.py::test_compositional_understanding[ADV-CO-03]`
   - `AssertionError: ADV-CO-03: Missing primary pathway {'P1'}. Got {'P5'}, expected at least {'P1'}. Source: The steel mill slag output serves as the cement plant primary supplementary cementitious material, r...`
16. `tests/test_adversarial_benchmark.py::test_compositional_understanding[ADV-CO-04]`
   - `AssertionError: ADV-CO-04: Missing primary pathway {'P1'}. Got {'P5'}, expected at least {'P1'}. Source: The port has unused berth capacity. Shippers face delays at the competing port. A rail connection ex...`
17. `tests/test_adversarial_benchmark.py::test_compositional_understanding[ADV-CO-05]`
   - `AssertionError: ADV-CO-05: Missing primary pathway {'P1'}. Got set(), expected at least {'P1'}. Source: Two adjacent factories: one vents waste heat, the other burns gas for process heat. A heat exchange ...`
18. `tests/test_adversarial_benchmark.py::test_negative_controls[ADV-NC-03]`
   - `AssertionError: ADV-NC-03: Expected set(), got {'P2', 'P1'}. Source: The plant has significant idle capacity and is running at full utilization. Demand exceeds supply bu... Reason: Direct contradictions within same description`
19. `tests/test_adversarial_benchmark.py::test_adversarial_benchmark_summary`
   - `AssertionError: Generalization accuracy 67.57% below 70%`
20. `tests/test_controlled_reference_cases.py::test_controlled_reference_case_expected_pathways[RC-01]`
   - `AssertionError: assert {'P4'} == {'P2', 'P4'}`
21. `tests/test_controlled_reference_cases.py::test_controlled_reference_case_expected_pathways[RC-05]`
   - `AssertionError: assert set() == {'P5'}`
22. `tests/test_controlled_reference_cases.py::test_controlled_reference_case_expected_pathways[RC-07]`
   - `AssertionError: assert {'P1', 'P5', 'P6'} == {'P1', 'P3', 'P5', 'P6'}`
23. `tests/test_controlled_reference_cases.py::test_controlled_reference_case_expected_pathways[RC-09]`
   - `AssertionError: assert set() == {'P4'}`
24. `tests/test_controlled_reference_cases.py::test_pass_fail_unknown_and_conflicting_hard_gates`
   - `AssertionError: assert 'awaiting' == 'passed'`
25. `tests/test_economic_modeling.py::test_structured_economic_model_calculates_and_replays`
   - `AssertionError: assert 'awaiting' == 'passed'`
